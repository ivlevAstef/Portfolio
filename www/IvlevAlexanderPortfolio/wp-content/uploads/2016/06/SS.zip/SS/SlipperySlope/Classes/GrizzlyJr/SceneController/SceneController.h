#ifndef _GRIZZLY_JR_SCENE_CONTROLLER_H_
#define _GRIZZLY_JR_SCENE_CONTROLLER_H_

#include "cocos2d.h"
#include <map>
#include <vector>
#include <string>

#include "SceneInformation.h"

namespace GrizzlyJr
{
	class LoadDynamicSceneInterface;
	class SceneController
	{
	private:
		struct TextureInformation {
			std::string postfix;
			std::string path;
			std::string texture_path;
			cocos2d::CCTexture2DPixelFormat format;
		};
		typedef std::map<cocos2d::CCTexture2D*,TextureInformation> TextureInformationMap;
		static TextureInformationMap textureInformation;
		
		struct PrivateSceneInformation {
			std::vector<LoadingData> resources;
			std::vector<cocos2d::CCTexture2D*> texture_resources;
		};
		
		struct KeyLoadingData {
			size_t reference;
			cocos2d::CCTexture2D* texture;
		};

		static cocos2d::CCScene* saveScene;
		static SceneController* singleton;
		static std::string prefix;
		static std::vector<std::string> postfixsPriority;
			
		std::vector<PrivateSceneInformation> scenes;
		std::vector<SceneInformation> sceneInfoForReload;
		
		std::map<LoadingData,KeyLoadingData> alldata;
		
		friend class LoadDynamicSceneInterface;
	public:
		static void remove();
		SceneController();
			
		void push(SceneInformation newScene);
		
		void restart(cocos2d::CCScene* scene);
			
		bool pop();
			
		void replace(SceneInformation newScene);
		void replace(SceneInformation newScene, SceneInformation loadScene);
			
		static void setPostfixs(std::vector<std::string> postfixNew) { postfixsPriority = postfixNew; }
		static void setPrefix(std::string prefixNew) { prefix = prefixNew; }
		static std::vector<std::string> getPostfixs() { return postfixsPriority; }
			
		void cleanLastSceneResource();
		std::vector<LoadingData> cleanLastSceneResourceWithUseNew(std::vector<LoadingData>& newResource);
			
		void loadDataIsNeeded(std::string name);
		void unloadDataIsNeeded(std::string name);
		
		void loadDataIsNeeded(const char* name);
		void unloadDataIsNeeded(const char* name);
		
		void loadDataIsNeeded(LoadingData data);
		void unloadDataIsNeeded(LoadingData data);
			
		static SceneController* get();
		static cocos2d::CCScene* getScene() { return saveScene; }
		
		static std::string getTexturePostfix(cocos2d::CCSprite*);
		
		static bool getOrSetState(int new_state);///if 0 == new_state -> don't change if new_state < 0 -> false new_state> 0 true
		static cocos2d::CCNode* loadUnloadAllResourceWithSaveState(bool isLoad,cocos2d::CCNode* label_for_visit=0x0);
		///return current layer
		
	private:
		PrivateSceneInformation loadResourceForScene(SceneInformation scene);
		
		void replace(SceneInformation newScene,PrivateSceneInformation privateScene);
		
		static cocos2d::CCTexture2DPixelFormat convertTextureFormat(LoadingData::Format texrureFormat);
		
		static cocos2d::CCTexture2D* loadData(std::string name,cocos2d::CCTexture2DPixelFormat format);
		static void unloadData(cocos2d::CCTexture2D* texture);
	};
	
	class LoadDynamicSceneInterface
	{
	protected:
		SceneInformation info;
		float currentSize;
		float fullSize;
		float sizeOnCreateTexture;
		size_t index;
		
		SceneController::PrivateSceneInformation privateScene;
	public:
		void initDynamicScene(SceneInformation info);
		
		bool loadNextResource();///return true if finish load
		float getProgress();///return 0-1
		
		void endDynamicScene();
	};
};
#endif
