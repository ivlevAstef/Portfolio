//
//  Replay.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.08.13.
//
//

#include "Replay.h"
#include <GrizzlyJr/Graphic/Box2DCocos.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

unsigned int Replay::fps = 24;

Replay::Frame::Frame():e(0x0),c(0) {
}

void Replay::Frame::fMalloc(size_t count) {
	if( 0x0 == e && count > 0) {
		e = (ElementFrame*)malloc(count*sizeof(ElementFrame));
		c = count;
	}
}
void Replay::Frame::fFree() {
	if( 0x0 != e) {
		free(e);
		e = 0x0;
		c = 0;
	}
}
Replay::Frame::~Frame() {
	fFree();
}

Replay::Replay():time(0),is_record(0),is_play(0),replay_speed(0) {
	float mult = 5*Box2DCocos::getDefaultConstant()*((float)fps);
	mult_x_for_int = mult/Box2DCocos::getRatioX();
	mult_y_for_int = mult/Box2DCocos::getRatioY();
	mult_r_for_int = fps;
}

//////////////////////////RECORD
bool Replay::startRecord(PhysicAuto* record_auto) {
	if( is_play || is_record || 0x0 == record_auto) {
		return false;
	}
	
	is_record = true;
	time = 0;
	replay_speed = 1;
	clearFrames();
	
	std::vector<AutoElement*> elements = getElements(record_auto);
	begin.pointer = record_auto;
	begin.pos = record_auto->getPosition();
	begin.elements.clear();
	
	for( size_t i =0; i < elements.size(); i++) {
		BeginElementFrame e;
		e.pointer = elements[i];
		e.pos = elements[i]->getPosition();
		e.angle = elements[i]->getRotation();
		begin.elements.push_back(e);
	}
	
	current = begin;
	
	return true;
}
bool Replay::tickRecord(float dt) {
	if( !is_record) {
		return false;
	}
	
	size_t index = 0;
	BeginAutoFrame last = current;
	while( interpolation(time, dt, current,index++)) {
		Frame* frame = new Frame();
		frame->a.x = (int)((current.pos.x-last.pos.x)*mult_x_for_int);
		frame->a.y = (int)((current.pos.y-last.pos.y)*mult_y_for_int);
		
		frame->fMalloc(current.elements.size());
		for( size_t i =0; i < current.elements.size(); i++) {
			frame->e[i].x = (int)((current.elements[i].pos.x-last.elements[i].pos.x)*mult_x_for_int);
			frame->e[i].y = (int)((current.elements[i].pos.y-last.elements[i].pos.y)*mult_y_for_int);
			frame->e[i].r = (int)((current.elements[i].angle-last.elements[i].angle)*mult_r_for_int);
		}
		
		frames.push_back(frame);
		last = current;
	}
	
	position = current.pos;
	
	time += dt;
	
	return true;
}
bool Replay::stopRecord() {
	if( !is_record) {
		return false;
	}
	
	is_record = false;
	time = 0;
	
	return true;
}


//////////////////////////PLAY
bool Replay::play(PhysicAuto* change_auto,float replay_speed) {
	if( is_play || is_record || 0x0 == change_auto) {
		return false;
	}
	
	std::vector<AutoElement*> elements = getElements(change_auto);
	if( begin.elements.size() != elements.size()) {
		return false;///this auto don't equal auto in replay
	}
	
	is_play = true;
	time = 0;
	this->replay_speed = replay_speed;
	
	begin.pointer = change_auto;
	change_auto->setPosition(ccp(begin.pos.x,begin.pos.y));
	
	for( size_t i =0; i < elements.size(); i++) {
		begin.elements[i].pointer = elements[i];
		elements[i]->setPosition(begin.elements[i].pos);
		elements[i]->setRotation(begin.elements[i].angle);
	}
	current = begin;
	
	return true;
}
bool Replay::tickPlay(float dt) {
	if( !is_play) {
		return false;
	}
	float local_fps = fps*replay_speed;
	
	size_t last_frame = ((int)((time)*local_fps));
	size_t new_frame = ((int)((time+dt)*local_fps));
	if ( new_frame >= frames.size()) {
		current.pointer->setPosition(current.pos);
		for( size_t j = 0; j < current.elements.size(); j++) {
			current.elements[j].pointer->setPosition(current.elements[j].pos);
			current.elements[j].pointer->setRotation(current.elements[j].angle);
		}
		return false;
	}
	
	if( last_frame != new_frame) {
		for( size_t i = last_frame; i <new_frame; i++) {
			current.pos.x += ((float)frames[i]->a.x)/mult_x_for_int;
			current.pos.y += ((float)frames[i]->a.y)/mult_y_for_int;
			for( size_t j = 0; j < frames[i]->c; j++) {
				const ElementFrame& frame = frames[i]->e[j];
				current.elements[j].pos.x += ((float)frame.x)/mult_x_for_int;
				current.elements[j].pos.y += ((float)frame.y)/mult_y_for_int;
				current.elements[j].angle += ((float)frame.r)/mult_r_for_int;
			}
		}
		last_frame = new_frame-1;
	}
	
	float procent = (time+dt)*((float)local_fps) - (float)new_frame;
	
	float x = current.pos.x + ((float)frames[new_frame]->a.x)*procent/mult_x_for_int;
	float y = current.pos.y + ((float)frames[new_frame]->a.y)*procent/mult_y_for_int;
	float r = 0;
	current.pointer->setPosition(ccp(x,y));
	
	for( size_t j = 0; j < frames[new_frame]->c; j++) {
		const ElementFrame& frame = frames[new_frame]->e[j];
		const BeginElementFrame& bframe = current.elements[j];
		x = bframe.pos.x + ((float)frame.x)*procent/mult_x_for_int;
		y = bframe.pos.y + ((float)frame.y)*procent/mult_y_for_int;
		r = bframe.angle + ((float)frame.r)*procent/mult_r_for_int;
		
		bframe.pointer->setPosition(ccp(x,y));
		bframe.pointer->setRotation(r);
	}
	
	time += dt;
	
	return true;
}
bool Replay::stop() {
	if( !is_play) {
		return false;
	}
	
	is_play = false;
	time = 0;
	
	return true;
}


static void writePoint(const CCPoint& point,FILE* f,float x_m,float y_m) {
	CCPoint pos = point;
	pos.x *= x_m;
	pos.y *= y_m;
	fwrite(&pos, 1, sizeof(CCPoint), f);
}
static void readPoint(CCPoint& point,FILE* f,float x_m,float y_m) {
	fread(&point, 1, sizeof(CCPoint), f);
	point.x /= x_m;
	point.y /= y_m;
}

//////////////////////////FILE OPERATION
bool Replay::save(std::string name) {
	std::string path = CCFileUtils::sharedFileUtils()->getWriteablePath()+"/"+name;
	FILE* file = fopen(path.c_str(), "wb");
	
	if( 0x0 == file) {
		return false;
	}
	
	writePoint(position,file,mult_x_for_int,mult_y_for_int);
	writePoint(begin.pos,file,mult_x_for_int,mult_y_for_int);
	
	size_t count = begin.elements.size();
	fwrite(&count, 1, sizeof(size_t), file);
	for( size_t i =0; i < count; i++) {
		writePoint(begin.elements[i].pos,file,mult_x_for_int,mult_y_for_int);
		fwrite(&begin.elements[i].angle, 1, sizeof(float), file);
	}
	
	count = frames.size();
	fwrite(&count, 1, sizeof(size_t), file);
	for( size_t i =0; i < count; i++) {
		fwrite(&frames[i]->a, 1, sizeof(AutoFrame), file);
		fwrite(&frames[i]->c, 1, sizeof(unsigned char), file);
		for( size_t j =0; j < frames[i]->c; j++) {
			fwrite(&frames[i]->e[j], 1, sizeof(ElementFrame), file);
		}
	}
	fclose(file);
	return true;
}
bool Replay::load(std::string name) {
	std::string path = CCFileUtils::sharedFileUtils()->getWriteablePath()+"/"+name;
	FILE* file = fopen(path.c_str(), "rb");
	
	if( 0x0 == file) {
		return false;
	}
	
	readPoint(position,file,mult_x_for_int,mult_y_for_int);
	readPoint(begin.pos,file,mult_x_for_int,mult_y_for_int);
	
	size_t count = 0;
	fread(&count, 1, sizeof(size_t), file);
	begin.elements.resize(count);
	for( size_t i =0; i < count; i++) {
		readPoint(begin.elements[i].pos,file,mult_x_for_int,mult_y_for_int);
		fread(&begin.elements[i].angle, 1, sizeof(float), file);
	}
	
	clearFrames();
	fread(&count, 1, sizeof(size_t), file);
	frames.resize(count);
	for( size_t i =0; i < count; i++) {
		frames[i] = new Frame();
		fread(&frames[i]->a, 1, sizeof(AutoFrame), file);
		fread(&frames[i]->c, 1, sizeof(unsigned char), file);
		frames[i]->fMalloc(frames[i]->c);
		for( size_t j =0; j < frames[i]->c; j++) {
			fread(&frames[i]->e[j], 1, sizeof(ElementFrame), file);
		}
	}
	fclose(file);
	
	return true;
}


//////////////////////////DESTROY
Replay::~Replay() {
	stopRecord();
	stop();
	
	clearFrames();
	time =  0;
}

void Replay::clearFrames() {
	for( size_t i =0; i < frames.size(); i++) {
		delete frames[i];
	}
	frames.clear();
}

//////////////////////////INTERPOLATION
bool Replay::interpolation(float time,float dt,BeginAutoFrame& use,size_t index) {
	int delta = ((int)((time+dt)*fps)) - ((int)(time*fps));
	if( delta <= index) {
		return false;
	}
	
	float end_time = ((int)((time+dt)*fps))/(float)fps;
	
	float procent_sub = ((time+dt)-end_time)*fps;
	float procent_full = 1-procent_sub;
	float procent = 1- ((procent_full*(index+1))/(float)delta);
		
	CCPoint translate = use.pointer->getPosition();
	translate = ccpMult(ccpSub(translate, use.pos),procent);
	
	use.pos = ccpSub(use.pointer->getPosition(), translate);
	
	std::vector<AutoElement*> elements = getElements(use.pointer);
	
	for( size_t i =0; i < elements.size(); i++) {
		CCPoint translate = elements[i]->getPosition();
		translate = ccpMult(ccpSub(translate, use.elements[i].pos),procent);
		
		use.elements[i].pos = ccpSub(elements[i]->getPosition(), translate);
		use.elements[i].angle = elements[i]->getRotation() - ((elements[i]->getRotation()-use.elements[i].angle)*procent);
	}
	
	return true;
}

std::vector<AutoElement*> Replay::getElements(PhysicAuto* node) {
	std::vector<AutoElement*> result;
	CCObject* obj = 0x0;
	CCARRAY_FOREACH(node->getChildren(), obj) {
		result.push_back((AutoElement*)obj);
	}
	
	return result;
}
