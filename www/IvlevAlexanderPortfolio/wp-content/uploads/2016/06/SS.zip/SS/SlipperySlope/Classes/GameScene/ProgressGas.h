//
//  ProgressGas.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 29.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_PROGRESS_GAS_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_PROGRESS_GAS_H_

#include "PhysicAuto.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class ProgressGas: public cocos2d::CCLayer {
		private:
			PhysicAuto* self_auto;
			cocos2d::CCSprite* progress;
			cocos2d::CCPoint progress_offset;
			cocos2d::CCRect progress_rect;
		private:
			ProgressGas():self_auto(0x0),progress(0x0) {}
		public:
			static ProgressGas* create(PhysicAuto* self_auto);
			bool init(PhysicAuto* self_auto);
			
		private:
			virtual void update(float dt);
		};
	};
};

#endif