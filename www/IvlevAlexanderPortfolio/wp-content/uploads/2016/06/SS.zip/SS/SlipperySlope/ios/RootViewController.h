//
//  SlipperySlopeAppController.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
