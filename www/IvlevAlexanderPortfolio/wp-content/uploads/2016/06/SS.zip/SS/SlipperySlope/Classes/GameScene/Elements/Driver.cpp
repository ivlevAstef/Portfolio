//
//  Drivers.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#include "Driver.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

Driver::Driver(std::string name) {
	this->name = name;
	z_order = -1;
	body = 0x0;
	
	ScaleCCSprite* image = ScaleCCSprite::createFN(name+".png");
	CCSize size = image->getContentSize();
	
	this->addChild(image,-1);
	this->setContentSize(size);
	
	loadMountingFromFile();
}

AutoElement* Driver::createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale) {
	Driver* copy = (Driver*)createCopy(translate,scale);
	copy->loadBodyFromFile(world);
	
	return copy;
}

AutoElement* Driver::createCopy(cocos2d::CCPoint translate,float scale) {
	Driver* copy = new Driver(name);
	copy->setPosition(ccpAdd(translate,ccpMult(this->getPosition(),scale)));
	copy->setScaleX(this->getScaleX()*scale);
	copy->setScaleY(scale);
	copy->setRotation(this->getRotation());
	copy->type = this->type;
	copy->autorelease();
	
	return copy;
}


void Driver::visit3dView(float auto_angle) {
}