//
//  MyLogFunction.h
//  SlipperSlope
//
//  Created by Alexander Ivlev on 12.04.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_ALL_LOG_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_ALL_LOG_H_

#include <stdio.h>

namespace GrizzlyJr {
	void NormalLog(const char * pszFormat, ...);
};

#endif
