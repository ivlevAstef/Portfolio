//
//  FadeOnAllChilds.h
//  SlipperSlope
//
//  Created by Alexander Ivlev on 04.10.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef _GRIZZLY_JR_MULTI_ANIMATE_H_
#define _GRIZZLY_JR_MULTI_ANIMATE_H_

#include "cocos2d.h"
#include <map>

namespace GrizzlyJr
{
	class FadeOnAllChilds: public cocos2d::CCActionInterval
	{
	private:
		bool isReverse;
	public:
		/** initializes the action with duration and opacity */
		bool initWithDuration(float duration, GLubyte opacity);
		bool initWithDuration(float duration, GLubyte opacity,bool isReverse);
		
		virtual cocos2d::CCObject* copyWithZone(cocos2d::CCZone* pZone);
		virtual void startWithTarget(cocos2d::CCNode* pTarget);
		virtual void update(float time);
		
	public:
		/** creates an action with duration and opacity */
		static FadeOnAllChilds* create(float duration, GLubyte opacity);
		static FadeOnAllChilds* create(float duration, GLubyte opacity,bool isReverse);
		
		
		static void setAllOpacityOnNode(cocos2d::CCNode* node, GLubyte opacity);
	protected:
		GLubyte m_toOpacity;
		std::map<cocos2d::CCNode*,GLubyte> m_fromOpacity;
	};
};

#endif
