#ifndef _GRIZZLY_JR_ANIMATED_SPRITE_H_
#define _GRIZZLY_JR_ANIMATED_SPRITE_H_

#include <string>
#include "cocos2d.h"
#include <map>
#include <vector>
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>

namespace GrizzlyJr
{
	class AnimatedSprite: public cocos2d::CCNode, public cocos2d::CCRGBAProtocol
	{
	public:
		static const unsigned int animatedSpriteTag;
	private:
		struct MapInformation {
			cocos2d::CCAnimation* anim;
			std::string sound;
			float soundLength;
			
			MapInformation():anim(0x0),sound(""),soundLength(0) {}
		};
		struct VectorInformation {
			float change;
			std::string name;
			VectorInformation():change(0),name("") {}
		};
		
		std::map<std::string, MapInformation> info;
		std::vector<VectorInformation> probability;
		float fullChange;
		
		unsigned int countNames;
	
	protected:
		std::vector<ScaleCCSprite*> sprites;
		std::map<std::string,int> postfixSave;
		std::string postfixAllName;
		
		bool bIsFlipX;
		bool bIsFlipY;
		
		cocos2d::ccColor3B color;
		GLubyte opacity;
	public:
		static AnimatedSprite* node(std::string mapName);
		AnimatedSprite();
		
		AnimatedSprite(std::string mapName);
		
		static AnimatedSprite* node(std::string mapName, std::string* postfix, unsigned int count);
		AnimatedSprite(std::string mapName, std::string* postfix, unsigned int count);
		static AnimatedSprite* node(std::string mapName, std::vector<std::string> postfixs);
		AnimatedSprite(std::string mapName, std::vector<std::string> postfixs);
		
		cocos2d::CCActionInterval* getAnimate(std::string name);
		cocos2d::CCActionInterval* run(std::string name);
		cocos2d::CCActionInterval* runForever(std::string name);
		cocos2d::CCActionInterval* runStop(std::string name);
		cocos2d::CCActionInterval* runRemove(std::string name);
		cocos2d::CCActionInterval* runCall(std::string name, CCObject* pSelectorTarget, cocos2d::SEL_CallFunc selector);
		cocos2d::CCActionInterval* runCallStop(std::string name, CCObject* pSelectorTarget, cocos2d::SEL_CallFunc selector);
		cocos2d::CCActionInterval* runProbability();
		
		void setBeginSprite(std::string name);
		
		inline const std::vector<ScaleCCSprite*>& getSprites()const { return sprites; }
		
		void runProbabilityNotResult();
		
		void setFlipX(bool bFlipX);
		void setFlipY(bool bFlipY);
		bool isFlipX();
		bool isFlipY();
		
		virtual CCRGBAProtocol* convertToRGBAProtocol() { return (CCRGBAProtocol *)this; }
		
		virtual void setColor(const cocos2d::ccColor3B& color);
		virtual const cocos2d::ccColor3B& getColor(void);
		virtual GLubyte getOpacity(void);
		virtual void setOpacity(GLubyte opacity);
		
		void setOpacity(GLubyte opacity, unsigned int number);
		void setColor(const cocos2d::ccColor3B&, unsigned int number);
		const cocos2d::ccColor3B& getColor(unsigned int number);
		
		bool isFindPostfix(std::string postfix);
		int getPostfixIndex(std::string postfix);
		void replacePostfix(std::string lastPost, std::string newPost);
		
		void setBlendFunc(cocos2d::ccBlendFunc func);
		
		void setOpacity(GLubyte opacity, std::string postfix);
		void setColor(const cocos2d::ccColor3B&, std::string postfix);
		const cocos2d::ccColor3B& getColor(std::string postfix);
		
		void setSizeOnTexture(cocos2d::CCPoint addOrigin,cocos2d::CCSize size, bool scalex2ifNeed);
		
		virtual ~AnimatedSprite();

		void init(std::string mapName,std::string* postfix, unsigned int count);
		
		virtual void setOpacityModifyRGB(bool) {}
		virtual bool isOpacityModifyRGB(void) { return true; }
		
		virtual void setShaderProgram(cocos2d::CCGLProgram* var);
		
	private:
		std::string getFullNameSprite(std::string name,std::string postfix);
	};
};
#endif
