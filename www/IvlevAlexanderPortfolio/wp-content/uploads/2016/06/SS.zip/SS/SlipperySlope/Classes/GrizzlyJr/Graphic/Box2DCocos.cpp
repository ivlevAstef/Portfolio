//
//  Box2DCocos.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.06.13.
//
//

#include "Box2DCocos.h"

using namespace GrizzlyJr;
USING_NS_CC;

float Box2DCocos::PTM_RATIO_X = 1;
float Box2DCocos::PTM_RATIO_Y = 1;
float Box2DCocos::default_constant = 100;

void Box2DCocos::init() {
	CCSize win_size = CCDirector::sharedDirector()->getWinSize();
	PTM_RATIO_X = default_constant*(win_size.height/768.0f);
	PTM_RATIO_Y = PTM_RATIO_X;
}