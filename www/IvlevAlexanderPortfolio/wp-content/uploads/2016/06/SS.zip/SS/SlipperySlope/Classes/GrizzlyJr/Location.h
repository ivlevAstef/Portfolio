//
//  LocationNew.h
//  SlipperSlope
//
//  Created by Alexander Ivlev on 07.08.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_LOCATION_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_LOCATION_H_

#include "cocos2d.h"
#include "FIOM/FIOMNode.h"

#include <string>
#include <map>


namespace GrizzlyJr
{
	class Location: public FIOMNode
	{
	public:
		enum TypeChangeSize {
			CHANGE_X,
			CHANGE_Y,
			CHANGE_NORMAL,
			CHANGE_REVERSE_NORMAL
		};
	private:
		static std::map<std::string,cocos2d::CCSize> devicesInfo;
		static std::vector<std::string> devicePriority;
		static cocos2d::CCSize deviceSize;
		
		std::string deviceFrom;
	public:
		static void init();
		static std::vector<std::string> getDevicePriority(cocos2d::CCSize winSize);
		
		static Location get(const char* name);
		static Location get(std::string name);
		
		Location(FIOMMain::NodeFileImage* node);
		Location(const FIOMNode& node);
		
		Location operator[](const char* name)const;
		Location operator[](std::string name)const;
		Location operator[](unsigned int number)const;
		
#define GET_CREATE(TYPE,TYPE_NAME) \
		TYPE get##TYPE_NAME(std::string name); \
		TYPE get##TYPE_NAME(unsigned int name); \
		TYPE get##TYPE_NAME(const char* name); \
		TYPE get##TYPE_NAME(std::string name,TypeChangeSize typeChange); \
		TYPE get##TYPE_NAME(unsigned int name,TypeChangeSize typeChange); \
		TYPE get##TYPE_NAME(const char* name,TypeChangeSize typeChange); \
		TYPE get##TYPE_NAME(std::string name,cocos2d::CCNode* node); \
		TYPE get##TYPE_NAME(unsigned int name,cocos2d::CCNode* node); \
		TYPE get##TYPE_NAME(const char* name,cocos2d::CCNode* node); \
		TYPE get##TYPE_NAME(std::string name,TypeChangeSize typeChange,cocos2d::CCNode* node); \
		TYPE get##TYPE_NAME(unsigned int name,TypeChangeSize typeChange,cocos2d::CCNode* node); \
		TYPE get##TYPE_NAME(const char* name,TypeChangeSize typeChange,cocos2d::CCNode* node); \
		
		GET_CREATE(float,LFloat)
		GET_CREATE(cocos2d::CCPoint,LPoint)
		GET_CREATE(cocos2d::CCSize,LSize)
		GET_CREATE(cocos2d::CCRect,LRect)
		
	private:
		Location(FIOMMain::NodeFileImage* node,std::string deviceFrom);
		
		void setDeviceFrom(std::string deviceFrom);
		
		float translateFloatOnCurrentDevice(float value,TypeChangeSize typeChange);
		float getValueFromStringUseNode(std::string term,TypeChangeSize typeChange,cocos2d::CCNode* ccnode);
		float parseTermUseNode(std::string term, TypeChangeSize typeChange, cocos2d::CCNode* ccnode);
	};
};

#endif

