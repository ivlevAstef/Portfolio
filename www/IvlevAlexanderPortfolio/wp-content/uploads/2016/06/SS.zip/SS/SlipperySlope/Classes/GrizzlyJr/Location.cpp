//
//  LocationNew.cpp
//  SlipperSlope
//
//  Created by Alexander Ivlev on 07.08.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "Location.h"
#include "WinSizeInfo.h"
#include "Log/LogFunction.h"

#include <Config/Config.h>

using namespace GrizzlyJr;
using namespace cocos2d;

static char* itoa(unsigned int value) {
	static char result[128] = {0};
	
	char* ptr = result;
	char* ptr1 = result;
	char tmp_char = 0x0;
	unsigned int tmp_value = 0;
	
	do {
		tmp_value = value;
		value /= 10;
		*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value*10)];
	} while ( value );
	
	///REVERSE
	*ptr-- = '\0';
	while(ptr1 < ptr) {
		tmp_char = *ptr;
		*ptr--= *ptr1;
		*ptr1++ = tmp_char;
	}
	return result;
}

std::map<std::string,CCSize> Location::devicesInfo;
std::vector<std::string> Location::devicePriority;
cocos2d::CCSize Location::deviceSize;

void Location::init() {
	static bool isFirst = false;
	
	if( !isFirst) {
		devicesInfo = WinSizeInfo::win_size_names;
	
		deviceSize = CCDirector::sharedDirector()->getWinSize();
	
		devicePriority = getDevicePriority(deviceSize);
		isFirst = true;
	}
}

std::vector<std::string> Location::getDevicePriority(cocos2d::CCSize winSize)
{
	std::vector<std::string> result;
	std::vector<std::string> temp_names = WinSizeInfo::win_size_names_array;
	
	NormalLog("WINSIZE=%f,%f",winSize.width,winSize.height);
	while(temp_names.size() > 0){
		float minPriority = 9999999.9f;
		unsigned int index = 0;
		for( unsigned int i =0; i < temp_names.size(); i++) {
			CCSize size = WinSizeInfo::win_size_names[temp_names[i]];
			float rx = fabs(size.width- winSize.width);
			float ry = fabs(size.height- winSize.height);
			float priority = MAX(rx,ry);
			
			if( 0 == ((int)size.width)%((int)winSize.width) &&
			    0 == ((int)size.height)%((int)winSize.height) ) {
				priority = MIN(priority, 1);
			} else if( 0 == ((int)winSize.width)%((int)size.width) &&
			    0 == ((int)winSize.height)%((int)size.height) ) {
				priority = MIN(priority, 1);
			} else if( 0 == ((int)winSize.height)%((int)size.height) ) {
				float mult = winSize.height/size.height;
				rx = fabs(size.width*mult - winSize.width);
				priority = (rx+mult)/2;
			}else if( 0 == ((int)size.height)%((int)winSize.height) ) {
				float mult = size.height/winSize.height;
				rx = fabs(size.width*mult - winSize.width);
				priority = (rx+mult)/2;
			}
			
			if( priority < minPriority) {
				minPriority = priority;
				index = i;
			}
		}
		
		NormalLog("PR%d =%s",result.size()+1,temp_names[index].c_str());
		
		result.push_back(temp_names[index]);
		temp_names.erase(temp_names.begin()+index);
	}
	return result;
}


Location Location::get(const char* name) {
	return Location(FIOMMain::get()->getRoot(name));
}

Location Location::get(std::string name) {
	return Location(FIOMMain::get()->getRoot(name.c_str()));
}

Location::Location(FIOMMain::NodeFileImage* node):FIOMNode(node) {
	Location::init();
}

Location::Location(const FIOMNode& node):FIOMNode(node) {
	Location::init();
}

Location Location::operator[](const char* name)const {
	if( !isCorrect() || 0x0 == name) {
		return *this;
	}
	
	Location result = FIOMNode::operator[](name);
	result.deviceFrom = this->deviceFrom;
	std::map<std::string,FIOMMain::NodeFileImage>::iterator find;
	while (result.isCorrect()&&result.isSpecial()) {
		bool isFind = false;
		for( size_t i =0; i < devicePriority.size(); i++) {
			find = result.node->dirs.find(devicePriority[i]);
			if( find != result.node->dirs.end()) {
				result = Location(&find->second,devicePriority[i]);
				isFind = true;
				break;
			}
		}
		if( !isFind) {
			break;
		}
	}
	
	return result;
}

Location Location::operator[](std::string name)const {
	return this->operator[](name.c_str());
}

Location Location::operator[](unsigned int number)const {
	return this->operator[](itoa(number));
}

float Location::getLFloat(const char* name,TypeChangeSize typeChange,cocos2d::CCNode* ccnode) {
	if( !isCorrect() || 0x0 == name) {
		return 0;
	}
	
	std::map<std::string,std::string>::iterator find = node->values.find(name);
	if( find == node->values.end()) {
		Location result = this->FIOMNode::operator[](name);
		if( result.isCorrect() && result.isSpecial() ) {
			for( size_t i =0; i < devicePriority.size(); i++) {
				find = result.node->values.find(devicePriority[i]);
				if( find != result.node->values.end()) {
					deviceFrom = devicePriority[i];
					return parseTermUseNode(find->second,typeChange,ccnode);
				}
			}
		}
		return 0;
	}
	
	return parseTermUseNode(find->second,typeChange,ccnode);
}

CCPoint Location::getLPoint(const char* name,TypeChangeSize typeChange,cocos2d::CCNode* ccnode) {
	Location node = this->operator[](name);
	return ccp(node.getLFloat("x",typeChange,ccnode),node.getLFloat("y",typeChange,ccnode));
}

CCSize Location::getLSize(const char* name,TypeChangeSize typeChange,cocos2d::CCNode* ccnode) {
	Location node = this->operator[](name);
	return CCSize(node.getLFloat("width",typeChange,ccnode),node.getLFloat("height",typeChange,ccnode));
}

CCRect Location::getLRect(const char* name,TypeChangeSize typeChange,cocos2d::CCNode* ccnode) {
	Location node = this->operator[](name);
	return CCRect(node.getLFloat("x",typeChange,ccnode),node.getLFloat("y",typeChange,ccnode),
				  node.getLFloat("width",typeChange,ccnode),node.getLFloat("height",typeChange,ccnode));
}

Location::Location(FIOMMain::NodeFileImage* node,std::string deviceFrom):FIOMNode(node) {
	setDeviceFrom(deviceFrom);
}

void Location::setDeviceFrom(std::string deviceFrom) {
	this->deviceFrom = deviceFrom;
}

float Location::translateFloatOnCurrentDevice(float value,TypeChangeSize typeChange) {
	if( "" == deviceFrom) {
		return value;
	}
	
	CCSize deviceFromSize = devicesInfo[deviceFrom];
	
	if( typeChange == CHANGE_X || typeChange == CHANGE_REVERSE_NORMAL) {
		value *= deviceSize.width/deviceFromSize.width;
	}
	if( typeChange == CHANGE_Y || typeChange == CHANGE_NORMAL) {
		value *= deviceSize.height/deviceFromSize.height;
	}
	
	return value;
}

float Location::getValueFromStringUseNode(std::string term,TypeChangeSize typeChange,CCNode* ccnode) {
	if( 0 == term.size()) {
		return 0;
	}
	
	float scale_factor = 1.0f;
	if( Config::c->isRetina) {
		scale_factor = 0.5f;
	}
	
	if( "w" == term) {
		return deviceSize.width;
	} else if( "h" == term) {
		return deviceSize.height;
	}else if( "wc" == term) {
		return deviceSize.width/2;
	}else if( "hc" == term) {
		return deviceSize.height/2;
	}
	
	if( 0x0 != ccnode) {	
		if( "sw" == term) {
			return ccnode->getContentSize().width*scale_factor;
		}
		if( "sh" == term) {
			return ccnode->getContentSize().height*scale_factor;
		}
		if( "swc" == term) {
			return ccnode->getContentSize().width*scale_factor/2;
		}
		if( "shc" == term) {
			return ccnode->getContentSize().height*scale_factor/2;
		}
	}
	
	
	if( 'c' ==term.c_str()[0]) {
		float localValue =0;
		sscanf(term.c_str(), "c%f",&localValue);
		return localValue;
	}
	
	float localValue =0;
	sscanf(term.c_str(), "%f",&localValue);
	return translateFloatOnCurrentDevice(localValue, typeChange);
}

float Location::parseTermUseNode(std::string term, TypeChangeSize typeChange, CCNode* ccnode) {
	const unsigned int countSymbols = 4;
	const char symbols[countSymbols] = {'-','+','*','/'};
	
	float result = 0;
	char lastSymbol = 0;
	char currentSymbol = 0;
	do {
		unsigned int minPos = term.size();
		for( unsigned int i = 0; i < countSymbols; i++) {
			unsigned int pos = term.find(symbols[i]);
			if(pos < minPos) {
				minPos = pos;
				currentSymbol = symbols[i];
			}
		}
		
		if( minPos <= term.size()) {
			std::string name = term.substr(0,minPos);
			
			float localValue =getValueFromStringUseNode(name,typeChange,ccnode);				
			
			switch(lastSymbol) {
				case '-':result -= localValue;break;
				case '+':result += localValue;break;
				case '/':result /= localValue;break;
				case '*':result *= localValue;break;
				case 0: result = localValue; break;
			}
			
			if( minPos >= term.size()) {
				break;
			}
			
			term = term.substr(minPos+1);
			lastSymbol = currentSymbol;
			continue;
		}
		
		break;
	} while (true);
	
	return result;
}

#define GET_INIT(TYPE,TYPE_PREFIX) \
TYPE Location::get##TYPE_PREFIX(std::string name) { \
return this->get##TYPE_PREFIX(name.c_str()); \
} \
TYPE Location::get##TYPE_PREFIX(unsigned int number) { \
return this->get##TYPE_PREFIX(itoa(number)); \
} \
TYPE Location::get##TYPE_PREFIX(std::string name,TypeChangeSize typeChange) { \
	return this->get##TYPE_PREFIX(name.c_str(),typeChange,0x0); \
} \
TYPE Location::get##TYPE_PREFIX(unsigned int number,TypeChangeSize typeChange) { \
	return this->get##TYPE_PREFIX(itoa(number),typeChange,0x0); \
} \
TYPE Location::get##TYPE_PREFIX(std::string name,cocos2d::CCNode* node) { \
	return this->get##TYPE_PREFIX(name.c_str(),node); \
} \
TYPE Location::get##TYPE_PREFIX(unsigned int number,cocos2d::CCNode* node) { \
	return this->get##TYPE_PREFIX(itoa(number),node); \
} \
TYPE Location::get##TYPE_PREFIX(const char* name,TypeChangeSize typeChange) { \
	return this->get##TYPE_PREFIX(name,typeChange,0x0); \
}

GET_INIT(float,LFloat)
GET_INIT(cocos2d::CCPoint,LPoint)
GET_INIT(cocos2d::CCSize,LSize)
GET_INIT(cocos2d::CCRect,LRect)


float Location::getLFloat(const char* name) {
	return getLFloat(name,CHANGE_NORMAL,0x0);
}
CCPoint Location::getLPoint(const char* name) {
	Location node = this->operator[](name);
	return ccp(node.getLFloat("x",CHANGE_X,0x0),node.getLFloat("y",CHANGE_Y,0x0));
}
CCSize Location::getLSize(const char* name) {
	Location node = this->operator[](name);
	return CCSize(node.getLFloat("width",CHANGE_X,0x0),node.getLFloat("height",CHANGE_Y,0x0));
}
CCRect Location::getLRect(const char* name) {
	Location node = this->operator[](name);
	return CCRect(node.getLFloat("x",CHANGE_X,0x0),node.getLFloat("y",CHANGE_Y,0x0),
				  node.getLFloat("width",CHANGE_X,0x0),node.getLFloat("height",CHANGE_Y,0x0));
}


float Location::getLFloat(const char* name,cocos2d::CCNode* ccnode) {
	return getLFloat(name,CHANGE_NORMAL,ccnode);
}
CCPoint Location::getLPoint(const char* name,cocos2d::CCNode* ccnode) {
	Location node = this->operator[](name);
	return ccp(node.getLFloat("x",CHANGE_X,ccnode),node.getLFloat("y",CHANGE_Y,ccnode));
}
CCSize Location::getLSize(const char* name,cocos2d::CCNode* ccnode) {
	Location node = this->operator[](name);
	return CCSize(node.getLFloat("width",CHANGE_X,ccnode),node.getLFloat("height",CHANGE_Y,ccnode));
}
CCRect Location::getLRect(const char* name,cocos2d::CCNode* ccnode) {
	Location node = this->operator[](name);
	return CCRect(node.getLFloat("x",CHANGE_X,ccnode),node.getLFloat("y",CHANGE_Y,ccnode),
				  node.getLFloat("width",CHANGE_X,ccnode),node.getLFloat("height",CHANGE_Y,ccnode));
}

