//
//  AutoElement.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 28.05.13.
//
//

#include "AutoElement.h"
#include <GrizzlyJr/Location.h>
#include <Config/Config.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

int AutoElement::grid_cell_size = 0;

void AutoElement::initGridCellSize() {
	grid_cell_size = Location::get("Positions")["Redactor"].getLFloat("grid_cell_size");
}

cocos2d::CCSprite* AutoElement::auto_point = 0x0;

void AutoElement::initAutoPoint(cocos2d::CCSprite* image) {
	auto_point = image;
	if( auto_point) {
		auto_point->retain();
	}
}

void AutoElement::flip() {
	setScaleX(-getScaleX());
}

void AutoElement::visit() {
	_3DElement::visit();
}

void AutoElement::draw() {
	CCNode::draw();
	
	if ( auto_point ) {
		for( size_t j =0; j < mount_points.size(); j++) {
			auto_point->setPosition(mount_points[j]);
			auto_point->visit();
		}
	}
}


void AutoElement::loadMountingFromFile() {
	FIOMNode element = FIOMNode::get("Elements")[name]["mount"];
	if( !element.isCorrect()) {
		return;
	}
	
	GTRANSLATE(element.getFloat("x"),element.getFloat("y"));
	
	FIOMNode points = element["points"];
	size_t count = points.getArraySize();
	if( 1 == count%2) {
		cocos2d::CCLog("ERROR: points count%2 == 1 in object %s",name.c_str());
	} else {
		for( unsigned int i =0; i < count; i+=2) {
			mount_points.push_back(GPOINT(points.getInt(i),points.getInt(i+1)));
		}
	}
}

float AutoElement::getParameter(std::string value) {
	return FIOMNode::get("Elements")[name].getFloat(value);
}

void AutoElement::loadBodyFromFile(b2World* world) {
	PhysicElement::loadBodyFromFile(world, name, this);
	updateImage();
}
