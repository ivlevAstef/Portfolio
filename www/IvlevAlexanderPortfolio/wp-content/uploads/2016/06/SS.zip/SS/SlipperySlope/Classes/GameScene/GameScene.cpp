//
//  GameScene.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.06.13.
//
//

#include "GameScene.h"

#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Graphic/Button.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>
#include <GrizzlyJr/SceneController/SceneController.h>
#include <GrizzlyJr/Gesture/GesturesController.h>
#include <GrizzlyJr/Location.h>

#include "ProgressGas.h"
#include <GrizzlyJr/Graphic/SlipEffect.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
using namespace cocos2d;



///cocos2d::CCPoint need;
///cocos2d::CCPoint current;
///PhysicAuto* self_auto;

void GameScene::CameraEffects::setAuto(PhysicAuto* self_auto,CCPoint translate) {
	this->self_auto = self_auto;
	this->auto_translate = translate;
	this->need = ccp(0,0);
	this->current = ccp(0,0);
	this->last_translate_len = 0;
}
void GameScene::CameraEffects::calc(float dt) {
	const CCSize w_size = CCDirector::sharedDirector()->getWinSize();
	float max_tr = MAX(w_size.height*0.013f,last_translate_len*0.25f);
	
	float x_tr = -self_auto->getSpeed().x*0.2f;
	
	float y = self_auto->convertToWorldSpace(ccp(0,0)).y;
	y += w_size.height*0.5f - auto_translate.y;
	float h_tr = -y;
	
	if( self_auto->getSpeed().y > 0) {
		h_tr -= self_auto->getSpeed().y*0.15f;
	}else {
		h_tr -= self_auto->getSpeed().y*0.4f;
	}
	h_tr = MIN(h_tr,0);
	
	need = ccp(x_tr, h_tr);
	
	CCPoint dir = ccpSub(need, current);
	float len = ccpLength(dir);
	if( len > max_tr) {
		dir = ccpMult(dir, max_tr/len);
		current = ccpAdd(current,dir);
	} else {
		current = need;
	}
	
	last_translate_len = len;
}

const cocos2d::CCPoint& GameScene::CameraEffects::get()const {
	return current;
}

CCScene* GameScene::scene(void* point) {
	CCScene *scene = CCScene::create();
	GameScene* layer = new GameScene();
	if( scene && layer && layer->init((Auto*)point)) {
		layer->autorelease();
		scene->addChild(layer);
		return scene;
	}
	CC_SAFE_DELETE(scene);
	CC_SAFE_DELETE(layer);
	return 0x0;
}

bool GameScene::init(Auto* image_auto) {
	if( !CCLayer::init() || 0x0 == image_auto) {
		return false;
	}
	
	this->image_auto = image_auto;
	line_size = Location::get("Positions")["GameScene"].getLPoint("line_size",Location::CHANGE_Y);
	
	GestureController::pause();
	
	CCDirector::sharedDirector()->getTouchDispatcher()->addStandardDelegate(this, 0);
	
	AutoElement::initAutoPoint(0x0);
	CCSize win_size = CCDirector::sharedDirector()->getWinSize();
	
	gravity = b2Vec2(0.0f, -9.8f);
	world = new b2World(gravity);
	world->SetAutoClearForces(false);
	
	time_click_run = 0;
	
	physic_translate.x = win_size.width*0.5f;
	physic_translate.y = win_size.height*0.58f;
	
	float auto_scale = Location::get("Positions")["GameScene"].getLFloat("auto_scale");
	enemy_auto = 0x0;
	
	this->self_auto = PhysicAuto::create(image_auto, world,auto_scale);
	this->self_auto->setTranslate(physic_translate);
	self_auto->initGas(500);
	self_auto->retain();
	
	progress_map = ProgressMap::create(self_auto);
	progress_map->setPosition(Location::get("Positions")["GameScene"].getLPoint("progress"));
	this->addChild(progress_map,100);
	
	texture_for_back = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("game-back.png")->getTexture();
	texture_for_way = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("game-way.png")->getTexture();
	texture_for_top = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("game-top.png")->getTexture();
	texture_for_snow = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("game-snow.png")->getTexture();
	texture_for_shadow = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("shadow.png")->getTexture();
	
	this->schedule(schedule_selector(GameScene::update));
	
	loadMap("Map");
	
	Button* redactor = Button::create("redactor-button-next.png", "redactor-button-next.png", this, menu_selector(GameScene::clickRedactor));
	redactor->setWorkingAllTime(true);
	redactor->setPosition(ccp(win_size.width*0.95f,win_size.height*0.95f));
	this->addChild(redactor,100);
	
	
	rotate_left = ScaleCCSprite::createFN("rotate.png");
	rotate_left->setFlipX(true);
	rotate_left->setPosition(ccp(win_size.width*0.08f,win_size.height*0.15f));
	this->addChild(rotate_left,100);
	
	rotate_right = ScaleCCSprite::createFN("rotate.png");
	rotate_right->setPosition(ccp(win_size.width*0.23f,win_size.height*0.15f));
	this->addChild(rotate_right,100);
	
	run_left = ScaleCCSprite::createFN("forward.png");
	run_left->setFlipX(true);
	run_left->setPosition(ccp(win_size.width*0.77f,win_size.height*0.15f));
	this->addChild(run_left,100);
	
	run_right = ScaleCCSprite::createFN("forward.png");
	run_right->setPosition(ccp(win_size.width*0.92f,win_size.height*0.15f));
	this->addChild(run_right,100);
	
	is_pause = false;
	touch_positions.clear();
	
	record_game.startRecord(self_auto);
	if( play_game.load("game1")) {
		Auto* enemy_auto_view = Auto::create(); enemy_auto_view->load("last_auto",image_auto->getLastGrid());
		enemy_auto = PhysicAuto::create(enemy_auto_view, auto_scale);
		enemy_auto->setTranslate(ccpAdd(physic_translate,ccp(-line_size.x,line_size.y*0.9f)));
		enemy_auto->retain();
		play_game.play(enemy_auto);
		
		progress_map->addAuto(enemy_auto);
		progress_map->addStaticPoint(play_game.getPosition());
	}
	
	ProgressGas* p_gas = ProgressGas::create(self_auto);
	p_gas->setPosition(Location::get("Positions")["GameScene"].getLPoint("progress-gas"));
	this->addChild(p_gas,100);
	
	camera_effect.setAuto(self_auto,physic_translate);
	
	
	slip_effects = CCNode::create();
	slip_effects->retain();
	
	return true;
}


void GameScene::loadMap(std::string map_name) {
	CCSize win_size = CCDirector::sharedDirector()->getWinSizeInPixels();
	
	b2BodyDef bodyDef;
	bodyDef.type = b2_staticBody;
	bodyDef.position.Set(0, 0);
	b2Body* body = world->CreateBody(&bodyDef);
	body->SetUserData(0x0);
	b2Vec2 size = Box2DCocos::convert(ccp(win_size.width,win_size.height));
	
	b2FixtureDef fixture;
	
	fixture.density = 1;
	fixture.friction = 1.0f;
	fixture.restitution = 0.1f;
	fixture.filter.categoryBits = 0x0004;
	fixture.filter.maskBits = 0x0002;
	
	FIOMMain::get()->loadFile("maps/"+map_name);
	FIOMNode map = FIOMNode::get(map_name.c_str());
	
	Location path = map["path"];
	size_t count = path.getArraySize();
	for( size_t i =0; i < count; i++) {
		CCPoint pos = path.getLPoint((unsigned int)i,Location::CHANGE_Y);
		b2Vec2 vpos = Box2DCocos::convert(pos);
		
		if( positions.size() >= 1) {
			b2Vec2 lpos = positions[positions.size()-1];
			int last_count = lpos.x/size.x;
			int current_count = vpos.x/size.x;
			for( size_t j = last_count; j < current_count; j++) {
				float new_x = (j+1)*size.x;
				float procent = (new_x-lpos.x)/(vpos.x-lpos.x);
				float new_y = (vpos.y-lpos.y)*procent + lpos.y;
				positions.push_back(b2Vec2(new_x,new_y));
			}
		}
		positions.push_back(vpos);
	}
	
	Location objs = map["objs"];
	count = objs.getArraySize();
	for( size_t i =0; i < count; i++) {
		ObjectOnMap obj;
		Location nobj = objs[i];
		obj.addSprite(nobj.getStr("name")+".png");
		obj.speed = nobj.getFloat("speed");
		obj.z_order = nobj.getInt("z_order");
		
		obj.sprite->setPosition(nobj.getLPoint("pos",Location::CHANGE_Y));
		obj.sprite->setScaleX(nobj["scale"].getFloat("x"));
		obj.sprite->setScaleY(nobj["scale"].getFloat("y"));
		obj.sprite->setFlipX(nobj["flip"].getBool("x"));
		obj.sprite->setFlipY(nobj["flip"].getBool("y"));
		obj.sprite->setRotation(CC_RADIANS_TO_DEGREES(nobj.getFloat("angle")));
		objects.push_back(obj);
	}
	
	Location pobjs = map["physic"];
	count = pobjs.getArraySize();
	for( size_t i =0; i < count; i++) {
		Location nobj = pobjs[i];
		Box* box = Box::create(nobj.getStr("name"));
		box->setPosition(ccpSub(nobj.getLPoint("pos",Location::CHANGE_Y),physic_translate));
		box->setScaleX(nobj["scale"].getFloat("x")*0.65f);
		box->setScaleY(nobj["scale"].getFloat("y")*0.65f);
		box->setFlipX(nobj["flip"].getBool("x"));
		box->setFlipY(nobj["flip"].getBool("y"));
		box->setRotation(CC_RADIANS_TO_DEGREES(nobj.getFloat("angle")));
		box->physicInit(world);
		box->retain();
		physics.push_back(box);
	}
	
	FIOMMain::get()->closeFile(map_name);
	
	if( positions.size() >= 2) {
		b2Vec2 trans = Box2DCocos::convert(physic_translate);
		for( size_t i =0; i < positions.size(); i++) {
			positions[i] -= trans;
		}
		
		b2EdgeShape shapeDef;
		b2Vec2 lpos = positions[1];
		progress_map->setBegin(Box2DCocos::convert(lpos));
		
		shapeDef.Set(b2Vec2(lpos.x,-size.y/2), b2Vec2(lpos.x, size.y*5));
		fixture.shape = &shapeDef;
		body->CreateFixture(&fixture);
	
		for( size_t i =1; i < positions.size(); i++) {
			b2Vec2 cpos = positions[i];
			shapeDef.Set(lpos, cpos);
			fixture.shape = &shapeDef;
			body->CreateFixture(&fixture);
			lpos = cpos;
		}
	
		lpos = positions[positions.size()-2];
		progress_map->setEnd(Box2DCocos::convert(lpos));
		shapeDef.Set(b2Vec2(lpos.x,-size.y/2), b2Vec2(lpos.x, size.y*5));
		fixture.shape = &shapeDef;
		body->CreateFixture(&fixture);
	}
}

void GameScene::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
		CCTouch* touch = (CCTouch*)(*iter);
		CCPoint pos = CCDirector::sharedDirector()->convertToGL(touch->locationInView());
		touch_positions.push_back(pos);
	}
	
}
void GameScene::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
		CCTouch* touch = (CCTouch*)(*iter);
		for( size_t j =0; j < touch_positions.size(); j++) {
			CCPoint l_pos = CCDirector::sharedDirector()->convertToGL(touch->previousLocationInView());
			CCPoint pos = CCDirector::sharedDirector()->convertToGL(touch->locationInView());
			if( ccpDistance(l_pos,touch_positions[j]) < 1) {
				touch_positions[j] = pos;
			}
		}
	}
}
void GameScene::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
		CCTouch* touch = (CCTouch*)(*iter);
		for( size_t j =0; j < touch_positions.size(); j++) {
			CCPoint l_pos = CCDirector::sharedDirector()->convertToGL(touch->previousLocationInView());
			if( ccpDistance(l_pos,touch_positions[j]) < 1) {
				touch_positions.erase(touch_positions.begin()+j);
				break;
			}
		}
	}
}
void GameScene::ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
		CCTouch* touch = (CCTouch*)(*iter);
		for( size_t j =0; j < touch_positions.size(); j++) {
			CCPoint l_pos = CCDirector::sharedDirector()->convertToGL(touch->previousLocationInView());
			if( ccpDistance(l_pos,touch_positions[j]) < 1) {
				touch_positions.erase(touch_positions.begin()+j);
				break;
			}
		}
	}	
}

void GameScene::clickRedactor(cocos2d::CCObject* obj) {
	record_game.stopRecord();
	record_game.save("game1");
	image_auto->save("last_auto", image_auto->getLastGrid());
	play_game.stop();
	
	is_pause = true;
	GestureController::resume();
	CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this);
	AutoElement::initAutoPoint(ScaleCCSprite::createFN("object-point-off.png"));
	SceneController::get()->pop();
}


static CCRect getRect(cocos2d::CCNode* node) {
	CCRect result;
	result.origin = node->getPosition();
	result.size = node->getContentSize();
	
	result.origin.x -= result.size.width*node->getAnchorPoint().x;
	result.origin.y -= result.size.height*node->getAnchorPoint().y;
	return result;
}

void GameScene::update(float dt) {
	if( is_pause) {
		return;
	}
	
	record_game.tickRecord(dt);
	play_game.tickPlay(dt);
	
	static size_t count = 4;
	CCRect rects[4] = {
		getRect(rotate_left),
		getRect(rotate_right),
		getRect(run_left),
		getRect(run_right)
	};
	ScaleCCSprite* sprites[4] = {
		rotate_left,
		rotate_right,
		run_left,
		run_right
	};
	std::pair<std::string, std::string> sprites_name[4] = {
		std::pair<std::string, std::string>("rotate.png","rotate-select.png"),
		std::pair<std::string, std::string>("rotate.png","rotate-select.png"),
		std::pair<std::string, std::string>("forward.png","forward-select.png"),
		std::pair<std::string, std::string>("forward.png","forward-select.png"),
	};
	
	float speed = 0;
	bool is_rotate = false;
	for( size_t j=0; j < count; j++) {
		std::string name = sprites_name[j].first;
		for( size_t i =0; i < touch_positions.size(); i++) {
			CCPoint pos = touch_positions[i];
			if( CCRect::CCRectContainsPoint(rects[j],pos)) {
				name = sprites_name[j].second;
				switch (j) {
					case 0:self_auto->rotateLeft(dt); is_rotate = true; break;
					case 1:self_auto->rotateRight(dt); is_rotate = true; break;
					case 2:speed++; break;
					case 3:speed--; break;
				}
			}
		}
		
		CCSpriteFrame* frame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name.c_str());
		if( !sprites[j]->isFrameDisplayed(frame)) {
			sprites[j]->setDisplayFrame(frame);
		}
	}
	
	if( ! is_rotate) {
		self_auto->stabilization(dt);
	}
	if( fabs(speed) >= 0.5f) {
		time_click_run += dt;
	} else {
		time_click_run = 0;
	}
	
	self_auto->setSpeed(speed,dt);
	
	stepWorld(dt);
	self_auto->update(dt);
	
	camera_effect.calc(dt);
		
	const CCPoint& cam_pos = camera_effect.get();
	self_auto->setTranslateX(physic_translate.x-self_auto->getPosition().x +cam_pos.x);
	self_auto->setTranslateY(physic_translate.y+ cam_pos.y);
	
	if( enemy_auto) {
		enemy_auto->setTranslateX(physic_translate.x -self_auto->getPosition().x-line_size.x +cam_pos.x);
		enemy_auto->setTranslateY(physic_translate.y + cam_pos.y + line_size.y*0.9f);
	}
	
	addSlipEffects(self_auto,dt,speed);
}

void GameScene::addSlipEffects(PhysicAuto* a,float dt,float sign_speed) {
	std::vector<PhysicAuto::ContactWheelInfo> contacts = a->getAllContactsWheel();
	CCSpriteFrame* smoke = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("particle-dust.png");
	CCSpriteFrame* stone = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("particle-stone.png");
	
	float max_speed = Location::get("Positions")["GameScene"].getLFloat("max_speed",Location::CHANGE_Y);
	
	for( size_t i = 0; i < contacts.size(); i++) {
		float len = ccpLength(contacts[i].speed);
		float angular_sign = (contacts[i].angular_speed>0)?1:-1;
		
		if( (fabs(contacts[i].angular_speed) > len*2.0f*1.15f || angular_sign != sign_speed) &&
			 time_click_run > 0 ){
			CCPoint speed = contacts[i].speed;
			float len = MIN(max_speed,fabs(contacts[i].angular_speed));
			speed = ccpMult(ccpNormalize(speed), len);
			SlipEffect* effect = SlipEffect::create(speed, smoke, stone);
			if( effect) {
				effect->setPosition(contacts[i].wpos);
				slip_effects->addChild(effect);
				
				cocos2d::CCLog("2ADD=%f,%f",contacts[i].wpos.x,contacts[i].wpos.y);
			}
		}
	}
	
	
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(slip_effects->getChildren(), iter) {
		iter->update(dt);
	}
}


void GameScene::stepWorld(float dt) {
	static const float32 FIXED_TIMESTEP = 1.0f / 30.0f;
	static const float32 MINIMUM_TIMESTEP = 1.0f / 300.0f;
	static const int32 VELOCITY_ITERATIONS = 12;
	static const int32 POSITION_ITERATIONS = 12;
	static const int32 MAXIMUM_NUMBER_OF_STEPS = 25;
	
	float32 frameTime = dt;
	int stepsPerformed = 0;
	while ( (frameTime > 0.0) && (stepsPerformed < MAXIMUM_NUMBER_OF_STEPS) ) {
		float32 deltaTime = std::min( frameTime, FIXED_TIMESTEP );
		frameTime -= deltaTime;
		if (frameTime < MINIMUM_TIMESTEP) {
			deltaTime += frameTime;
			frameTime = 0.0f;
		}
		world->Step(deltaTime,VELOCITY_ITERATIONS,POSITION_ITERATIONS);
		stepsPerformed++;
	}
	world->ClearForces();
	//world->Step(dt,12,12);
	//world->ClearForces();
}

static void drawLineWithTexture(const std::vector<std::pair<CCPoint*, CCPoint*> >& points, unsigned int texture,
								CCPoint origin,CCPoint size,
								int color1,int color2) {
	CCPoint pos = ccp(origin.x+ size.x,origin.y+ size.y);
	CCPoint arr[4] = {ccp(0,0)};
	cocos2d::ccColor4B color[4];
	for( size_t i =0; i < points.size(); i++) {
		size_t in = points.size()-i-1;
		arr[0] = ccpAdd(points[in].first[2], origin);
		arr[1] = ccpAdd(points[in].first[3], origin);
		arr[2] = ccpAdd(points[in].first[2], pos);
		arr[3] = ccpAdd(points[in].first[3], pos);
		color[0] = color[1] = ccc4(color1, color1, color1, 255);
		color[2] = color[3] = ccc4(color2, color2, color2, 255);
		
		ccDrawTexturePoly(arr,texture,points[in].second,color);
	}
}

void GameScene::draw() {
}

void GameScene::visibleObjects(int z_begin, int z_end) {
	CCSize wsize = CCDirector::sharedDirector()->getWinSize();
	
	for( size_t i =0; i< objects.size(); i++) {
		int z = objects[i].z_order;
		if( z < z_begin || z_end < z) {
			continue;
		}
		
		float translate = -self_auto->getPosition().x*objects[i].speed;
		CCPoint pos = objects[i].sprite->getPosition();
		CCSize size = objects[i].sprite->getContentSize();
		size.width *= objects[i].sprite->getScaleX();
		CCPoint wpos = ccpAdd(pos, ccp(translate,0));
		wpos = ccpAdd(wpos, camera_effect.get());
		
		if( wpos.x < -size.width || wpos.x > wsize.width+size.width) {
			continue;
		}
		
		objects[i].sprite->setPosition(wpos);
		objects[i].sprite->visit();
		objects[i].sprite->setPosition(pos);
	}
}

void GameScene::visiblePhysics() {
	CCSize wsize = CCDirector::sharedDirector()->getWinSize();
	std::vector<std::pair<CCPoint, Box*> > visible_objects;
	
	for( size_t i =0; i< physics.size(); i++) {
		physics[i]->updateImage();
		
		float translate = -self_auto->getPosition().x;
		CCPoint pos = physics[i]->getPosition();
		CCSize size = objects[i].sprite->getContentSize();
		size.width *= objects[i].sprite->getScaleX();
		CCPoint wpos = ccpAdd(pos, ccp(physic_translate.x+translate,physic_translate.y));
		wpos = ccpAdd(wpos, camera_effect.get());
		
		if( wpos.x < -size.width || wpos.x > wsize.width+size.width) {
			continue;
		}
		
		physics[i]->setPosition(wpos);
		visible_objects.push_back(std::pair<CCPoint, Box*>(pos,physics[i]));
	}
	
	for( size_t i =0; i< visible_objects.size(); i++) {
		visible_objects[i].second->visit3dView(0);
	}
	
	for( size_t i =0; i< visible_objects.size(); i++) {
		visible_objects[i].second->visit();
		visible_objects[i].second->setPosition(visible_objects[i].first);
	}
}

void GameScene::drawBack(float speed) {
	cocos2d::ccColor4B color[4] = {
		ccc4(255,255,255,255),
		ccc4(255,255,255,255),
		ccc4(255,255,255,255),
		ccc4(255,255,255,255)
	};
	
	unsigned int number = texture_for_back->getName();
	CCSize size = CCDirector::sharedDirector()->getWinSize();
	
	float procent = speed*self_auto->getPosition().x/size.width;
	procent -= ((int)procent);
	procent = 1-procent;
	
	CCPoint arrT[4] = {
		ccp(1,1),
		ccp(1-procent,1),
		ccp(1,0),
		ccp(1-procent,0)
	};
	CCPoint arr[4] = {
		ccp(size.width*procent,0),
		ccp(0,0),
		ccp(size.width*procent,size.height),
		ccp(0,size.height),
	};
	ccDrawTexturePoly(arr,number,arrT,color);
	
	CCPoint arrT2[4] = {
		ccp(1-procent,1),
		ccp(0,1),
		ccp(1-procent,0),
		ccp(0,0)
	};
	CCPoint arr2[4] = {
		ccp(size.width,0),
		ccp(size.width*procent,0),
		ccp(size.width,size.height),
		ccp(size.width*procent,size.height),
	};
	ccDrawTexturePoly(arr2,number,arrT2,color);
}

void GameScene::drawBackFrontTexture(std::vector<std::pair<CCPoint*, CCPoint*> >& points,unsigned int number, float mult) {
	cocos2d::ccColor4B color[4] = {
		ccc4(255,255,255,255),
		ccc4(255,255,255,255),
		ccc4(255,255,255,255),
		ccc4(255,255,255,255)
	};
	
	CCPoint arr[4] = {ccp(0,0)};
	for( size_t i =0; i < points.size(); i++) {
		for( size_t j =0; j < 2;j++) {
			arr[j].x = points[i].first[j].x;
			arr[j].y = points[i].first[j].y;
		}
		for( size_t j =2; j < 4;j++) {
			arr[j].x = points[i].first[j].x - line_size.x*mult;
			arr[j].y = points[i].first[j].y + line_size.y*mult;
		}
		
		ccDrawTexturePoly(arr,number,points[i].second,color);
	}
}

void GameScene::calcPoints(std::vector<std::pair<cocos2d::CCPoint*, cocos2d::CCPoint*> >& result) {
	CCSize wsize = CCDirector::sharedDirector()->getWinSize();
	
	for( size_t i =1; i < positions.size(); i++) {
		CCPoint lpos = Box2DCocos::convert(positions[i-1]);
		CCPoint pos = Box2DCocos::convert(positions[i]);
		
		CCPoint lposT = lpos;
		CCPoint posT = pos;
		lposT = ccpAdd(lposT, ccp(wsize.width*0.5f,wsize.height*0.5f));
		posT = ccpAdd(posT, ccp(wsize.width*0.5f,wsize.height*0.5f));
		
		lposT.x = lposT.x/wsize.width;
		lposT.y = lposT.y/wsize.height;
		posT.x = posT.x/wsize.width;
		posT.y = posT.y/wsize.height;
		
		while( lposT.x > 1 || posT.x > 1) {
			lposT.x --;
			posT.x --;
		}
		
		CCPoint arrT[4] = {
			ccp(lposT.x,1),
			ccp(posT.x,1),
			ccp(lposT.x,0),
			ccp(posT.x,0)
		};
		
		lpos = ccpAdd(lpos, ccp(physic_translate.x-self_auto->getPosition().x,physic_translate.y));
		pos = ccpAdd(pos, ccp(physic_translate.x-self_auto->getPosition().x,physic_translate.y));
		lpos = ccpAdd(lpos, camera_effect.get());
		pos = ccpAdd(pos, camera_effect.get());
		
		if( pos.x < -line_size.x*2 && lpos.x < -line_size.x*2) {
			continue;
		}
		if( pos.x > wsize.width+line_size.x*2 && lpos.x > wsize.width+line_size.x*2) {
			break;
		}
		
		CCPoint* arr = new CCPoint[4]();
		arr[0] = ccp(lpos.x,camera_effect.get().y);
		arr[1] = ccp(pos.x,camera_effect.get().y);
		arr[2] = ccp(lpos.x,lpos.y);
		arr[3] = ccp(pos.x,pos.y);
		
		CCPoint* arrD = new CCPoint[4]();
		arrD[0] = arrT[0];
		arrD[1] = arrT[1];
		arrD[2] = arrT[2];
		arrD[3] = arrT[3];
		
		result.push_back(std::pair<CCPoint*, CCPoint*>(arr,arrD));
	}
}

void GameScene::visibleShadow(PhysicAuto* a,std::vector<std::pair<cocos2d::CCPoint*, cocos2d::CCPoint*> >& points, cocos2d::CCPoint translate) {
	const CCRect& dim = a->getDimensions();
	CCPoint pos_on_window = a->getPositionOnScreen();
	
	float x1 = pos_on_window.x + dim.origin.x;
	float x2 = x1 + dim.size.width*0.95f;
	std::vector<CCPoint> shadow_points;
	
	float ground_angle = 0;
	float h = 0;
	float x_center = x1+dim.size.width*0.5f;
	for( size_t i = 0; i < points.size(); i++) {
		const CCPoint& p1 = points[i].first[2];
		const CCPoint& p2 = points[i].first[3];
		if( p1.x < x_center && x_center < p2.x) {
			float procent = (x_center-p1.x)/(p2.x-p1.x);
			h = p1.y + (p2.y-p1.y)*procent;
			ground_angle = ccpAngleSigned(ccpSub(p2, p1), ccp(1,0));
			break;
		}
	}
	float h_ground = fabs(pos_on_window.y-dim.size.height*0.5f-h);
	float scale = 1 - h_ground/CCDirector::sharedDirector()->getWinSize().height;
	if( scale < 0) {
		return;
	}
	float mult_scale = fabs(sin(CC_DEGREES_TO_RADIANS(a->getAngle())-ground_angle));
	mult_scale = (1-mult_scale) + mult_scale*dim.size.height/dim.size.width;
	scale *= mult_scale;
	
	scale = MIN(scale,1);
	float opacity = scale;
	
	x1 += dim.size.width*0.5f*(1-scale);
	x2 -= dim.size.width*0.5f*(1-scale);
	x1 += h_ground*0.5f;///light don't perpendicular ground - he get angle
	x2 += h_ground*0.5f;///light don't perpendicular ground - he get angle
	
	for( size_t i = 0; i < points.size(); i++) {
		float y =0;
		const CCPoint& p1 = points[i].first[2];
		const CCPoint& p2 = points[i].first[3];
		
		if( p1.x < x1 && x1 < p2.x) {///begin
			float procent = (x1-p1.x)/(p2.x-p1.x);
			y = p1.y + (p2.y-p1.y)*procent;
			shadow_points.push_back(ccp(x1,y));
		}
		
		if( x1 < p1.x && p1.x < x2) {///center
			shadow_points.push_back(ccp(p1.x,p1.y));
		}
		
		if( p1.x < x2 && x2 < p2.x) {///end
			float procent = (x2-p1.x)/(p2.x-p1.x);
			y = p1.y + (p2.y-p1.y)*procent;
			shadow_points.push_back(ccp(x2,y));
		}
	}
	
	cocos2d::ccColor4B color[4] = {
		ccc4(255,255,255,255*opacity),
		ccc4(255,255,255,255*opacity),
		ccc4(255,255,255,255*opacity),
		ccc4(255,255,255,255*opacity)
	};
	
	unsigned int number = texture_for_shadow->getName();
	float depth = a->getDepth()*0.5f*scale;
	for( size_t i =1; i < shadow_points.size(); i++) {
		CCPoint arr[4] = {
			ccpAdd(shadow_points[i-1], ccp(depth,translate.y-depth*0.4f)),
			ccpAdd(shadow_points[i], ccp(depth,translate.y-depth*0.4f)),
			ccpAdd(shadow_points[i-1], ccp(-depth,translate.y+depth*0.4f)),
			ccpAdd(shadow_points[i], ccp(-depth,translate.y+depth*0.4f))
		};
		float pr1 = (shadow_points[i-1].x-x1)/(x2-x1);
		float pr2 = (shadow_points[i].x-x1)/(x2-x1);
		
		CCPoint tex[4] = {
			ccp(pr1,0),
			ccp(pr2,0),
			ccp(pr1,1),
			ccp(pr2,1)
		};
		
		ccDrawTexturePoly(arr,number,tex,color);
	}
}

void GameScene::visitSlipEffects() {
	CCPoint wpos = ccpAdd(ccp(0,0), ccp(-self_auto->getPosition().x,0));
	wpos = ccpAdd(wpos, camera_effect.get());
	wpos = ccpAdd(wpos, ccp(physic_translate.x,physic_translate.y));
	
	slip_effects->setPosition(wpos);
	slip_effects->visit();
}

void GameScene::visit() {
	drawBack(0.2f);
	visibleObjects(-1000,0);
	
	std::vector<std::pair<CCPoint*, CCPoint*> > points;
	calcPoints(points);
	
	unsigned int number_top = texture_for_top->getName();
	unsigned int number_way = texture_for_way->getName();
	unsigned int number_snow = texture_for_snow->getName();
	float snow_height = texture_for_snow->getContentSize().height;
	
	float line1 = -0.4f;
	float line2 = 0.6f;
	float line3 = 1.25f;

#define POS(MULT) ccp(-line_size.x*(MULT),line_size.y*(MULT))
	///snow back
	drawLineWithTexture(points,number_snow,POS(line3),ccp(0, snow_height*0.65f),215,215);
	///way back
	drawLineWithTexture(points,number_way,POS(line2),POS(line3-line2),235,215);
	
	if( enemy_auto) {
		enemy_auto->visit();
	}
	///snow center
	drawLineWithTexture(points,number_snow,POS(line2),ccp(0, snow_height),235,235);
	
	///way front
	drawLineWithTexture(points,number_way,POS(line1),POS(line2-line1),255,235);
	visibleShadow(self_auto,points,POS(0));
	self_auto->visit();
	visitSlipEffects();
	///snow front
	drawLineWithTexture(points,number_snow,POS(line1),ccp(0, snow_height),255,255);
	///front
	drawBackFrontTexture(points,number_top,line1);
#undef POS
	
	for( size_t i =0; i < points.size(); i++) {
		delete[] points[i].first;
		delete[] points[i].second;
	}
	
	visibleObjects(0,1000);
	CCLayer::visit();
}

GameScene::~GameScene() {
	CC_SAFE_DELETE(world);
	world = 0x0;
	for( size_t i =0; i < objects.size(); i++) {
		objects[i].remove();
	}
	for( size_t i =0; i < physics.size(); i++) {
		physics[i]->release();
	}
	CC_SAFE_RELEASE_NULL(self_auto);
	CC_SAFE_RELEASE_NULL(enemy_auto);
	
	slip_effects->release();
}

SceneInformation GameScene::getSceneInformation()
{
	SceneInformation info;
	info.createScene = &scene;
	info.p = 0x0;
	
	info.resources.push_back(LoadingData("game-scene/elements/beams"));
	info.resources.push_back(LoadingData("game-scene/elements/drivers"));
	info.resources.push_back(LoadingData("game-scene/elements/engines"));
	info.resources.push_back(LoadingData("game-scene/elements/wheels"));
	info.resources.push_back(LoadingData("game-scene/elements/liner"));
	info.resources.push_back(LoadingData("game-scene/decoration"));
	info.resources.push_back(LoadingData("game-scene/backs"));
	info.resources.push_back(LoadingData("game-scene/button"));
	info.resources.push_back(LoadingData("game-scene/top"));
	info.resources.push_back(LoadingData("game-scene/snow"));
	info.resources.push_back(LoadingData("game-scene/way"));
	info.resources.push_back(LoadingData("game-scene/physic"));
	info.resources.push_back(LoadingData("game-scene/shadow"));
	info.resources.push_back(LoadingData("game-scene/progress"));
	info.resources.push_back(LoadingData("game-scene/particle"));
	info.resources.push_back(LoadingData("redactor-scene/mount"));
	info.resources.push_back(LoadingData("redactor-scene/menu"));
	info.resources.push_back(LoadingData("redactor-scene/backs"));
	
	return info;
}
