//
//  PhysicElement.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 14.08.13.
//
//

#include "PhysicElement.h"
#include <GrizzlyJr/FIOM/FIOMNode.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>

USING_NS_CC;

using namespace GrizzlyJr;
using namespace SlipperSlope;

b2Body* PhysicElement::loadBodyFromFile(b2World* world,std::string name,cocos2d::CCNode* node) {
	FIOMNode element = FIOMNode::get("Elements")[name]["physic"];
	if( !element.isCorrect()) {
		return 0x0;
	}
	
	b2BodyDef bodyDef;
	bodyDef.linearDamping = element.getFloat("linear");
	bodyDef.angularDamping = element.getFloat("angular");
	bodyDef.bullet = false;
	bodyDef.type = b2_dynamicBody;
	
	setPosAndAngleBodyDef(bodyDef,node);
	
	body = world->CreateBody(&bodyDef);
	
	FIOMNode fixtures = element["fixtures"];
	size_t count = fixtures.getArraySize();
	
	for( size_t i =0; i < count; i++) {
		FIOMNode fix = fixtures[(unsigned int)i];
		
		b2FixtureDef fixture;
		fixture.density = fix.getFloat("density");
		fixture.friction = fix.getFloat("friction");
		fixture.restitution = fix.getFloat("restitution");
		fixture.filter.categoryBits = categoryBits;
		fixture.filter.maskBits = maskBits;
		
		b2PolygonShape poly;
		b2CircleShape circle;
		if( "circle" == fix.getStr("type")) {
			FIOMNode data = fix["data"];
			float x = data.getFloat("x")*node->getScaleX();
			float y = data.getFloat("y")*node->getScaleY();
			circle.m_p = b2Vec2(x,y);
			circle.m_radius = data.getFloat("radius")*node->getScaleY()*0.5f;
			fixture.shape = &circle;
		} else {
			b2Vec2 points_v[32];
			
			FIOMNode points = fix["points"];
			size_t p_count = points.getArraySize();
			for( size_t j =0; j < p_count; j+=2) {
				float x = points.getFloat((unsigned int)j)*node->getScaleX();
				float y = points.getFloat((unsigned int)j+1)*node->getScaleY();
				points_v[j/2] = b2Vec2(x,y);
			}
			
			poly.Set(points_v, p_count/2);
			
			fixture.shape = &poly;
		}
		
		body->CreateFixture(&fixture);
	}
	return body;
}

void PhysicElement::setPosAndAngleBodyDef(b2BodyDef& bdef,cocos2d::CCNode* node) {
	bdef.position = Box2DCocos::convert(node->getPosition());
	bdef.angle = Box2DCocos::convertToBox2d(node->getRotation());
}

void PhysicElement::updateNode(cocos2d::CCNode* node) {
	if( 0x0 != body) {
		node->setPosition(Box2DCocos::convert(body->GetPosition()));
		node->setRotation(Box2DCocos::convertToCocos2D(body->GetAngle()));
	}
}

