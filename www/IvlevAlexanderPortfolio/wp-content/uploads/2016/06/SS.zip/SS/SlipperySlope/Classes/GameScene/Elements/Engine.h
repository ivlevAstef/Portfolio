//
//  Engine.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_ENGINE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_ENGINE_H_

#include "AutoElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Engine: public AutoElement {
		private:
			float torque;
			float accelerate;
			float max_speed;
			
			float a;
			float b;
			float degree;
		public:
			Engine(std::string name);
			
			float getTorque()const { return torque; }
			float getAccelerate()const { return accelerate; }
			float getMaxSpeed()const { return max_speed; }
			
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale);
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale);
			
			virtual void visit3dView(float auto_angle);
			
			virtual void setScaleX(float x);
			virtual void setScaleY(float y);
			virtual void setScale(float scale);
			
			float getA()const { return a;}
			float getB()const { return b;}
			float getDegree()const { return degree;}
		};
	};
};

#endif