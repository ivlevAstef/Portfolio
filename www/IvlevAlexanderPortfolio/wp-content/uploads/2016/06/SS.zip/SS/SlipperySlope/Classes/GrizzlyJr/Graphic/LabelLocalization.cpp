#include "LabelLocalization.h"
#include "../Localization.h"
#include "../Location.h"
#include <Config/Config.h>

#define LABEL_LOCATION_FILE "LabelLocation"

using namespace GrizzlyJr;
using namespace cocos2d;

LabelLocalization* LabelLocalization::create(std::string idText,std::string id_name)
{
	LabelLocalization* label = new LabelLocalization();
	if( label->init(idText, id_name)) {
		label->autorelease();
		return label;		
	}
	delete label;
	return 0x0;
}

LabelLocalization* LabelLocalization::create(int number,std::string id_name) {
	LabelLocalization* label = new LabelLocalization();
	char nText[32] = {0};
	sprintf(nText, "%d",number);
	if( label->initT(nText, id_name)) {
		label->autorelease();
		return label;
	}
	delete label;
	return 0x0;
}

bool LabelLocalization::init(std::string idText,std::string id_name) {
	return initT(Localization::text(idText), id_name);
}

LabelLocalization* LabelLocalization::createT(std::string text,std::string id_name) {
	LabelLocalization* label = new LabelLocalization();
	if( label->initT(text, id_name)) {
		label->autorelease();
		return label;		
	}
	delete label;
	return 0x0;
}

LabelLocalization* LabelLocalization::createDate(time_t time_value,std::string id_name) {
	LabelLocalization* label = new LabelLocalization();
	if( label->initDate(time_value, id_name)) {
		label->autorelease();
		return label;
	}
	delete label;
	return 0x0;
}

static std::string getTime(time_t time) {
	if( time < 0) {
		return "00:00";
	}
	
	int sec = time%60;
	time = time/60;
	int min = time%60;
	time = time/60;
	int hour = time%24;
	time = time/24;
	int day = time;
	
	char temp[128] = {0};
	if( 0 == hour && 0 == min && 0 == day) {
		sprintf(temp, "%2ds ",sec);
	} else if( 0 == hour && 0 == day) {
		sprintf(temp, "%2dm %02ds",min,sec);
	} else if( 0 == day){
		sprintf(temp, "%2dh %02dm",hour,min);
	} else {
		sprintf(temp, "%dd %dh",day,hour);
	}
	
	return temp;
}

bool LabelLocalization::initDate(time_t time_value,std::string id_name) {
	time_t current_time = time(NULL);
	std::string text;
	if( time_end > current_time) {
		text = getTime(time_end-current_time);
	} else {
		text = "00:00";
	}
	if( initT(text, id_name) ) {
		time_end = time_value;
		return true;
	}
	return false;
}

std::string LabelLocalization::getFontName() {
	FIOMNode localesNode = FIOMNode::get(LABEL_LOCATION_FILE)["languages"];
	size_t localesSize = localesNode.getArraySize();
	int addIndex = 0;
	std::string beginLocale = Localization::get()->getLocale();
	for (unsigned int i = 0; i < localesSize; i++) {
		if( localesNode.getStr(i) == beginLocale) {
			addIndex = i;
			break;
		}
	}
	std::string localeFirst = localesNode.getStr(addIndex);
	
	FIOMNode fontsNode = FIOMNode::get(LABEL_LOCATION_FILE)["fonts"];
	return fontsNode.getStr(localeFirst);
}

bool LabelLocalization::initT(std::string text,std::string id_name) {
	time_end = 0;
	
	FIOMNode localesNode = FIOMMain::get()->getRoot(LABEL_LOCATION_FILE)["languages"];
	size_t localesSize = localesNode.getArraySize();
	
	int addIndex = 0;
	std::string beginLocale = Localization::get()->getLocale();
	for (unsigned int i = 0; i < localesSize; i++) {
		if( localesNode.getStr(i) == beginLocale) {
			addIndex = i;
			break;
		}
	}
	
	Location nodeStart = Location::get(LABEL_LOCATION_FILE);
	Location node = nodeStart;
	
	std::string localeFirst = localesNode.getStr(addIndex);
	std::string locale;
	
	for( unsigned int i =0; i < localesSize; i++) {
		int index = (addIndex+i)%localesSize;
		
		locale = localesNode.getStr(index);
		node = nodeStart[locale][id_name];
		
		if( node.isCorrect() ) {
			break;
		}
	}
	
	if(!node.isCorrect()) {
		return false;
	}
	
	
	std::string useType = node.getStr("use_type");

	CCPoint pos;
	CCSize dimension;
	float font_size;
	if( "y" == useType) {
		pos = node.getLPoint("device",Location::CHANGE_Y);
		dimension = node.getLSize("device",Location::CHANGE_Y);
		font_size = node["device"].getLFloat("size",Location::CHANGE_Y);
	}else if( "x" == useType) {
		pos = node.getLPoint("device",Location::CHANGE_X);
		dimension = node.getLSize("device",Location::CHANGE_X);
		font_size = node["device"].getLFloat("size",Location::CHANGE_X);
	}else {
		pos = node.getLPoint("device");
		dimension = node.getLSize("device");
		font_size = node["device"].getLFloat("size");
	}
	
	{
		Location font_data = Location::get(LABEL_LOCATION_FILE)[beginLocale];
		if( dimension.width <= 0 && dimension.height <= 0) {
			pos = ccpAdd(pos, font_data.getLPoint("font_data"));
		}
		font_size += font_data["font_data"].getLFloat("size");
	}

	float angle = node.getFloat("angle");
	std::string font_name = node.getStr("name");
	if( "" == font_name || localeFirst != locale) {
		FIOMNode fontsNode = FIOMMain::get()->getRoot(LABEL_LOCATION_FILE)["fonts"];
		font_name = fontsNode.getStr(localeFirst);
	}
	
	std::string aligmentStr = node.getStr("aligment");
	float aligmentY = node.getFloat("aligmentY");
	
	
	ccColor3B color = node.getColor("color");
	GLubyte alpha =  node["color"].getInt("a");
	
	//bool isWrite = FIOMG(bool,node,"isWrite");
	
	////CREATE
		
	CCTextAlignment aligmentX = kCCTextAlignmentCenter;
	CCSize dimensionUse = dimension;
	bool isAligmentY = node.is("aligmentY");
	if( "left" == aligmentStr) {
		aligmentX = kCCTextAlignmentLeft;
	}else if( "right" == aligmentStr) {
		aligmentX = kCCTextAlignmentRight;
	}else if( "center" == aligmentStr) {
		aligmentX = kCCTextAlignmentCenter;
	}else {
		aligmentX = kCCTextAlignmentCenter;
		isAligmentY = false;
		dimensionUse = CCSize(0,0);
	}
	if( isAligmentY) {
		dimensionUse.height = 0;
	}
	
	bool isCreate = CCTextFieldTTF::initWithPlaceHolder(text.c_str(), dimensionUse, aligmentX, font_name.c_str(), font_size);
	this->setVerticalAlignment(kCCVerticalTextAlignmentCenter);
	
	if( isCreate) {
		this->setString(text.c_str());
		this->setRotation(angle);
		this->setColor(color);
		this->setOpacity(alpha);
		
		if( isAligmentY && this->getContentSize().height < dimension.height) {
			float h2 = (dimension.height-this->getContentSize().height);
			pos.y += (0.5f-aligmentY)*h2;
		}
		this->setPosition(pos);
		return true;
	}
	
	return false;
}


void LabelLocalization::draw() {
	if( time_end > 0) {
		std::string text;
		time_t current_time = time(NULL);
		if( time_end > current_time) {
			text = getTime(time_end-current_time);
		} else {
			text = "00:00";
		}
		
		if( text != this->getString() ) {
			((CCLabelTTF*)this)->setString(text.c_str());
		}
	}
	
	CCTextFieldTTF::draw();
}
