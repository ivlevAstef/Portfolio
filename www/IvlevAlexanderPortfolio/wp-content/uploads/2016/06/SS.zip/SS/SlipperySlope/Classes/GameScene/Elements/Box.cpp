//
//  Box.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 14.08.13.
//
//

#include "Box.h"

using namespace GrizzlyJr;
using namespace SlipperSlope;

USING_NS_CC;

Box::Box() {
	depth = 30;
	CCSize world_size = CCDirector::sharedDirector()->getWinSize();
	center = ccp(-world_size.width*0.5f,-world_size.height*0.5f);
}

Box* Box::create(std::string name) {
	Box* box = new Box();
	if( box && box->init(name)) {
		box->autorelease();
		return box;
	}
	CC_SAFE_DELETE(box);
	return 0x0;
}

bool Box::init(std::string name) {
	this->name = name;
	
	ScaleCCSprite* image = ScaleCCSprite::createFN(name+".png");
	CCSize size = image->getContentSize();
	
	this->addChild(image,-1);
	this->setContentSize(size);
	
	back = ScaleCCSprite::createFN(name+"-back.png");
	back->retain();
	
	return true;
}

Box::~Box() {
	back->release();
}

void Box::physicInit(b2World* world) {
	categoryBits = 0x0002 | 0x0004;
	maskBits = 0x0002 | 0x0004;
	loadBodyFromFile(world, name, this);
	updateNode(this);
}

void Box::setFlipX(bool flipX) {
	if( flipX) {
		setScaleX(-fabs(getScaleX()));
	} else {
		setScaleX(fabs(getScaleX()));
	}
}
void Box::setFlipY(bool flipY) {
	if( flipY) {
		setScaleY(-fabs(getScaleY()));
	} else {
		setScaleY(fabs(getScaleY()));
	}
}

void Box::visit3dView(float glob_angle) {
	CCPoint pos_on_image = calc3dTranslate(glob_angle);
		
	kmGLPushMatrix();
	this->transform();
	
	CCObject* obj = 0x0;
	ScaleCCSprite* image = 0x0;
	
	CCARRAY_FOREACH(m_pChildren, obj) {
		image = (ScaleCCSprite*) obj;
		back->setPosition(ccpAdd(image->getPosition(), pos_on_image));
		back->visit();
	}
	
	kmGLPopMatrix();
}
