//
//  GestureGeometryListener.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 05.09.13.
//
//

#ifndef _GRIZZLY_JR_GESTURE_GEOMETRY_LISTENER_H_
#define _GRIZZLY_JR_GESTURE_GEOMETRY_LISTENER_H_

namespace GrizzlyJr {
	class GestureGeometryListener {
	public:
		virtual void beginGestureRecord() {}
		virtual void createGesture(std::string name){} ///call before endGestureRecord
		virtual void endGestureRecord() {}
	};
};


#endif
