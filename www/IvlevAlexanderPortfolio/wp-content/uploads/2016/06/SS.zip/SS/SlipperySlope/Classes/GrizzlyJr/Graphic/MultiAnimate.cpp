#include "MultiAnimate.h"
#include "AnimatedSprite.h"
#include "../Log/LogFunction.h"

using namespace GrizzlyJr;
using namespace cocos2d;

MultiAnimate::MultiAnimate() : animation(0x0)
	, m_nNextFrame(0)
	, nameSound("")
	, soundLength(0) {
}

MultiAnimate::~MultiAnimate() {
	if( "" != nameSound) {
		SoundController::get()->endEffect(m_pTarget);
	}
}

MultiAnimate* MultiAnimate::actionWithAnimation(CCAnimation* pAnimation,unsigned int count) {
	MultiAnimate *pAnimate = new MultiAnimate();
	pAnimate->initWithAnimation(pAnimation,count);
	pAnimate->autorelease();

	return pAnimate;
}

bool MultiAnimate::initWithAnimation(CCAnimation* pAnimation,unsigned int count) {
	CCAssert(pAnimation, "");
	
	float singleDuration = pAnimation[0].getDuration();
	if (CCActionInterval::initWithDuration(singleDuration)) {
		m_nNextFrame = 0;
		animation = pAnimation;
		this->count = count;
				
		return true;
	}

	return false;
}

MultiAnimate* MultiAnimate::create(float duration, CCAnimation* pAnimation,unsigned int count) {
	MultiAnimate *pAnimate = new MultiAnimate();
	pAnimate->initWithDuration(duration, pAnimation,count);
	pAnimate->autorelease();

	return pAnimate;
}

bool MultiAnimate::initWithDuration(float duration, CCAnimation* pAnimation,unsigned int count) {
	CCAssert(pAnimation != NULL, "");

	if (CCActionInterval::initWithDuration(duration)) {
		m_nNextFrame = 0;
		animation = pAnimation;
		this->count = count;
		return true;
	}

	return false;
}

CCObject* MultiAnimate::copyWithZone(CCZone* pZone)
{
	MY_LOG("COPY MULTI ANIMATE!!!! IT's MEMORY LEAK");
	CCZone* pNewZone = NULL;
	CCObject* pCopy = NULL;
	if(pZone && pZone->m_pCopyObject)  {
		//in case of being called at sub class
		pCopy = (MultiAnimate*)(pZone->m_pCopyObject);
	} else {
		pCopy = new MultiAnimate();
		assert(false);//on Window don't work -> pZone = pNewZone = new CCZone(pCopy);
	}

	CCActionInterval::copyWithZone(pZone);

	((MultiAnimate*)pCopy)->initWithDuration(m_fDuration, animation,count);

	CC_SAFE_DELETE(pNewZone);
	return pCopy;
}

void MultiAnimate::startWithTarget(CCNode* pTarget)
{
	CCActionInterval::startWithTarget(pTarget);
	
    m_nNextFrame = 0;
	
	if( "" != nameSound) {
		SoundController::get()->playEffect(pTarget,nameSound.c_str(),soundLength);
	}
	
}

void MultiAnimate::stop(void)
{	
	CCActionInterval::stop();
	if( "" != nameSound) {
		SoundController::get()->endEffect(m_pTarget);
	}
}

bool MultiAnimate::isDone(void) {
	if( CCActionInterval::isDone()) {
		update(1);
		return true;
	} else {
		return false;
	}
}

void MultiAnimate::update(float time)
{
	const std::vector<ScaleCCSprite*>& sprites = ((AnimatedSprite*)(m_pTarget))->getSprites();
	int saveFrame = m_nNextFrame;
	for( unsigned int i =0; i < this->count; i++)
	{
		CCArray* pFrames = animation[i].getFrames();
		unsigned int numberOfFrames = pFrames->count();
		if( 0 == numberOfFrames) {
			continue;
		}
		
		for( size_t idx = saveFrame; idx < numberOfFrames; idx++ ) {
			float splitTime = (float)idx/(float)(numberOfFrames);
			
			if( splitTime <= time ) {
				CCAnimationFrame* frame = (CCAnimationFrame*)pFrames->objectAtIndex(idx);
				CCSpriteFrame* frameToDisplay = frame->getSpriteFrame();
				sprites[i]->setDisplayFrame(frameToDisplay);
				m_nNextFrame = idx+1;
				break;
			}
		}
	}
}

CCActionInterval* MultiAnimate::reverse(void)
{
	///Don't reverse
	return MultiAnimate::actionWithAnimation(animation, count);
}