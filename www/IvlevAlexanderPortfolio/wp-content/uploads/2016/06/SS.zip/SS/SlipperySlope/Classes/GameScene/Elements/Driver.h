//
//  Drivers.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_DRIVER_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_DRIVER_H_

#include "AutoElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Driver: public AutoElement {
		public:
			Driver(std::string name);
			
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale);
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale);
			
			virtual void visit3dView(float auto_angle);
		};
	};
};

#endif
