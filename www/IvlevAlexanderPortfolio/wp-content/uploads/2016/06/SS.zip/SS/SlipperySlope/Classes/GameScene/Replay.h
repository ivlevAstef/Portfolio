//
//  Replay.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_REPLAY_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_REPLAY_H_

#include "Elements/AutoElement.h"
#include "PhysicAuto.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Replay {
		private:
			static unsigned int fps;
		private:			
			struct AutoFrame {
				int x:16;///max 65536 - x translate from last frame
				int y:16;///max 65536 - y translate from last frame
			};///4byte
			
			struct ElementFrame {
				int x:16;///max 65536 - x translate from last frame
				int y:16;///max 65536 - y translate from last frame
				int r:16;///max 65536 - angle translate from last frame
			};///6byte
			
			struct Frame {
				AutoFrame a;///global auto info
				ElementFrame* e;///array changing ElementFrame
				unsigned char c;///max 256 - count change ElementFrame
				
				Frame();
				void fMalloc(size_t count);
				void fFree();
				~Frame();
			};
			
			
			struct BeginElementFrame {
				cocos2d::CCPoint pos;
				float angle;
				AutoElement* pointer;
				
				BeginElementFrame():angle(0),pointer(0x0) {}
			};
			struct BeginAutoFrame {
				cocos2d::CCPoint pos;
				PhysicAuto* pointer;
				
				std::vector<BeginElementFrame> elements;
				
				BeginAutoFrame():pointer(0x0) {}
			};
			
			std::vector<Frame*> frames;
			BeginAutoFrame begin;
			BeginAutoFrame current;
			cocos2d::CCPoint position;
			
			float time;
			
			bool is_record;
			bool is_play;
			
			float mult_x_for_int;
			float mult_y_for_int;
			float mult_r_for_int;
			float replay_speed;
		public:
			Replay();
			
			bool startRecord(PhysicAuto* record_auto);
			bool tickRecord(float dt);
			bool stopRecord();
			
			~Replay();
		public:	
			bool play(PhysicAuto* change_auto,float replay_speed=1);
			bool tickPlay(float dt);
			bool stop();
			
		public:
			bool isRecord()const { return is_record; }
			bool isPlay()const { return is_play; }
			
			float getCurrentTime()const { return time; }
			float getFullTime()const { return (float)frames.size()/(float)fps; }
			
			
			const cocos2d::CCPoint& getPosition()const { return position; }
		public:
			bool save(std::string name);
			bool load(std::string name);
			
		private:
			static bool interpolation(float time,float dt,BeginAutoFrame& use,size_t index);
			
			static std::vector<AutoElement*> getElements(PhysicAuto* node);
			
			void clearFrames();
		};
	};
};

#endif