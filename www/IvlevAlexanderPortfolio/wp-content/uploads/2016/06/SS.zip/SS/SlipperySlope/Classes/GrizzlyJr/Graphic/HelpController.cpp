//
//  HelpController.cpp
//  cuteheroes
//
//  Created by Alexander Ivlev on 04.10.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "HelpController.h"
#include <GrizzlyJr/Location.h>
#include <GrizzlyJr/SceneController/SceneController.h>
#include "ScaleCCSprite.h"

#include <GrizzlyJr/FileImageOnMemory/FIOMNode.h>

#include "FadeOnAllChilds.h"
#include "RemoveAction.h"

#include "LabelLocalization.h"

#include "Scene/GameScene.h"
#include "Scene/CompaingMenu.h"
#include "Character/CharacterController.h"

#include "Utils/Controller/ServerController.h"

#include "../LogAPI.h"
#include "Config/Config.h"

#define FADE_TIME 0.5f
#define FADE_TIME_DOWN 0.3f
#define FADE_TAG 1113
#define DELAY_TAG 1112
#define DELAY_FOR_REMOVE_TAG 1113

#define ARROW_CHANGE_DELAY_UNSELECT 0.5f
#define ARROW_CHANGE_DELAY_SELECT 0.5f

using namespace GrizzlyJr;
using namespace cocos2d;
using namespace CuteHeroes;

HelpController* HelpController::singleton = 0x0;

HelpController* HelpController::get() {
	if( 0x0 == singleton) {
		singleton = new HelpController();
	}
	return singleton;
}

void HelpController::remove() {
	if( 0x0 != singleton) {
		CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(singleton);
		delete singleton;
		singleton = 0x0;
	}
}

HelpController::HelpController() {
	FIOMMain::get()->loadFile("config/HelpInformation");
	helpLayer = 0x0;
	nameScene = "";
	lastParent = 0x0;
	isPause = false;
	touchEnd = false;
	fullLoad = false;
	castEnd = false;
	addUnitEnd = false;
	CCDirector::sharedDirector()->getTouchDispatcher()->addStandardDelegate(this, 0);
	
#ifdef TEST_HELP_CONTROLLER
#ifdef TEST_MODE_FIRST_INDEX
	CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",TEST_MODE_FIRST_INDEX);
#else
	CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",1);
#endif
	CCUserDefault::sharedUserDefault()->setIntegerForKey("style-gameSceneEnemy", 0);
	CCUserDefault::sharedUserDefault()->setIntegerForKey("style-pauseMenu", 0);
	CCUserDefault::sharedUserDefault()->setIntegerForKey("style-gameSceneGetUnit", 0);
	CCUserDefault::sharedUserDefault()->setIntegerForKey("style-gameSceneCombo", 0);
	CCUserDefault::sharedUserDefault()->setIntegerForKey("style-firstbase",0);
	//CCUserDefault::sharedUserDefault()->setIntegerForKey("style-attack-castle",0);
	//CCUserDefault::sharedUserDefault()->setIntegerForKey("style-champion-duel",0);
	//CCUserDefault::sharedUserDefault()->setIntegerForKey("style-play-shield",0);
	CCUserDefault::sharedUserDefault()->flush();
	
	FIOMNode node = FIOMNode::get("Personages.per");
	node.set("first_session",true);
#else
	if( Config::c->isFirstLaunch) {
		CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",1);
		LogAPI::helpNewIndex(1);
		CCUserDefault::sharedUserDefault()->flush();
		ServerController::get()->saveHelpProgress();
	}
	
	if( -1 ==CCUserDefault::sharedUserDefault()->getIntegerForKey("help-index",-1)) {
		CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",1);
		CCUserDefault::sharedUserDefault()->flush();
	}
#endif
}

std::string HelpController::getScene() {
#ifdef DISABLE_HELP
	return "";
#endif
	
	FIOMNode node = FIOMNode::get("HelpInformation")["menu-index"];
	int index = CCUserDefault::sharedUserDefault()->getIntegerForKey("help-index");
	if( "" != nameScene) {
		index++;
	}
	for(; index >=1; index--) {
		FIOMNode child = node[index];
		if( child.isCorrect() ) {
			std::string scene = child.getStr("scene");
			if( "ignore" == scene) {
				return "";
			}
			
			if( "end" == scene) {
				return "";
			}
			if( "normal" == scene) {
				if( "" == nameScene) {
					continue;
				}
				return "";
			}
			
			if( "" == nameScene) {
				CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",index);
			}
			return scene;
		}
	}
	return "";
}

void* HelpController::getInfoScene() {
	FIOMNode node = FIOMNode::get("HelpInformation")["menu-index"];
	int index = CCUserDefault::sharedUserDefault()->getIntegerForKey("help-index");
	if( "" != nameScene) {
		index++;
	}
	
	std::string scene = "";
	for(; index >=1; index--) {
		FIOMNode child = node[index];
		if( child.isCorrect() ) {
			scene = child.getStr("scene");
			if( "ignore" == scene) {
				return 0x0;
			}
			
			if( "end" == scene) {
				return 0x0;
			}
			if( "normal" == scene) {
				if( "" == nameScene) {
					continue;
				}
				return 0x0;
			}
			node = child["params"];
			goto IS_CORRECT;
		}
	}
	return 0x0;
	
IS_CORRECT:;
	if( "battle" == scene) {
		GameSceneStructForLoad* loadData = new CuteHeroes::GameSceneStructForLoad();		
		loadData->mapName = node.getStr("map-name");
		loadData->level = 0;
		loadData->computerLevel	= node.getInt("complexity");
		
		CharacterController::get()->getMe()->setVirtualImage(node.getStr("virtual-name"));
		CharacterController::get()->getEnemy()->loadComputer(node.getStr("enemy-name"));
		return loadData;
	}
	if( "compaing" == scene) {
		CuteHeroes::CompaingMenu::CompaingInitInformation* info = new CuteHeroes::CompaingMenu::CompaingInitInformation();
		info->defaultComputerLevel = node.getInt("complexity")-1;
		info->beginVisiblePopUp = node.getInt("level")-1;
		return info;
	}
	
	return 0x0;
}

HelpController::~HelpController() {
	if( 0x0 != helpLayer) {
		stopMyAction();
		helpLayer->release();
		helpLayer = 0x0;
	}
	
	CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this);	
}

static void setAllEnable(std::vector<HelpElementInterface*>& vec) {
	for( size_t i = 0; i < vec.size(); i++) {
		if( 0x0 != vec[i]) {
			vec[i]->enableOnHelp();
		}
	}
	vec.clear();
}

void HelpController::changeScene(std::string nameScene) {
	endScene();
	this->nameScene = nameScene;
	loadElements.clear();
}

void HelpController::stopMyAction() {
	CCAction* action_iter = 0x0;
	while( 0x0 != (action_iter = helpLayer->getActionByTag(FADE_TAG))) {
		helpLayer->stopAction(action_iter);
	}
	while( 0x0 != (action_iter = helpLayer->getActionByTag(DELAY_TAG))) {
		helpLayer->stopAction(action_iter);
	}
	while( 0x0 != (action_iter = helpLayer->getActionByTag(DELAY_FOR_REMOVE_TAG))) {
		helpLayer->stopAction(action_iter);
	}
	
}

void HelpController::endScene() {
	touchEnd = false;
	fullLoad = false;
	castEnd = false;
	addUnitEnd = false;
	
	if( 0x0 != GameScene::getSingleton() && 0x0 != GameScene::getMapState() && -1 != beginGameScenePos.y) {
		GameScene::getMapState()->setPosition(beginGameScenePos);
	}
	
	if( 0x0 != helpLayer) {
	 	CCAction* action = helpLayer->getActionByTag(FADE_TAG);
		if( 0x0 != action) {
			action->retain();
		}
		
		stopMyAction();
		if( !action) {
			FadeOnAllChilds* fade = FadeOnAllChilds::create(FADE_TIME_DOWN,0);
			CCSequence* seq = CCSequence::createWithTwoActions(fade, RemoveAction::create());
			seq->setTag(FADE_TAG);
			helpLayer->runAction(seq);
		} else {
			helpLayer->runAction(action);
			action->release();
		}
	}
	if( "" != nameScene) {
		int index = CCUserDefault::sharedUserDefault()->getIntegerForKey("help-index");
		CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",index+1);
		LogAPI::helpNewIndex(index+1);
		CCUserDefault::sharedUserDefault()->flush();
		
		FIOMNode node = FIOMNode::get("HelpInformation")["menu-index"][index+1];
		if( node.isCorrect() ) {
			node = node["clean"];
			if( node.isCorrect()) {
				size_t size = node.getArraySize();
				for( unsigned int i =0; i < size; i++) {
					std::string key = "style-"+node.getStr(i);
					CCUserDefault::sharedUserDefault()->setIntegerForKey(key.c_str(), 1000000);
				}
			}
		}
		ServerController::get()->saveHelpProgress();
	}
}

void HelpController::clearData() {
	if( 0x0 != helpLayer) {
		helpLayer->release();
		helpLayer = 0x0;
	}
}

static HelpElementInterface* enableDisableElementOnHelp(FIOMNode& node,HelpElementInterface* element) {
	if( 0x0 == element) {
		return 0x0;
	}
	
	if( node.getBool("enable")) {
		element->enableOnHelp();
	} else {
		element->disableOnHelp();
	}
	
	if( node.is("dontUseAction") && node.getBool("dontUseAction")) {
		element->dontUseNormalAction();
	}
	
	if( node.is("useImage")) {
		ScaleCCSprite* image = ScaleCCSprite::createWithSpriteFrameName(node.getStr("useImage").c_str());
		image->setPosition(ccp(element->getWidth()*0.5f,element->getHeight()*0.5f));
		element->addNodeChild(image);
	}

	if( node.is("control") && node.getBool("control")) {
		return element; 
	}
	return 0x0;
}

static void addImage(FIOMNode& node,CCNode* parent,std::map<std::string,CCRect>& userRect) {
	if( 0x0 == parent) {
		return;
	}
	
	ScaleCCSprite* image = ScaleCCSprite::createWithSpriteFrameName(node.getStr("name").c_str());
	if( 0x0 == image) {
		return;
	}
	
	if( node.is("flipX") && node.getBool("flipX")) {
		image->setFlipX(true);
	}
	if( node.is("flipY") && node.getBool("flipY")) {
		image->setFlipY(true);
	}

	image->setPosition(ccp(0,0));
	if( node.is("posId")) {
		std::string posId = node.getStr("posId");
		Location pos = Location::get("DevicesInfo")["HelpMenu"];
		image->setPosition(pos.getLPoint(posId));
	}
	
	if( node.is("posIdUser")) {
		std::string posId = node.getStr("posIdUser");
		CCPoint pos = userRect[posId].origin;
		image->setPosition(ccpAdd(pos,image->getPosition()));
	}
	
	if( node.is("textId") && node.is("textPosId")) {
		std::string textId = node.getStr("textId");
		std::string posId = "HelpMenu/"+node.getStr("textPosId");
		
		LabelLocalization* label = LabelLocalization::create(textId, posId);
		label->setOpacity(0);
		image->addChild(label);
	}
	
	CCFiniteTimeAction* action = FadeOnAllChilds::create(FADE_TIME,255);
	if( node.is("delay")) {
		CCDelayTime* delayA = CCDelayTime::create(node.getFloat("delay"));
		action = CCSequence::createWithTwoActions(delayA,action);
	}
	
	image->setOpacity(0);
	image->runAction(action);
	
	
	Button* pB = dynamic_cast<Button*>(parent);
	if( pB) {
		pB->addNodeChild(image);
	} else {
		parent->addChild(image,100500);
	}
}

void HelpController::changeArrow(CCObject* arrowBase) {
	CCMenuItemSprite* arrow = (CCMenuItemSprite*)arrowBase;
	if( arrow->isSelected()) {
		arrow->unselected();
		CCDelayTime* delay = CCDelayTime::create(ARROW_CHANGE_DELAY_UNSELECT);
		CCCallFuncO* call = CCCallFuncO::create(this, callfuncO_selector(HelpController::changeArrow), arrowBase);
		arrow->runAction(CCSequence::createWithTwoActions(delay, call));
	} else {
		arrow->selected();
		CCDelayTime* delay = CCDelayTime::create(ARROW_CHANGE_DELAY_SELECT);
		CCCallFuncO* call = CCCallFuncO::create(this, callfuncO_selector(HelpController::changeArrow), arrowBase);
		arrow->runAction(CCSequence::createWithTwoActions(delay, call));
	}
}

static void addArrow(FIOMNode& node,CCNode* parent) {
	if( 0x0 == parent) {
		return;
	}
	
	std::string normal = node.getStr("name");
	std::string select = normal+"-select.png";
	normal += ".png";
	
	ScaleCCSprite* normalI = ScaleCCSprite::createWithSpriteFrameName(normal.c_str());
	ScaleCCSprite* selectI = ScaleCCSprite::createWithSpriteFrameName(select.c_str());
	CCMenuItemSprite* image = CCMenuItemSprite::create(normalI,selectI);
	
	if( node.is("flipX") && node.getBool("flipX")) {
		normalI->setFlipX(true);
		selectI->setFlipX(true);
	}
	if( node.is("flipY") && node.getBool("flipY")) {
		normalI->setFlipY(true);
		selectI->setFlipY(true);
	}
	
	
	if( node.is("posId")) {
		std::string posId = node.getStr("posId");
		Location pos = Location::get("DevicesInfo")["HelpMenu"];
		image->setPosition(pos.getLPoint(posId));
	}
	
	FadeOnAllChilds* fade = FadeOnAllChilds::create(FADE_TIME,255);
	image->setOpacity(0);
	image->runAction(fade);
	
	Button* pB = dynamic_cast<Button*>(parent);
	if( pB) {
		pB->addNodeChild(image);
	} else {
		parent->addChild(image,100500);
	}
	
	image->unselected();
	HelpController::get()->changeArrow(image);
}

static std::string findCurrentStyle(std::string scene, int currentIndex) {
#ifdef DISABLE_HELP
	return "";
#endif
	
	if( "" == scene) {
		return "";
	}
	
	FIOMNode node = FIOMNode::get("HelpInformation")["names"][scene];
	if( !node.isCorrect()) {
		return "";
	}
	
	if( currentIndex <= 0) {
		currentIndex = CCUserDefault::sharedUserDefault()->getIntegerForKey("help-index",-1);
		if( -1 == currentIndex) {
			CCUserDefault::sharedUserDefault()->setIntegerForKey("help-index",1);
			CCUserDefault::sharedUserDefault()->flush();
			currentIndex = 1;
		}
	}
	size_t size = node.getArraySize();
	for( unsigned int i =0; i < size; i++) {
		std::string name = node.getStr(i);
		FIOMNode node = FIOMNode::get("HelpInformation")["styles"][name];
		if( !node.isCorrect()) {
			continue;
		}
		if( node.getInt("indexOfVisible") == currentIndex){
			return name;
		}
	}
	
	return "";
}

static void static_pause(CCNode* node) {
	if( node->getUserData() && -1 == *((int*)node->getUserData())) {
		return;
	}
	if( 0x0 != GameScene::getSingleton() && node == GameScene::getMapState()) {
		GameScene::getMapState()->resumeScrollAndTouch();
	}
	
	node->pauseSchedulerAndActions();
	CCArray* childred = node->getChildren();
	CCObject* pObject = 0x0;
	CCARRAY_FOREACH(childred, pObject)
	{
		CCNode* pNode = (CCNode*)pObject;
		if(0x0 != pNode) {
			static_pause(pNode);
		}
	}
}
static void static_resume(CCNode* node) {
	if( 0x0 != GameScene::getSingleton() && node == GameScene::getMapState()) {
		GameScene::getMapState()->resumeScrollAndTouch();
	}
	
	node->resumeSchedulerAndActions();
	CCArray* childred = node->getChildren();
	CCObject* pObject = 0x0;
	CCARRAY_FOREACH(childred, pObject)
	{
		CCNode* pNode = (CCNode*)pObject;
		if(0x0 != pNode) {
			static_resume(pNode);
		}
	}
}

void HelpController::enableHelp(cocos2d::CCNode* parent) {
	clearData();
	lastParent = 0x0;
	std::string idStyle = findCurrentStyle(nameScene,-1);
	if( "" == idStyle) {
		setAllEnable(loadElements);
		nameScene = "";
		return;
	}
	
	std::string nameSceneSave = nameScene;
	enableHelpUseStyle(parent,idStyle);
	nameScene = nameSceneSave;
}

void HelpController::enableHelpUseStyle(cocos2d::CCNode* parent,std::string idStyle) {
	beginGameScenePos = ccp(-1,-1);
#ifdef DISABLE_HELP
	return;
#endif	
	if( isVisible()) {
		return;
	}
	
	FIOMNode node = FIOMNode::get("HelpInformation")["styles"][idStyle];
	if( !node.isCorrect()) {
		return;
	}
	if( node.is("countEnable")) {
		int nodeCount = node.getInt("countEnable");
		std::string key = "style-"+idStyle;
		int count = CCUserDefault::sharedUserDefault()->getIntegerForKey(key.c_str());
		if( nodeCount <= count) {
			return;
		}
		CCUserDefault::sharedUserDefault()->setIntegerForKey(key.c_str(), count+1);
		CCUserDefault::sharedUserDefault()->flush();
		ServerController::get()->saveHelpProgress();
	}
	
	if( 0x0 != GameScene::getSingleton() && 0x0 != GameScene::getMapState()) {
		if( node.is("gameScenePosBegin") && node.getBool("gameScenePosBegin")) {
			beginGameScenePos = GameScene::getMapState()->getPosition();
			GameScene::getMapState()->setPositionWithThisSize(0);
		} else if( node.is("gameScenePosEnd") && node.getBool("gameScenePosEnd")) {
			beginGameScenePos = GameScene::getMapState()->getPosition();
			CCSize size = GameScene::getMapState()->getContentSize();
			GameScene::getMapState()->setPositionWithThisSize(-size.width);
		}
	}
		
	idStyleSave = idStyle;
	nameScene = "";
	clearData();
	lastParent = 0x0;
	
	helpLayer = NodeWithResource::node(LoadingData("HELP/"+node.getStr("resource")));
	helpLayer->retain();
	
	if( node.is("pauseAll") && node.getBool("pauseAll")) {
		isPause = true;
	} else {
		isPause = false;
	}
	
	touchEnd = false;
	if( node.is("touchEnd") && node.getBool("touchEnd")) {
		touchEnd = true;
	}
	castEnd = false;
	if( node.is("castEnd") && node.getBool("castEnd")) {
		castEnd = true;
	}
	
	addUnitEnd = false;
	if( node.is("addUnitEnd") && node.getBool("addUnitEnd")) {
		addUnitEnd = true;
	}
	
	float delayV = node.getFloat("delay");
	
	if( isPause) {
		static_pause(parent);
	}
	
	controlElements.clear();
	if( (node.is("reload") && node.getBool("reload")) || 0==loadElements.size()) {
		setAllEnable(loadElements);
		node = node["sprites"];
		
		size_t size = node.getArraySize();
		for( unsigned int i = 0; i < size; i++) {
			FIOMNode element = node[i];
			if( 1 == element.getInt("type")) {
				HelpElementInterface* helpElement = elements[element.getStr("name")];
				loadElements.push_back(helpElement);
				helpElement = enableDisableElementOnHelp(element,helpElement);
				
				if( 0x0 != helpElement) {
					controlElements.push_back(helpElement);
				}
			}
		}
		isLoadElements = true;
	} else {
		isLoadElements = false;
	}
	
	CCDelayTime* delay = CCDelayTime::create(delayV);
	CCCallFuncO* call = CCCallFuncO::create(this, callfuncO_selector(HelpController::enableHelpDelay),parent);
	CCSequence* seq = CCSequence::createWithTwoActions(delay, call);
	seq->setTag(DELAY_TAG);
	helpLayer->runAction(seq);
	parent->addChild(helpLayer,10000);
	lastParent = parent;
	
	fullLoad = false;
}

FIOMNode HelpController::getValuesDict() {
	return FIOMNode::get("HelpInformation")["styles"][idStyleSave]["values"];
}

void HelpController::enableHelpDelay(cocos2d::CCObject* obj) {
	//CCNode* parent = (CCNode*)obj;
	fullLoad = true;
	std::string idStyle = idStyleSave;
	FIOMNode node = FIOMNode::get("HelpInformation")["styles"][idStyle];
	
	if( !isLoadElements){
		setAllEnable(loadElements);
	}
	
	if( node.is("pauseAllDelay") && node.getBool("pauseAllDelay")) {
		isPause = true;
		static_pause(helpLayer->getParent());
	}
	
	if( node.is("delay-for-remove")) {
		CCDelayTime* delay = CCDelayTime::create(node.getFloat("delay-for-remove"));
		CCCallFunc* call = CCCallFunc::create(this, callfunc_selector(HelpController::disableHelp));
		CCSequence* seq = CCSequence::createWithTwoActions(delay, call);
		seq->setTag(DELAY_FOR_REMOVE_TAG);
		helpLayer->runAction(seq);
	}
	
	if( 0x0 != GameScene::getSingleton() && 0x0 != GameScene::getMapState()) {
		if( node.is("gameScenePosBegin") && node.getBool("gameScenePosBegin")) {
			GameScene::getMapState()->setPositionWithThisSize(0);
		}else if( node.is("gameScenePosEnd") && node.getBool("gameScenePosEnd")) {
			CCSize size = GameScene::getMapState()->getContentSize();
			GameScene::getMapState()->setPositionWithThisSize(-size.width);
		}
	}
	
	node = node["sprites"];
	size_t size = node.getArraySize();
	for( unsigned int i = 0; i < size; i++) {
		FIOMNode element = node[i];
		int type = element.getInt("type");
		CCNode* localParent = 0x0;
		
		
		if( element.is("parent")) {
			localParent = dynamic_cast<CCNode*>(elements[element.getStr("parent")]);
		}
		if( 0x0 == localParent) {
			localParent = helpLayer;
		}
		
		switch (type) {
			case 1: if( !isLoadElements){
				HelpElementInterface* helpElement = elements[element.getStr("name")];
				loadElements.push_back(helpElement);
				helpElement = enableDisableElementOnHelp(element,helpElement);
				
				if( 0x0 != helpElement) {
					controlElements.push_back(helpElement);
				}
			}break;
			case 2: addImage(element,localParent,userRect); break;
			case 3: addArrow(element,localParent); break;
			default:
				break;
		}
	}
	
}

void HelpController::clickOnElement(HelpElementInterface* element) {
	restartDelayDisable();
	bool isFind = false;
	for( size_t i =0; i < controlElements.size(); i++) {
		if( controlElements[i] == element) {
			isFind = true;
			break;
		}
	}
	
	
	if ( touchEnd && fullLoad) {
		disableHelp();
	}

	if( isFind) {
		disableHelp();
	}	
}

void HelpController::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	if( pTouches->count() > 0 && touchEnd && fullLoad) {
		disableHelp();
	}
}

void HelpController::castMagic() {
	if( castEnd) {
		disableHelp();
	}
}

void HelpController::addUnit() {
	if( addUnitEnd) {
		disableHelp();
	}
}



float HelpController::getDelay() {
	if( "" != nameScene) {
		int index = CCUserDefault::sharedUserDefault()->getIntegerForKey("help-index")+1;
		std::string idStyle = findCurrentStyle(nameScene,index);
		if( "" == idStyle) {
			return 0;
		}

		FIOMNode node = FIOMNode::get("HelpInformation")["styles"][idStyle];
		return node.getFloat("delay");
	}
	
	return 0;
}

void HelpController::restartDelayDisable() {
	if( !helpLayer) {
		return;
	}

	CCActionInterval* action = (CCActionInterval*)helpLayer->getActionByTag(DELAY_TAG);
	if( action) {
		action->setElapsed(0);
	}
}
void HelpController::endDelayDisable(float time) {
	if( !helpLayer) {
		return;
	}

	CCActionInterval* action = (CCActionInterval*)helpLayer->getActionByTag(DELAY_TAG);
	if( action) {
		action->setElapsed(action->getDuration()-time);
	}
}

void HelpController::disableHelp() {
	if( 0x0 != helpLayer) {
		helpLayer->stopActionByTag(DELAY_FOR_REMOVE_TAG);
		helpLayer->stopActionByTag(DELAY_TAG);
	}
	
	endScene();
	if( isPause && 0x0 != lastParent) {
		static_resume(lastParent);
	}
	
	if( 0x0 == helpLayer) {
		setAllEnable(loadElements);
		return;
	}
	helpLayer->release();
	helpLayer = 0x0;

	
	if( 0x0 != lastParent) {
		enableHelp(lastParent);
	} else {
		setAllEnable(loadElements);
	}
}

void HelpController::addElement(std::string idElement,HelpElementInterface* element) {
	elements[idElement] = element;
}
void HelpController::changeId(std::string idLastElement,std::string idNewElement) {
	std::map<std::string,HelpElementInterface*>::iterator find = elements.find(idLastElement);
	if( find != elements.end()) {
		HelpElementInterface* element = find->second;
		elements.erase(find);
		addElement(idNewElement, element);
	}
}
void HelpController::removeElement(std::string idElement,HelpElementInterface* parent) {
	std::map<std::string,HelpElementInterface*>::iterator find = elements.find(idElement);
	if( 0x0 != parent && find != elements.end() && parent != find->second) {
		return;
	}
	
	if( find != elements.end()) {
		HelpElementInterface* element = find->second;
		for( int i =0; i < (int)loadElements.size(); i++) {
			if( loadElements[i] == element) {
				loadElements.erase(loadElements.begin()+i);
				i--;
			}
		}
		for( int i =0; i < (int)controlElements.size(); i++) {
			if( controlElements[i] == find->second) {
				controlElements.erase(controlElements.begin()+i);
				i--;
			}
		}
		
		elements.erase(find);
	}
}