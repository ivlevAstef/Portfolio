#include "Localization.h"
#include "cocos2d.h"

#include "FIOM/FIOMNode.h"

#define LOCALIZATION_PATH "config/Localization"
#define LOCALIZATION_FILE "Localization"
#define DEFAULT_LOCALE "ru"

using namespace GrizzlyJr;
using namespace cocos2d;

Localization* Localization::singleton = 0x0;

Localization* Localization::get() {
	if( 0x0 == singleton) {
		FIOMMain::get()->loadFile(LOCALIZATION_PATH);
		singleton = new Localization();
		singleton->init();
	}
	return singleton;
}

std::string Localization::getText(std::string idText)const {
	return getTextForLocale(idText, this->locale);
}
std::string Localization::getTextForLocale(std::string idText,std::string locale)const {
	FIOMNode node = FIOMNode::get(LOCALIZATION_FILE)["texts"][idText];
	std::string result = node.getStr(locale);
	if( result.empty()) {
		return "*"+idText+"*";
	}
	return result;
}

void Localization::init() {
	std::string language = CCUserDefault::sharedUserDefault()->getStringForKey("language",getSystemLocale());
#ifdef LOCALIZATION_INIT_LOCALE_ON_START
	language = getSystemLocale();
#endif
	init( language);
}
void Localization::init(std::string locale) {
	
	if( !setLocale(locale)) {
		std::vector<std::string> locales = getAllLocales();
		/*if( locales.size() > 0) {
			this->locale = locales[0];
		}else {*/
			this->locale = DEFAULT_LOCALE;
		//}
	}
}

std::string Localization::getSystemLocale()const
{
	ccLanguageType lang = CCApplication::sharedApplication().getCurrentLanguage();
	switch (lang) {
 	case kLanguageEnglish: return "en"; break;
	case kLanguageChinese: return "ch"; break;
	case kLanguageFrench: return "fr"; break;
	case kLanguageItalian: return "it"; break;
	case kLanguageKorean: return "ko"; break;
	case kLanguageGerman: return "ge"; break;
	case kLanguageSpanish: return "sp"; break;
	case kLanguageRussian: return "ru"; break;
	}
	return "en";
}

void Localization::changeOnNextLocale() {
	std::vector<std::string> locales = getAllLocales();
	if( locales.size() <= 0) {
		return;
	}
	unsigned int i =0;
	for( ; i < locales.size(); i++) {
		if( locales[i] == this->locale) {
			break;
		}
	}
	i = (i+1)%locales.size();
	setLocale(locales[i]);
}
void Localization::changeOnSystemLocale() {
	setLocale(getSystemLocale());
}

bool Localization::setLocale(std::string locale)
{
	std::vector<std::string> locales = getAllLocales();
	for( unsigned int i =0; i < locales.size(); i++) {
		if( locales[i] == locale) {
			this->locale = locale;
			CCUserDefault::sharedUserDefault()->setStringForKey("language",locale);
			return true;
		}
	}
	return false;
}

std::string Localization::getLocale()const
{
	return locale;
}

int Localization::getIndexLocale()const 
{
	std::vector<std::string> locales = getAllLocales();
	for( unsigned int i =0; i < locales.size(); i++) {
		if( locales[i] == locale) {
			return i;
		}
	}
	return 0;
}

std::vector<std::string> Localization::getAllLocales()const  {
	std::vector<std::string> result;
	
	FIOMNode languages = FIOMNode::get(LOCALIZATION_FILE)["languages"];
	const size_t count = languages.getArraySize();
	for( size_t i = 0; i < count; i++) {
		result.push_back(languages.getStr((unsigned int)i));
	}
	
	return result;
}