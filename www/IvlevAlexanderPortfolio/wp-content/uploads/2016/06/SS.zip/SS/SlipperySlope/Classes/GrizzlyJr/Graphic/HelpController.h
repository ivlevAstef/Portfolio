//
//  HelpController.h
//  cuteheroes
//
//  Created by Alexander Ivlev on 03.10.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//


#ifndef _GRIZZLY_JR_CUTE_HEROES_HELP_CONTROLLER_H_
#define _GRIZZLY_JR_CUTE_HEROES_HELP_CONTROLLER_H_

#include "cocos2d.h"
#include "HelpElementInterface.h"
#include "NodeWithResource.h"
#include <GrizzlyJr/SceneController/LoadingData.h>
#include <map>
#include <string>
#include <GrizzlyJr/FileImageOnMemory/FIOMNode.h>

#include "Config/ConfigDefine.h"

namespace GrizzlyJr
{
	namespace CuteHeroes {
		class HelpController: public cocos2d::CCObject, public cocos2d::CCTouchDelegate {
		private:
			friend class HelpElementInterface;
			static HelpController* singleton;
			
			std::map<std::string,HelpElementInterface*> elements;
					
			NodeWithResource* helpLayer;
			std::string nameScene;
			
			cocos2d::CCNode* lastParent;
			
			std::vector<HelpElementInterface*> controlElements;
			std::vector<HelpElementInterface*> loadElements;
			
			bool isLoadElements;
			bool isPause;
			
			std::string idStyleSave;
			
			std::map<std::string,cocos2d::CCRect> userRect;
			bool castEnd;
			bool addUnitEnd;
			bool touchEnd;
			
			bool fullLoad;
			
			cocos2d::CCPoint beginGameScenePos;
		public:
			static HelpController* get();
			static void remove();
			
			void changeScene(std::string idScene);
			void enableHelp(cocos2d::CCNode* parent);
			
			cocos2d::CCNode* getLayer()const { return helpLayer; }
			
			void enableHelpUseStyle(cocos2d::CCNode* parent,std::string idStyle);
			void clearData();
			
			void addElement(std::string idElement,HelpElementInterface* element);
			void changeId(std::string idLastElement,std::string idNewElement);
			void removeElement(std::string idElement,HelpElementInterface* element);
			
			void addUserRect(std::string name,cocos2d::CCRect rect) {
				userRect[name] = rect;
			}
			cocos2d::CCRect getUserRect(std::string name) {
				return userRect[name];
			}
			
			void castMagic();
			void addUnit();
			
			FIOMNode getValuesDict();
			
			bool isVisible() {
				if( 0x0 != helpLayer) {
					return true;
				}
				return false;
			}
			
			std::string getScene();
			void* getInfoScene();
			
			void restartDelayDisable();
			void endDelayDisable(float time);
			
			virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
			
			
			void changeArrow(CCObject* arrowBase);
			
			
			void clickOnElement(HelpElementInterface* element);///private
			
			void disableHelp();
		private:
			void endScene();
			
			void enableHelpDelay(cocos2d::CCObject* parent);
			
			HelpController();
			~HelpController();
			
			float getDelay();
			
			void stopMyAction();
		};
	};
};

#endif

