//
//  Wheel.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_WHEEL_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_WHEEL_H_

#include "AutoElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Wheel: public AutoElement {
		private:
			float radius;
		public:
			Wheel(std::string name);
			
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale);
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale);
			
			float getRadius()const { return radius; }
		};
	};
};

#endif