#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_CONFIG_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_CONFIG_H_

#include <string>

namespace GrizzlyJr
{
	class Config
	{
	public:
		static const int application_version;
		static Config* c;
	public:
		enum MenuType {
			BIG_MENU,
			SMALL_MENU
		} menuType;
		
		std::string postfixFile;
		std::string prefixFile;
		
		bool isRetina;
		float winWidth;
		float winHeight;
		
		bool isFirstLaunch;
		
		Config();
		void init();
	};
};
#endif
