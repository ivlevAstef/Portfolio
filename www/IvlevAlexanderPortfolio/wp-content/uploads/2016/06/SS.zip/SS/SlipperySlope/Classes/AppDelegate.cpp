//
//  SlipperySlopeAppDelegate.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#include "AppDelegate.h"

#include "cocos2d.h"
#include "SplashLayer.h"
#include "Config/Config.h"

USING_NS_CC;

AppDelegate::AppDelegate() {
}

AppDelegate::~AppDelegate() {
}

bool AppDelegate::applicationDidFinishLaunching() {
	new GrizzlyJr::Config();
    // initialize director
    CCDirector *pDirector = CCDirector::sharedDirector();
	CCEGLView& view = CCEGLView::sharedOpenGLView();
	pDirector->setOpenGLView(&view);
	pDirector->enableRetinaDisplay(true);
		
	//view.setDesignResolutionSize(frameSize.width, frameSize.height);
	CCFileUtils::sharedFileUtils()->setiPhoneRetinaDisplaySuffix("");
	CCFileUtils::sharedFileUtils()->setiPadRetinaDisplaySuffix("");
	CCFileUtils::sharedFileUtils()->setiPadSuffix("");

    // enable High Resource Mode(2x, such as iphone4) and maintains low resource on other devices.
	CCSize frameSize = pDirector->getWinSizeInPixels();

    // turn on display FPS
    pDirector->setDisplayStats(false);

    // set FPS. the default value is 1.0/60 if you don't call this
    pDirector->setAnimationInterval(1.0 / 60);
	
	GrizzlyJr::Config::c->winWidth = frameSize.width;
	GrizzlyJr::Config::c->winHeight = frameSize.height;
	GrizzlyJr::Config::c->isRetina = (pDirector->getContentScaleFactor() >= 2.0f-1.0e-3f);
   
	GrizzlyJr::SlipperSlope::SplashLayer::create();
    return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void AppDelegate::applicationDidEnterBackground()
{
    CCDirector::sharedDirector()->stopAnimation();

    // if you use SimpleAudioEngine, it must be pause
    // SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground()
{
    CCDirector::sharedDirector()->startAnimation();
    
    // if you use SimpleAudioEngine, it must resume here
    // SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
}
