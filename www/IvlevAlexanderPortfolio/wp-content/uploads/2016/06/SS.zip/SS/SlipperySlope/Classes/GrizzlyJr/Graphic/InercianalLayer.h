#ifndef _GRIZZLY_JR_INERCIANAL_LAYER_H_
#define _GRIZZLY_JR_INERCIANAL_LAYER_H_

#include "cocos2d.h"

namespace GrizzlyJr
{
	class InercianalLayer : public cocos2d::CCLayer
	{
	public:
		enum EventChange {
			BEGIN_TOUCH,
			MOVE_TOUCH,
			END_TOUCH,
			CANCEL_TOUCH
		};
		
		struct EventChangeParameter {
			EventChange lastE;
			EventChange newE;
			cocos2d::CCPoint pointOnView;
			cocos2d::CCPoint beginPointOnView;
		};
		
		class IListener {
		public:
			virtual void eventStateChange(EventChangeParameter parametr, int number) = 0;
		};
		
	private:
		struct touchInformation {
			cocos2d::CCPoint touchBegin;
			cocos2d::CCPoint touchLast;
			cocos2d::CCPoint touchLastForNumber;
			
			EventChangeParameter parameter;
		};
		
		std::map<int,touchInformation> touches;
	
		std::vector<IListener*> listeners;
		
	 	float minDirLength;
			
		float speed;
		float acceselerometr;
			
		cocos2d::CCPoint thisBegin;
		cocos2d::CCPoint dir;
		float time;
		bool isInercial;
		float timeLastMove;
		
		bool isPauseScroll;
		bool isPauseTouch;
	public:
		static InercianalLayer* create(std::string name);
		
		InercianalLayer();
		InercianalLayer(std::string name);
		
		void addListener(IListener* listener);
		void removeListener(IListener* listener);
		
		void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		void ccTouchCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
			
		void tick(float time);
		
		void pauseTouch();
		void resumeTouch();
		
		void pauseScroll();
		void resumeScroll();
		
		virtual void pauseScrollAndTouch();
		virtual void resumeScrollAndTouch();
		
		void end();
		
		void setPositionWithThisSize(float x) {
			setPositionWithThisSize(x,this->getPosition().y);
		}
	private:
		
		void init(std::string name);
		
		void setPositionWithThisSize(float x, float y);
		
		void listenerAll(int number);
		
		int getNumberTouch(cocos2d::CCTouch* touch);
	};
};

#endif