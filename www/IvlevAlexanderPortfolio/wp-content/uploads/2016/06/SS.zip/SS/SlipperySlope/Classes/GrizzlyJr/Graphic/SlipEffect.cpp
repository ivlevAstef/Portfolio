//
//  SlipEffect.cpp
//  particles
//
//  Created by Alexander Ivlev on 30.08.13.
//
//

#include "SlipEffect.h"

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

const float SlipEffect::scale = 0.75f;

SlipEffect* SlipEffect::create(cocos2d::CCPoint speed,cocos2d::CCSpriteFrame* smoke_tex,cocos2d::CCSpriteFrame* stone_tex) {
	SlipEffect* effect = new SlipEffect();
	if( effect && effect->init(speed,smoke_tex,stone_tex)) {
		effect->autorelease();
		return effect;
	}
	CC_SAFE_DELETE(effect);
	return 0x0;
}
bool SlipEffect::init(cocos2d::CCPoint speed,cocos2d::CCSpriteFrame* smoke_tex,cocos2d::CCSpriteFrame* stone_tex) {
	float duration = 0.5f;
	
	if( smoke_tex) {
		if( !initSmoke(speed,duration,smoke_tex)) {
			return false;
		}
	}
	
	if( stone_tex) {
		if( !initStone(speed,duration,stone_tex)) {
			return false;
		}
	}
	
	CCDelayTime* delay = CCDelayTime::create(duration+1.0f);
	CCCallFunc* call = CCCallFunc::create(this, callfunc_selector(SlipEffect::end));
	this->runAction(CCSequence::create(delay,call,0x0));
	
	return true;
}

void SlipEffect::update(float dt) {
	stone->update(dt);
	smoke->update(dt);
}

bool SlipEffect::initSmoke(cocos2d::CCPoint speed,float duration,cocos2d::CCSpriteFrame* texture) {
	static const int count = 40;
	
	smoke = new CCParticleSystemQuad();
	if( !smoke || !smoke->initWithTotalParticles(count)) {
		CC_SAFE_DELETE(smoke);
		return false;
	}
	
	smoke->setPositionType(kCCPositionTypeRelative);
	smoke->setTextureWithRect(texture->getTexture(),texture->getRect());
	float angle = CC_RADIANS_TO_DEGREES(ccpAngleSigned(speed, ccp(1,0)));
	float sign = (speed.x>0)?1:-1;
	
	float length = ccpLength(speed);
	float size = texture->getRect().size.width*scale;
	
	smoke->setDuration(duration);
	
	smoke->autorelease();
	smoke->setPosition(ccp(0,0));
	this->addChild(smoke);
	
	smoke->setEmitterMode(kCCParticleModeGravity);
	smoke->setGravity(ccp(0,0));
	
	smoke->setSpeed(length*scale);
	smoke->setSpeedVar(length*scale*0.1f);
	
	smoke->setRadialAccel(0);
	smoke->setRadialAccelVar(0);
	
	smoke->setTangentialAccel(0);
	smoke->setTangentialAccelVar(0);
	
	smoke->setPosVar(ccp(10,0));
	
	smoke->setAngle(angle+sign*145);
	smoke->setAngleVar(20);
	
	smoke->setLife(0.9f);
	smoke->setLifeVar(0.08f);
	
	smoke->setStartSize(size);
	smoke->setStartSizeVar(size*0.3f);
	
	smoke->setEndSize(kCCParticleStartSizeEqualToEndSize);
	smoke->setEmissionRate(count/duration);
	
	setSmokeColor(ccc3(200, 200, 200));
	
	return true;
}


bool SlipEffect::initStone(cocos2d::CCPoint speed,float duration,cocos2d::CCSpriteFrame* texture) {
	static const int count = 7;
	
	stone = new CCParticleSystemQuad();
	if( !stone || !stone->initWithTotalParticles(count)) {
		CC_SAFE_DELETE(stone);
		return false;
	}
	
	stone->setPositionType(kCCPositionTypeRelative);
	stone->setTextureWithRect(texture->getTexture(),texture->getRect());
	float angle = CC_RADIANS_TO_DEGREES(ccpAngleSigned(speed, ccp(1,0)));
	float sign = (speed.x>0)?1:-1;
	CCLog("%f",angle);
	
	float length = ccpLength(speed);
	float size = texture->getRect().size.width*scale;
	
	stone->setDuration(duration);
	
	stone->autorelease();
	stone->setPosition(ccp(0,0));
	this->addChild(stone);
	
	stone->setEmitterMode(kCCParticleModeGravity);
	stone->setGravity(ccp(0,-length*scale*0.5f));
	
	stone->setSpeed(length*scale);
	stone->setSpeedVar(length*scale*0.15f);
	
	stone->setRadialAccel(length*scale*0.5f);
	stone->setRadialAccelVar(1);
	
	stone->setTangentialAccel(length*scale*0.4f);
	stone->setTangentialAccelVar(length*scale*0.2f);
	
	stone->setPosVar(ccp(10,0));
	
	stone->setAngle(angle+sign*145);
	stone->setAngleVar(15);
	
	stone->setLife(0.75f);
	stone->setLifeVar(0.08f);
	
	stone->setStartSize(size*0.5f);
	stone->setStartSizeVar(size*0.25f);
	
	stone->setEndSize(kCCParticleStartSizeEqualToEndSize);
	stone->setEmissionRate(count/duration);
	
	setStoneColor(ccc3(42, 221, 235));
	
	return true;
}

void SlipEffect::setStoneColor(cocos2d::ccColor3B color) {
	stone->setStartColor(ccc4f(color.r/255.0f, color.g/255.0f, color.b/255.0f, 1));
	stone->setStartColorVar(ccc4f(0.1f, 0.1f, 0.1f, 0));
	
	color.r *= 0.9f;
	color.g *= 0.9f;
	color.b *= 0.9f;
	stone->setEndColor(ccc4f(color.r/255.0f,color.r/255.0f,color.r/255.0f,0));
	stone->setEndColorVar(ccc4f(0.01f,0.01f,0.01f,0.1f));
}

void SlipEffect::setSmokeColor(cocos2d::ccColor3B color) {
	smoke->setStartColor(ccc4f(color.r/255.0f, color.g/255.0f, color.b/255.0f, 1));
	smoke->setStartColorVar(ccc4f(0.1f, 0.1f, 0.1f, 0.1f));
	
	color.r *= 0.1f;
	color.g *= 0.1f;
	color.b *= 0.1f;
	smoke->setEndColor(ccc4f(color.r/255.0f,color.r/255.0f,color.r/255.0f,0));
	smoke->setEndColorVar(ccc4f(0.1f,0.1f,0.1f,0.01f));
}

void SlipEffect::end() {
	if( this->getParent()) {
		this->getParent()->removeChild(this, true);
	}
}
