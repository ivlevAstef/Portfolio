#ifndef _GRIZZLY_JR_LOADING_DATA_H_
#define _GRIZZLY_JR_LOADING_DATA_H_

#include <string>

namespace GrizzlyJr
{
	struct LoadingData
	{
		enum Format
		{
			PIXEL_RGBA8888,
			PIXEL_RGB565,
			PIXEL_RGBA4444,
			PIXEL_RGBA5551,
			PIXEL_A8,
		} format;
			
		std::string name;
		float size;
			
		LoadingData():format(PIXEL_RGBA8888),size(0) { name = "";}
		LoadingData(std::string name):format(PIXEL_RGBA8888),size(0),name(name) {}
			
		LoadingData(std::string name,float size):format(PIXEL_RGBA8888),size(size),name(name) {}
		LoadingData(std::string name,Format format):format(format),size(0),name(name) {}
			
		LoadingData(std::string name,Format format,float size):format(format),size(size),name(name) {}

		bool operator <(LoadingData const &p)const {
			return name < p.name;
		}
	};
};
#endif
