#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_BUTTON_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_BUTTON_H_

#include "cocos2d.h"
#include <ScaleCCSprite.h>
#include "HelpElementInterface.h"
#include "../Gesture/GestureListener.h"

namespace GrizzlyJr
{
	class Button: public cocos2d::CCMenu, public HelpElementInterface
	{
	public:
		static bool disable_button;
	private:
		bool working_all_time;
		cocos2d::CCMenuItemSprite* itemSprite;
		
		bool isEnableClick;
		
		bool isClickV;
		
		float radius;
		
		cocos2d::CCObject* b_target;
		cocos2d::SEL_MenuHandler b_selector;
		cocos2d::SEL_SCHEDULE pressed_selector;
		
		bool isTab;
		bool isPressed;
		bool isStartPress;
		
		std::vector<Button*> self_links;
		std::vector<Button*> linked_button;
		
		cocos2d::CCPoint begin_pos;
		cocos2d::CCPoint touch_pos;
	public:
		Button() { itemSprite = 0x0; isEnableClick = true; working_all_time =false;}
		~Button();
		static Button* create(const char* normal,const char* select,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector);
		///automatic add ".png" for normal and "-select.png" for select sprites
		static Button* create(const char* name,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector);
		bool init(const char* normal,const char* select,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector);
		///automatic add ".png" for normal and "-select.png" for select sprites
		bool init(const char* name,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector);
		
		///call on all tick if pressed
		void setPressedSelector(cocos2d::SEL_SCHEDULE pressed_selector);
		
		void addLinkedButton(Button* button);
		void removeLinkedButton(Button* button);
		
		void setWorkingAllTime(bool is_working) { this->working_all_time = is_working; }
		
		///all add method remove last node
		void addTextID(const char* idText,const char* idLocation);
		void addTextID(const char* idText,const char* idLocationNormal,const char* idLocationSelect);
		void addText(const char* text,const char* idLocation);
		void addText(const char* text,const char* idLocationNormal,const char* idLocationSelect);
		
		void addNumber(const char* prefix,int number,const char* idLocation);
		void addNumber(const char* prefix,int number,const char* idLocationNormal,const char* idLocationSelect);
		
		///automatic add ".png" for normal and "-select.png" for select sprites
		void addImage(const char* name);
		void addImage(const char* normal,const char* select);
		
		void removeAllChild();
		
		void setTab(bool isTab) { this->isTab = isTab; }
		
		cocos2d::CCNode* getChild();
		
		virtual void setColor(const cocos2d::ccColor3B& color);
		virtual const cocos2d::ccColor3B& getColor(void);
		virtual GLubyte getOpacity(void);
		virtual void setOpacity(GLubyte opacity);
		
		void flipX(bool isFlip);
		void flipY(bool isFlip);
		
		cocos2d::CCSize getSize();
		
		ScaleCCSprite* getNormal();
		ScaleCCSprite* getSelect();
		cocos2d::CCMenuItemSprite* getItemSprite()const { return itemSprite; }
				
		virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		virtual void ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		
		virtual bool ccTouchBegan(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
		virtual void ccTouchMoved(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
		virtual void ccTouchEnded(cocos2d::CCTouch *touch, cocos2d::CCEvent* event);
		virtual void ccTouchCancelled(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
		
		virtual void enableOnHelp();
		virtual void disableOnHelp();
		
		virtual void addNodeChild(void* child);
		virtual float getWidth();
		virtual float getHeight();
		
		void useRadialButtonTest(float radius);
		
		bool isClick()const { return isClickV; }
	protected:
		///TODO: in cocos set function virtual
		virtual cocos2d::CCMenuItem* itemForTouch(cocos2d::CCTouch *touch);
		
	private:
		void changeStateLinkedButtons();
		void clickButton(cocos2d::CCObject* obj);
		
		virtual void update(float dt);
	};
};
#endif
