//
//  PhysicAuto.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.06.13.
//
//

//
//  Auto.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_PHYSIC_AUTO_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_PHYSIC_AUTO_H_

#include "Auto.h"
#include "Box2D.h"
#include <deque>


namespace GrizzlyJr {
	namespace SlipperSlope {
		class PhysicAuto: public cocos2d::CCNode {
		public:
			struct ContactWheelInfo {
				cocos2d::CCPoint wpos;
				float angular_speed;
				cocos2d::CCPoint speed;
				cocos2d::CCPoint normal_impulse;
			};
		private:
			struct Motor {
				b2RevoluteJoint* motor;
				AutoElement* wheel;
				AutoElement* engine;
			};
			std::vector<Motor> motors;
			std::vector<AutoElement*> wheels;
			cocos2d::CCPoint translate;
			cocos2d::CCPoint driver_pos;
			AutoElement* driver;
			
			float begin_angle;
			float mass;
			
			float auto_scale;
			
			float air_time;
			cocos2d::CCPoint speed;
			std::deque<cocos2d::CCPoint> speed_five;
			
			cocos2d::CCRect dimensions;
			float depth;
			float angle;
			
			float gas;
			float full_gas;
			float gas_air_mult;
			float gas_ground_mult;
		public:
			static PhysicAuto* create(Auto* image_auto,b2World* world,float scale);
			virtual bool init(Auto* image_auto,b2World* world,float scale);
			static PhysicAuto* create(Auto* image_auto,float scale);
			virtual bool init(Auto* image_auto,float scale);
			
			virtual void visit();
			
			void setSpeed(float mult,float dt);
			void rotateLeft(float dt);
			void rotateRight(float dt);
			
			void stabilization(float dt);
			
			void setTranslate(const cocos2d::CCPoint& var) { this->translate = var; recalcDriver();}
			void setTranslateX(const float& var) { this->translate.x = var; recalcDriver(); }
			void setTranslateY(const float& var) { this->translate.y = var; recalcDriver(); }
			cocos2d::CCPoint getPositionOnScreen();
			const cocos2d::CCPoint& getSpeed()const { return speed; }
			void update(float dt);
			
			const cocos2d::CCRect& getDimensions()const { return dimensions; }
			float getDepth()const { return depth; }
			
			float getAngle()const { return angle; }
			
			void initGas(float gas_v) { gas = full_gas = gas_v; }
			float getGas()const { return gas; }
			float getFullGas()const { return full_gas; }
			
			std::vector<ContactWheelInfo> getAllContactsWheel();
		private:
			std::vector<cocos2d::CCPoint> findMounting(AutoElement* a1, AutoElement* a2);
			void createRevoluteJoint(cocos2d::CCPoint point,AutoElement* e1, AutoElement* e2, b2World* world);
			
			void createMotorIfNeed(AutoElement* e1, AutoElement* e2,b2RevoluteJoint* joint);
			
			void visit3dView();
			void visitNormal();
			
			void recalcDriver();
		};
	};
};

#endif