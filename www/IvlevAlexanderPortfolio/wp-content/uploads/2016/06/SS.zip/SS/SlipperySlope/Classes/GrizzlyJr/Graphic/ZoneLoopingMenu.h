//
//  ZoneLoopingMenu.h
//  CuteHeroes
//
//  Created by Alexander Ivlev on 23.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPER_ZONE_LOOPING_MENU_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPER_ZONE_LOOPING_MENU_H_

#include "cocos2d.h"
#include "../Gesture/GestureListener.h"

namespace GrizzlyJr
{
	typedef enum OrientationLoopingMenu {
		OLM_HORIZONTAL,
		OLM_HORIZONTAL_REVERSE,
		OLM_VERTICAL,
		OLM_VERTICAL_REVERSE,
	} OrientationLoopingMenu;
	
	
	#define MENU_CHILD_USE_CENTER_WINDOW_TAG 1245
	class ZoneLoopingMenu: public cocos2d::CCLayerColor, public GestureListener
	{
	public:
		class ListenerZoneLoopingMenu {
		public:
			virtual void clickOnElement(cocos2d::CCNode* node) = 0;
		};
	private:
		cocos2d::CCRect area;
		cocos2d::CCPoint dir;
		float padding;
		float paddingEdge;
		float pos;/// 0..len
		float len;/// len >= 0
		float lenPos;/// = area.width || area.height (Orientation)
		
		float beginPos;
		float beginSpeed;
		float time;
		
		bool isTouch;
		float lastMove;
		float lastDt;
		
		float speed;
		float acceleration;
		float accMult;
		
		cocos2d::CCPoint windowTranslate;
		float nodeTranslateAdd;
		
		bool isPause;
		
		float autoScrollSpeed;
		
		float anchorPointForFewElements;
		float visit_scale_factor;
		bool is_circle;
		
		std::vector<ListenerZoneLoopingMenu*> listeners;
		cocos2d::CCNode* pre_node;
	public:
		static ZoneLoopingMenu* createOnRect(cocos2d::CCRect rect,float scaleFactor=1);
		bool initOnRect(cocos2d::CCRect rect,float scaleFactor=1);
		
		void addListener(ListenerZoneLoopingMenu* listener);
		void removeListener(ListenerZoneLoopingMenu* listener);
		
		void setIsCircle(bool is_circle) { this->is_circle = is_circle; }
		
		bool isFewElements();
		
		void setAnchorPointForFewElements(float ah) {anchorPointForFewElements = ah; }
		
		virtual void addChild(cocos2d::CCNode* child, int zOrder, int tag);
		virtual void removeChild(cocos2d::CCNode* node, bool cleanup);
		void changeChild(cocos2d::CCNode* child,cocos2d::CCNode* enwChild);
		
		void setOrientation(OrientationLoopingMenu orient);
		void setPadding(float padding);
		void setPaddingEdge(float paddingEdge);
		
		void setAutoScroll(float speed);
		
		void updatePositionChildren();
		void updatePosition();
		
		void pause() { isPause = true; }
		void resume() { isPause = false; }
		
		void setScrollingSpeed(float speed, float acc);
		
		void setWindowTranslate(cocos2d::CCPoint translate);
		inline void setNodeTranslate(float newT) { nodeTranslateAdd = newT; }
		
		inline cocos2d::CCRect getArea()const { return area;  }
		float getProcent()const;///0-1
		inline float getLength()const { return len; }
		
		void setPositionUseNode(cocos2d::CCNode* node);
		
		virtual void setOpacity(GLubyte opacity);
		
		virtual void removeAllChildrenWithCleanup(bool cleanup);
		
		~ZoneLoopingMenu();
	private:
		void tick(float dt);
		
		bool testOnEnd();
		
		void endTouch(float move);
		void onExit();
		void visit();
		
		virtual void resumeSchedulerAndActions(void);
		virtual void pauseSchedulerAndActions(void);
		
		virtual bool beginAction(cocos2d::CCPoint pos,GestureType type);
		virtual void move(cocos2d::CCPoint pos,cocos2d::CCPoint delta,cocos2d::CCPoint move,cocos2d::CCPoint speed);
		virtual void endAction(cocos2d::CCPoint pos,GestureType type);
		
		cocos2d::CCNode* findNodeForPosition(cocos2d::CCPoint pos);
	};
};
#endif