//
//  3DElement.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 14.08.13.
//
//

#include "3DElement.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Location.h>

USING_NS_CC;

using namespace GrizzlyJr;
using namespace SlipperSlope;

_3DElement::_3DElement() {
	depth = Location::get("Positions")["ElementInfo"].getLFloat("3d_depth",Location::CHANGE_Y);
	CCSize world_size = CCDirector::sharedDirector()->getWinSize();
	center = ccp(0,-world_size.height);
}

void _3DElement::visit3dView(float glob_angle) {
	CCPoint pos_on_image = calc3dTranslate(glob_angle);
	
	CCObject* obj = 0x0;
	ScaleCCSprite* image = 0x0;
	
	CCARRAY_FOREACH(m_pChildren, obj) {
		image = (ScaleCCSprite*) obj;
		image->setColor(ccc3(160, 160, 160));
		image->setPosition(ccpAdd(image->getPosition(), pos_on_image));
	}
	_3DElement::visit();
	
	CCARRAY_FOREACH(m_pChildren, obj) {
		image = (ScaleCCSprite*) obj;
		image->setColor(ccc3(255, 255, 255));
		image->setPosition(ccpSub(image->getPosition(), pos_on_image));
	}
}

cocos2d::CCPoint _3DElement::calc3dTranslate(float glob_angle) {
	CCPoint world_pos = this->convertToWorldSpace(ccp(0,0));
	CCSize world_size = CCDirector::sharedDirector()->getWinSize();
	world_pos = ccpAdd(world_pos, center);
	world_pos.x /= world_size.width;
	world_pos.y /= world_size.height;
	
	CCPoint translate = ccp(-depth*world_pos.x,-depth*world_pos.y);
	translate.y = MAX(0,translate.y);
	
	float radians = -CC_DEGREES_TO_RADIANS(getRotation());
	CCPoint pos_on_image = ccpRotateByAngle(translate, ccp(0,0), -radians+glob_angle);
	pos_on_image.x *= getScaleX();
	pos_on_image.y *= getScaleY();
	
	return pos_on_image;
}
