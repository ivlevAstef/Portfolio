//
//  Box2DCocos.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.06.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPER_BOX2D_COCOS_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPER_BOX2D_COCOS_H_

#include "Box2d.h"
#include "Cocos2d.h"

namespace GrizzlyJr {
	struct Box2DCocos {
	private:
		static float PTM_RATIO_X;
		static float PTM_RATIO_Y;
		static float default_constant;
	public:
		static void init();
		
		static float getRatioX() { return PTM_RATIO_X;}
		static float getRatioY() { return PTM_RATIO_Y;}
		static float getDefaultConstant() { return default_constant;}
		
		static b2Vec2 convert(cocos2d::CCPoint pos) {
			return b2Vec2(pos.x/PTM_RATIO_X,pos.y/PTM_RATIO_Y);
		}
		static cocos2d::CCPoint convert(b2Vec2 pos) {
			return cocos2d::CCPoint(pos.x*PTM_RATIO_X, pos.y*PTM_RATIO_Y);
		}
		
		static float convertToCocos2D(float angle) {
			return -1 * CC_RADIANS_TO_DEGREES(angle);
		}
		static float convertToBox2d(float angle) {
			return -1 * CC_DEGREES_TO_RADIANS(angle);
		}
		
		static float convertLengthToBox2d(float l) {
			return l/PTM_RATIO_X;
		}
		static float convertLengthToCocos2D(float l) {
			return l*PTM_RATIO_X;
		}
		
	};
};


#endif
