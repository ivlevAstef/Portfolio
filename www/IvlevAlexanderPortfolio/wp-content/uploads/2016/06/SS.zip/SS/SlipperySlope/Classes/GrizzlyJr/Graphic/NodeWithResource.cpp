#include "NodeWithResource.h"
#include "../SceneController/SceneController.h"
#include "../Log/LogFunction.h"

using namespace GrizzlyJr;

NodeWithResource* NodeWithResource::node(std::vector<LoadingData> data) {
	NodeWithResource* node = new NodeWithResource(data);
	node->autorelease();
	return node;
}

NodeWithResource* NodeWithResource::node(LoadingData data) {
	NodeWithResource* node = new NodeWithResource(data);
	node->autorelease();
	return node;
}

NodeWithResource::NodeWithResource(std::vector<LoadingData> data) {
	init(data);
}

NodeWithResource::NodeWithResource(LoadingData data) {
	init(data);
}


bool NodeWithResource::init(std::vector<LoadingData> data) {
	this->data = data;
	for( unsigned int i = 0; i < data.size(); i++) {
		SceneController::get()->loadDataIsNeeded(data[i]);
	}
	return true;
}

bool NodeWithResource::init(LoadingData data) {
	std::vector<LoadingData> dataV;
	NormalLog("%s",data.name.c_str());
	dataV.push_back(data);
	return init(dataV);
}

NodeWithResource::~NodeWithResource() {
	for( unsigned int i = 0; i < data.size(); i++) {
		SceneController::get()->unloadDataIsNeeded(data[i]);
	}
}