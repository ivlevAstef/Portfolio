#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_REDACTOR_SCENE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_REDACTOR_SCENE_H_

#include "cocos2d.h"
#include <GrizzlyJr/SceneController/SceneInformation.h>
#include "Auto.h"
#include <GrizzlyJr/Gesture/GestureListener.h>
#include <GrizzlyJr/Graphic/ZoneLoopingMenu.h>
#include <GrizzlyJr/Graphic/LabelLocalization.h>
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>

namespace GrizzlyJr {
	namespace SlipperSlope {
		
		class RedactorScene: public cocos2d::CCLayer, public GestureListener {
		private:
			cocos2d::CCSprite* menu_back;
			
			Auto* self_auto;
			AutoElement* select;
			cocos2d::CCPoint begin_pos;
			cocos2d::CCPoint last_real_pos;
			cocos2d::CCPoint last_speed;
			
			ZoneLoopingMenu* loop_menu;
			
			cocos2d::CCRect grid_rect;
			cocos2d::CCRect grid_init_rect;
			size_t grid_width;
			size_t grid_height;
			
			cocos2d::CCSprite* grid_point;
			
			LabelLocalization* help_label;
			ScaleCCSprite* help_plashka;
		public:
			RedactorScene() {}
			virtual ~RedactorScene();
			static cocos2d::CCScene* scene(void* p);
			
			static SceneInformation getSceneInformation();
			bool init();
		private:
			void clickRun(cocos2d::CCObject* obj);
			void clickClean(cocos2d::CCObject* obj);
			
			virtual void draw();
			virtual void visit();
			
			AutoElement* getObjectIn(cocos2d::CCPoint pos,cocos2d::CCPoint& begin_pos);
			AutoElement* getObjectIn(cocos2d::CCPoint pos);
			bool setObjectInGrid(AutoElement* obj);
			
			
			virtual bool beginAction(cocos2d::CCPoint pos,GestureType type);
			virtual float getScaleMult();
			virtual void scale(float scale);
			virtual void move(cocos2d::CCPoint pos,cocos2d::CCPoint delta,cocos2d::CCPoint move,cocos2d::CCPoint speed);
			virtual void rotate(float angle,float delta_angle);
			virtual void endAction(cocos2d::CCPoint pos,GestureType type);
			
			void disableHelp();
		};
	};
};
#endif
