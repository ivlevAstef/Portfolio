//
//  FadeOnAllChilds.cpp
//  SlipperSlope
//
//  Created by Alexander Ivlev on 04.10.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "FadeOnAllChilds.h"

using namespace cocos2d;
using namespace GrizzlyJr;

FadeOnAllChilds* FadeOnAllChilds::create(float duration, GLubyte opacity)
{
	FadeOnAllChilds* pFade = new FadeOnAllChilds();
	pFade->initWithDuration(duration, opacity);
	pFade->autorelease();
	
	return pFade;
}

FadeOnAllChilds* FadeOnAllChilds::create(float duration, GLubyte opacity,bool isReverse)
{
	FadeOnAllChilds* pFade = new FadeOnAllChilds();
	pFade->initWithDuration(duration, opacity,isReverse);
	pFade->autorelease();
	
	return pFade;
}

bool FadeOnAllChilds::initWithDuration(float duration, GLubyte opacity)
{
	return initWithDuration(duration,opacity,false);
}

bool FadeOnAllChilds::initWithDuration(float duration, GLubyte opacity,bool isReverse)
{
	if (CCActionInterval::initWithDuration(duration))
	{
		this->isReverse = isReverse;
        m_toOpacity = opacity;
		return true;
	}
	
	return false;
}

CCObject* FadeOnAllChilds::copyWithZone(CCZone *pZone)
{
	CCZone* pNewZone = NULL;
	FadeOnAllChilds* pCopy = NULL;
	if(pZone && pZone->m_pCopyObject) 
	{
		//in case of being called at sub class
		pCopy = (FadeOnAllChilds*)(pZone->m_pCopyObject);
	}
	else
	{
		pCopy = new FadeOnAllChilds();
		pZone = pNewZone = new CCZone(pCopy);
	}
	
	CCActionInterval::copyWithZone(pZone);
	
	pCopy->initWithDuration(m_fDuration, m_toOpacity,isReverse);
	
	CC_SAFE_DELETE(pNewZone);
	return pCopy;
}

static void getAllOpacity(std::map<CCNode*,GLubyte>& map, CCNode* node) {
	CCRGBAProtocol *pRGBAProtocol = dynamic_cast<CCRGBAProtocol*>(node);
	if (pRGBAProtocol) {
		map[node] = pRGBAProtocol->getOpacity();
	}
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(node->getChildren(),iter) {
		CCNode* child = dynamic_cast<CCNode*>(iter);
		if( child) {
			getAllOpacity(map, child);
		}
	}
}

void FadeOnAllChilds::startWithTarget(CCNode *pTarget)
{
	CCActionInterval::startWithTarget(pTarget);
	
	getAllOpacity(m_fromOpacity,pTarget);
}

void FadeOnAllChilds::setAllOpacityOnNode(cocos2d::CCNode* node, GLubyte opacity) {
	CCRGBAProtocol *pRGBAProtocol = dynamic_cast<CCRGBAProtocol*>(node);
	if( pRGBAProtocol) {
		pRGBAProtocol->setOpacity(opacity);
	}

	
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(node->getChildren(),iter) {
		CCNode* child = dynamic_cast<CCNode*>(iter);
		if( child) {
			setAllOpacityOnNode(child,opacity);
		}
	}
}

static void setAllOpacity(const std::map<CCNode*,GLubyte>& map, CCNode* node, float time, GLubyte endOpacity,bool isReverse) {
	std::map<CCNode*,GLubyte>::const_iterator find = map.find(node);
	CCRGBAProtocol *pRGBAProtocol = dynamic_cast<CCRGBAProtocol*>(node);
	if( find != map.end() && pRGBAProtocol) {
		float beginOpacity = find->second;
		float opacity = beginOpacity + (endOpacity - beginOpacity)*time;
		if( isReverse) {
			opacity = endOpacity + (beginOpacity - endOpacity)*time;
		}
		
		pRGBAProtocol->setOpacity((GLubyte)opacity);
	}
	
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(node->getChildren(),iter) {
		CCNode* child = dynamic_cast<CCNode*>(iter);
		if( child) {
			setAllOpacity(map, child,time,endOpacity,isReverse);
		}
	}
}

void FadeOnAllChilds::update(float time)
{
	setAllOpacity(m_fromOpacity, m_pTarget, time, m_toOpacity,isReverse);
}
