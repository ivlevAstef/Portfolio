//
//  Liner.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 25.06.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_LINER_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_LINER_H_

#include "AutoElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Liner: public AutoElement {
		public:
			Liner(std::string name);
			
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale);
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale);
		};
	};
};

#endif