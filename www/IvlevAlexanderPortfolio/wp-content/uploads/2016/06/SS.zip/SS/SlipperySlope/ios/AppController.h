//
//  SlipperySlopeAppController.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

@class RootViewController;

@interface AppController : NSObject <UIAccelerometerDelegate, UIAlertViewDelegate, UITextFieldDelegate,UIApplicationDelegate> {
    UIWindow* window;
    RootViewController* viewController;
}

@end

