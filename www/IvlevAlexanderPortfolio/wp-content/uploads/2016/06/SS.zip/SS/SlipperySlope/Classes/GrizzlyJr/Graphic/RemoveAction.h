#ifndef _GRIZZLY_JR_REMOVE_ACTION_H_
#define _GRIZZLY_JR_REMOVE_ACTION_H_

#include "cocos2d.h"

namespace GrizzlyJr
{
	class RemoveAction: public cocos2d::CCActionInterval
	{
	public:
		bool init() {
			return CCActionInterval::initWithDuration(0.0f);
		}

		virtual void startWithTarget(cocos2d::CCNode *pTarget) {
			pTarget->getParent()->removeChild(pTarget,true);
		}
		
		
		static RemoveAction* create() {
			RemoveAction *pAction = new RemoveAction();
			pAction->init();
			pAction->autorelease();
			return pAction;
		}
		
		void update(float) {}
	};
};
#endif
