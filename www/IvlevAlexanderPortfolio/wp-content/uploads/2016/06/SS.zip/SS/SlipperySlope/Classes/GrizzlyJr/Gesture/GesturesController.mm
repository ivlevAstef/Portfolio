//
//  GesturesController.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 24.05.13.
//
//

#include "GesturesController.h"
#import <Foundation/Foundation.h>

using namespace GrizzlyJr;
USING_NS_CC;

static CCPoint convertPos(const float& x,const float& y) {
	return CCDirector::sharedDirector()->convertToGL(ccp(x,y));
}
static CCPoint convertPos(const CGPoint& point) {
	return CCDirector::sharedDirector()->convertToGL(ccp(point.x,point.y));
}

/////////////////////////OBJC_CONTROLLER

typedef void (GestureController::*GBeginEndAction)(CCPoint pos,GestureListener::GestureType type);
typedef void (GestureController::*GScaleAction)(float scale);
typedef void (GestureController::*GMoveAction)(CCPoint pos,cocos2d::CCPoint speed);
typedef void (GestureController::*GRotateAction)(float angle);

@interface GestureObjCController: NSObject<UIGestureRecognizerDelegate> {
	GestureController* parent;
	GBeginEndAction s_beginAction;
	GBeginEndAction s_endAction;
	GScaleAction s_scaleAction;
	GMoveAction s_moveAction;
	GRotateAction s_rotateAction;
	
	UIView* view;
}

+(GestureObjCController*)create:(GestureController*)parent;
-(GestureObjCController*)init:(GestureController*)parent;

-(void)setBeginer:(GBeginEndAction)action;
-(void)setEnder:(GBeginEndAction)action;
-(void)setScale:(GScaleAction)action;
-(void)setMove:(GMoveAction)action;
-(void)setRotate:(GRotateAction)action;

-(void)scale:(id)sender;
-(void)rotate:(id)sender;
-(void)move:(id)sender;
-(void)Tap:(id)sender;
-(void)doubleTap:(id)sender;

-(void)pause;
-(void)resume;

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer;

@end

@implementation GestureObjCController

+(GestureObjCController*)create:(GestureController*)parent {
	return [[[GestureObjCController alloc] init:parent] autorelease];
}
-(GestureObjCController*)init:(GestureController*)parent_ {
	parent = parent_;
	view = [[[[UIApplication sharedApplication] keyWindow] subviews] lastObject];
	
	UIPinchGestureRecognizer* gScale = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(scale:)];
	[gScale setDelegate:self];
	[view addGestureRecognizer:gScale];
	
	UIRotationGestureRecognizer* gRotate = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotate:)];
	gRotate.cancelsTouchesInView = false;
	gRotate.delaysTouchesEnded = false;
	[gRotate setDelegate:self];
	[view addGestureRecognizer:gRotate];
	
	UIPanGestureRecognizer *gMove = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(move:)];
	gMove.cancelsTouchesInView = false;
	gMove.delaysTouchesEnded = false;
	[gMove setMinimumNumberOfTouches:1];
	[gMove setMaximumNumberOfTouches:1];
	[gMove setDelegate:self];
	[view addGestureRecognizer:gMove];
	
	UITapGestureRecognizer *gTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Tap:)];
	gTap.cancelsTouchesInView = false;
	gTap.delaysTouchesEnded = false;
	[gTap setNumberOfTapsRequired:1];
	[gTap setDelegate:self];
	[view addGestureRecognizer:gTap];
	
	UITapGestureRecognizer *gDoubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap:)];
	gDoubleTap.cancelsTouchesInView = false;
	gDoubleTap.delaysTouchesEnded = false;
	[gDoubleTap setNumberOfTapsRequired:2];
	[gDoubleTap setDelegate:self];
	[view addGestureRecognizer:gDoubleTap];
	
	[gTap requireGestureRecognizerToFail:gDoubleTap];	
	
	return self;
}

-(void)pause {
	for( UIGestureRecognizer* iter in [view gestureRecognizers]) {
		iter.enabled = false;
	}
}
-(void)resume {
	for( UIGestureRecognizer* iter in [view gestureRecognizers]) {
		iter.enabled = true;
	}
}

-(void)setBeginer:(GBeginEndAction)action {
	s_beginAction = action;
}
-(void)setScale:(GScaleAction)action {
	s_scaleAction = action;
}
-(void)setMove:(GMoveAction)action {
	s_moveAction = action;
}
-(void)setRotate:(GRotateAction)action {
	s_rotateAction = action;
}
-(void)setEnder:(GBeginEndAction)action {
	s_endAction = action;
}

-(void)scale:(id)sender {
	CGPoint pos = [(UIPinchGestureRecognizer*)sender locationInView:view];
	CCPoint test_pos = convertPos(pos);
	
    if([(UIPinchGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
		(parent->*s_beginAction)(test_pos, GestureListener::SCALE);
    }
	
	float scale = [(UIPinchGestureRecognizer*)sender scale];
	(parent->*s_scaleAction)(scale);
	
	if([(UIPinchGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
		(parent->*s_endAction)(test_pos, GestureListener::SCALE);
	}
}

-(void)rotate:(id)sender {
	CGPoint pos = [(UIRotationGestureRecognizer*)sender locationInView:view];
	CCPoint test_pos = convertPos(pos);
	
    if([(UIRotationGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
		(parent->*s_beginAction)(test_pos, GestureListener::ROTATION);
    }
    
    CGFloat rotation = CC_RADIANS_TO_DEGREES([(UIRotationGestureRecognizer*)sender rotation]);
	(parent->*s_rotateAction)(rotation);
		
	if([(UIRotationGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
		(parent->*s_endAction)(test_pos, GestureListener::ROTATION);
	}
}

-(void)move:(id)sender {
	CGPoint pos = [(UIPanGestureRecognizer*)sender locationInView:view];
	CCPoint test_pos = convertPos(pos);
	
	if([(UIPanGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
		(parent->*s_beginAction)(test_pos, GestureListener::MOVE);
    }
	

	CGPoint speed = [(UIPanGestureRecognizer*)sender velocityInView:view];
	//cocos2d::CCLog("SPEED(%f,%f)",speed.x,speed.y);
	(parent->*s_moveAction)(test_pos,ccp(speed.x/10,-speed.y/10));
	
	if([(UIPanGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
		(parent->*s_endAction)(test_pos, GestureListener::MOVE);
	}
	if([(UIPanGestureRecognizer*)sender state] == UIGestureRecognizerStateCancelled) {
		(parent->*s_endAction)(test_pos, GestureListener::MOVE);
	}
}

-(void)Tap:(id)sender {
	CGPoint pos = [(UITapGestureRecognizer*)sender locationInView:view];
	CCPoint test_pos = convertPos(pos);

	if([(UITapGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
		(parent->*s_beginAction)(test_pos, GestureListener::CLICK);
    }
	if([(UITapGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
		(parent->*s_endAction)(test_pos, GestureListener::CLICK);
    }
}

-(void)doubleTap:(id)sender {
	CGPoint pos = [(UITapGestureRecognizer*)sender locationInView:view];
	CCPoint test_pos = convertPos(pos);

	if([(UITapGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
		(parent->*s_beginAction)(test_pos, GestureListener::DOUBLE_CLICK);
    }
	if([(UITapGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
		(parent->*s_endAction)(test_pos, GestureListener::DOUBLE_CLICK);
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}


@end

/////////////////////////LISTENER
GestureListener::GestureListener() {
	GestureController::get()->addListener(this);
}

GestureListener::~GestureListener() {
	GestureController::get()->removeListener(this);
}

void GestureController::pause() {
	[(GestureObjCController*)get()->data pause];
}
void GestureController::resume() {
	[(GestureObjCController*)get()->data resume];
}

/////////////////////////CONTROLLER
const float GestureController::UNDEFINED_ANGLE = -12345.0f;

GestureController* GestureController::singleton = 0x0;
GestureController* GestureController::get() {
	if( 0x0 == singleton) {
		singleton = new GestureController();
	}
	return singleton;
}

GestureController::GestureController() {
	data = [[GestureObjCController create:this] retain];
	[(GestureObjCController*)data setBeginer:&GestureController::beginAction];
	[(GestureObjCController*)data setScale:&GestureController::scale];
	[(GestureObjCController*)data setMove:&GestureController::move];
	[(GestureObjCController*)data setRotate:&GestureController::rotate];
	[(GestureObjCController*)data setEnder:&GestureController::endAction];
}

GestureController::~GestureController() {
	if( singleton == this) {
		singleton = 0x0;
	}
	[(GestureObjCController*)data release];
}

void GestureController::addListener(GestureListener* listener, cocos2d::CCRect zone) {
	if( 0x0 == listener) {
		return;
	}
	for( size_t i =0; i < listeners.size(); i++) {
		if( listeners[i].listener == listener ) {
			return;
		}
	}
	
	ListenerInfo info = { listener, 1};
	info.scale_mult = 1;
	info.begin_angle = 0;
	info.last_angle = 0;
	info.begin_pos = ccp(0,0);
	info.last_pos = ccp(0,0);
	info.zone = zone;
	listeners.push_back(info);
}

void GestureController::addListener(GestureListener* listener) {
	CCRect zone = CCRect(0,0,0,0);
	zone.size = CCDirector::sharedDirector()->getWinSize();
	addListener(listener,zone);
}
void GestureController::removeListener(GestureListener* listener) {
	for( size_t i =0; i < listeners.size(); i++) {
		if( listeners[i].listener == listener ) {
			listeners.erase(listeners.begin()+i);
			return;
		}
	}
}
void GestureController::setZoneFor(GestureListener* listener, cocos2d::CCRect zone) {
	for( size_t i =0; i < listeners.size(); i++) {
		if( listeners[i].listener == listener ) {
			listeners[i].zone = zone;
		}
	}
}


void GestureController::beginAction(CCPoint pos,GestureListener::GestureType type) {
	for( size_t i =0; i < listeners.size(); i++) {
		ListenerInfo& inf = listeners[i];
		if( GestureListener::CLICK == type || GestureListener::DOUBLE_CLICK == type) {
			if( !CCRect::CCRectContainsPoint(inf.zone, pos)) {
				continue;
			}
		}
		
		inf.listener->beginAction(pos, type);
		switch (type) {
			case GestureListener::SCALE: inf.scale_mult = inf.listener->getScaleMult(); break;
			case GestureListener::MOVE: inf.begin_pos = pos; inf.last_pos = pos; break;
			case GestureListener::ROTATION: inf.begin_angle = UNDEFINED_ANGLE; inf.last_angle = UNDEFINED_ANGLE;
			default: break;
		}
	}
}
void GestureController::scale(float scale) {
	for( size_t i =0; i < listeners.size(); i++) {
		ListenerInfo& inf = listeners[i];
		inf.listener->scale(scale*inf.scale_mult);
	}
}
void GestureController::move(CCPoint pos,cocos2d::CCPoint speed) {
	for( size_t i =0; i < listeners.size(); i++) {
		ListenerInfo& inf = listeners[i];
		
		CCPoint delta = ccpSub(pos,inf.last_pos);
		CCPoint move = ccpSub(pos,inf.begin_pos);
	
		if( CCRect::CCRectContainsPoint(inf.zone, pos) ) {
			inf.listener->move(pos, delta,move,speed);
			inf.last_pos = pos;
		}
	}
}
void GestureController::rotate(float angle) {
	for( size_t i =0; i < listeners.size(); i++) {
		ListenerInfo& inf = listeners[i];
		
		if( UNDEFINED_ANGLE == inf.begin_angle) { inf.begin_angle = angle; }
		if( UNDEFINED_ANGLE == inf.last_angle) { inf.last_angle = angle; }
				
		inf.listener->rotate(angle-inf.begin_angle,angle - inf.last_angle);
		inf.last_angle = angle;
	}
}

void GestureController::endAction(CCPoint pos,GestureListener::GestureType type) {
	for( size_t i =0; i < listeners.size(); i++) {
		ListenerInfo& inf = listeners[i];
		
		if( GestureListener::CLICK == type || GestureListener::DOUBLE_CLICK == type) {
			if( !CCRect::CCRectContainsPoint(inf.zone, pos)) {
				continue;
			}
		}
		
		inf.listener->endAction(pos, type);
	}
}

