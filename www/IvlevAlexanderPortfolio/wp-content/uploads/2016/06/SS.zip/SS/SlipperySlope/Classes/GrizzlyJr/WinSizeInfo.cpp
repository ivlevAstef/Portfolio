#include "WinSizeInfo.h"

using namespace GrizzlyJr;
using namespace cocos2d;

std::map<std::string,cocos2d::CCSize> createWinSizeNames() {
	std::map<std::string,cocos2d::CCSize> result;
	result["d2048x1536"] = CCSizeMake(2048,1536);
	result["d1024x768"] = CCSizeMake(1024,768);
	result["d1136x640"] = CCSizeMake(1136,640);
	result["d960x640"] = CCSizeMake(960,640);
	result["d480x320"] = CCSizeMake(480,320);
	
	result["d800x480"] = CCSizeMake(800,480);
	result["d854x480"] = CCSizeMake(854,480);
	result["d1024x600"] = CCSizeMake(1024,600);
	result["d1280x800"] = CCSizeMake(1280,800);
	return result;
}
std::vector<cocos2d::CCSize> createWinSizes() {
	std::vector<cocos2d::CCSize> result;

	std::map<std::string,cocos2d::CCSize> data = createWinSizeNames();
	std::map<std::string,cocos2d::CCSize>::iterator iter = data.begin();
	for( ; iter != data.end(); iter++) {
		result.push_back(iter->second);
	}
	return result;
}
std::vector<std::string> createNamesWinSize() {
	std::vector<std::string> result;

	std::map<std::string,cocos2d::CCSize> data = createWinSizeNames();
	std::map<std::string,cocos2d::CCSize>::iterator iter = data.begin();
	for( ; iter != data.end(); iter++) {
		result.push_back(iter->first);
	}
	return result;
}
std::map<std::string,std::string> createFilePostfixByDevice() {
	std::map<std::string,std::string> result;
	result["d2048x1536"] = "ipad-hd";
	result["d1024x768"] = "ipad";
	result["d1136x640"] = "hd";
	result["d960x640"] = "hd";
	result["d480x320"] = "normal";
	
	result["d800x480"] = "android1";
	result["d854x480"] = "android1";
	result["d1024x600"] = "android2";
	result["d1280x800"] = "android3";
	return result;
}

std::map<std::string,cocos2d::CCSize> createPostfixWinSize() {
	std::map<std::string,cocos2d::CCSize> result;
	std::map<std::string,std::string> postfixs = createFilePostfixByDevice();
	std::map<std::string,cocos2d::CCSize> win_size = createWinSizeNames();
	
	std::map<std::string,std::string>::iterator iter;
	for( iter = postfixs.begin(); iter != postfixs.end(); iter++) {
		result[iter->second] = win_size[iter->first];
	}
	return result;
}


std::map<std::string,cocos2d::CCSize> WinSizeInfo::win_size_names = createWinSizeNames();
std::vector<cocos2d::CCSize> WinSizeInfo::win_sizes = createWinSizes();
std::vector<std::string> WinSizeInfo::win_size_names_array = createNamesWinSize();

std::map<std::string,std::string> WinSizeInfo::file_postfix_by_device = createFilePostfixByDevice();

std::map<std::string,cocos2d::CCSize> WinSizeInfo::postfix_win_size = createPostfixWinSize();
