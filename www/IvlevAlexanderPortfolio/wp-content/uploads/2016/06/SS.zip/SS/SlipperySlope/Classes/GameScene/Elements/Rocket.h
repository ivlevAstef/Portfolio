//
//  Rocket.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 25.06.13.
//
//


#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_ROCKET_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_ROCKET_H_

#include "AutoElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Rocket: public AutoElement {
		public:
			Rocket(std::string name);
			
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale);
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale);
		};
	};
};

#endif