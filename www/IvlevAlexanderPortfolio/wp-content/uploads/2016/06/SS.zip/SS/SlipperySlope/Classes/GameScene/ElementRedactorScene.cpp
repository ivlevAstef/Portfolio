//
//  ElementRedactorScene.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 29.07.13.
//
//

#include "ElementRedactorScene.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Gesture/GesturesController.h>
#include <GrizzlyJr/Graphic/Button.h>
#include <GrizzlyJr/SceneController/SceneController.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>
#include <GrizzlyJr/FIOM/FIOMNode.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
using namespace cocos2d;

#define ELEMENT_TAG 123

void AutoElementRedactor::load() {
	FIOMNode node= FIOMNode::get("Elements")[name]["physic"]["fixtures"];
	size_t count = node.getArraySize();
	
	visible_fixture.clear();
	for( size_t i =0; i < count; i++) {
		AutoElementVisibleFixtureInfo fixture;
		FIOMNode f = node[(unsigned int)i];
		
		if( "circle" == f.getStr("type")) {
			fixture.is_circle = true;
			CCPoint pos = f.getPoint("data");
			fixture.center = Box2DCocos::convert(b2Vec2(pos.x,pos.y));
			fixture.center.retain();
			fixture.radius = Box2DCocos::convertLengthToCocos2D(f["data"].getFloat("radius"));
		} else {
			fixture.is_circle = false;
			
			FIOMNode points = f["points"];
			size_t p_count = points.getArraySize();
			for( size_t j =0; j < p_count; j += 2) {
				float x = points.getFloat((unsigned int)j);
				float y = points.getFloat((unsigned int)j+1);
				fixture.points.push_back(Box2DCocos::convert(b2Vec2(x,y)));
				fixture.points[fixture.points.size()-1].retain();
			}
		}
		
		fixture.density = f.getFloat("density");
		fixture.friction = f.getFloat("friction");
		fixture.restitution = f.getFloat("restitution");
		
		visible_fixture.push_back(fixture);
	}
}

void AutoElementRedactor::save() {
	FIOMNode node= FIOMNode::get("Elements");
	node = node.addNextDepth(name, false, false);
	node = node.addNextDepth("physic", false, false);
	node = node.addNextDepth("fixtures", true, false);
	node.clear();
	
	for( size_t i =0; i < visible_fixture.size(); i++) {
		FIOMNode f =node.addNextDepth(i, false, false);
		f.set("density", visible_fixture[i].density);
		f.set("friction", visible_fixture[i].friction);
		f.set("restitution", visible_fixture[i].restitution);
		if( visible_fixture[i].is_circle) {
			f.set("type","circle");
			FIOMNode d = f.addNextDepth("data", false, false);
			d.set("radius", Box2DCocos::convertLengthToBox2d(visible_fixture[i].radius));
			d.set("x", Box2DCocos::convertLengthToBox2d(visible_fixture[i].center.x));
			d.set("y", Box2DCocos::convertLengthToBox2d(visible_fixture[i].center.y));
		} else {
			f.set("type","poly");
			
			FIOMNode d = f.addNextDepth("points", true, false);
			std::vector<cocos2d::CCPoint>& points = visible_fixture[i].points;
			for( size_t j =0; j < points.size(); j++) {
				d.set((unsigned int)j*2+0, Box2DCocos::convertLengthToBox2d(points[j].x));
				d.set((unsigned int)j*2+1, Box2DCocos::convertLengthToBox2d(points[j].y));
			}
			
		}
		
	}
	
	FIOMMain::get()->saveFile("Elements");
	
}



class ElementMenuElement: public Button {
private:
	std::string name;
	cocos2d::CCNode* parent;
	cocos2d::CCPoint pos;
public:
	static ElementMenuElement* create(std::string name,cocos2d::CCNode* parent,cocos2d::CCPoint pos) {
		ElementMenuElement* node = new ElementMenuElement();
		if( node && node->init(name,parent,pos) ) {
			node->autorelease();
			return node;
		}
		CC_SAFE_DELETE(node);
		return 0x0;
	}
	
	bool init(std::string name,cocos2d::CCNode* parent,cocos2d::CCPoint pos) {
		this->parent = parent;
		this->name = name;
		this->pos = pos;
		if( Button::init("redactor-icon-back",this,menu_selector(ElementMenuElement::click)) ) {
			std::string image = "redactor-icon-"+name+".png";
			addImage(image.c_str(),image.c_str());
			return true;
		}
		return false;
	}
	
	std::string getName()const { return name; }
	
	void click(cocos2d::CCObject* obj) {
		cocos2d::CCNode* tag_child = parent->getChildByTag(ELEMENT_TAG);
		if( 0x0 != tag_child) {
			parent->removeChild(tag_child, true);
		}
		AutoElementRedactor* new_element = AutoElementRedactor::create(name);
		new_element->setPosition(pos);
		new_element->setScale(2.0f);
		parent->addChild(new_element,0,ELEMENT_TAG);
	}
};


CCScene* ElementRedactorScene::scene(void* point) {
	CCScene *scene = CCScene::create();
	ElementRedactorScene* layer = new ElementRedactorScene();
	if( scene && layer && layer->init()) {
		layer->autorelease();
		scene->addChild(layer);
		return scene;
	}
	CC_SAFE_DELETE(scene);
	CC_SAFE_DELETE(layer);
	return 0x0;
}

#define ADD_ELEMENT(NAME) ((CCNode*)loop_menu)->addChild(ElementMenuElement::create(NAME,this,pos));

bool ElementRedactorScene::init() {
	if( !CCLayer::init()) {
		return false;
	}
	
	CCSize size = CCDirector::sharedDirector()->getWinSize();
	ScaleCCSprite* back = ScaleCCSprite::createFN("back.png");
	back->setPosition(ccp(size.width/2,size.height/2));
	this->addChild(back,-1);
	
	menu_back = ScaleCCSprite::createFN("back-bottom.png");
	CCSize m_size = menu_back->getContentSize();
	menu_back->setPosition(ccp(size.width/2,m_size.height/2));
	this->addChild(menu_back);
	
	loop_menu = ZoneLoopingMenu::createOnRect(CCRect(0,0,m_size.width,m_size.height));
	loop_menu->setOrientation(OLM_HORIZONTAL);
	
	CCSize w_size = CCDirector::sharedDirector()->getWinSize();
	float h = menu_back->getContentSize().height;
	CCPoint pos = ccp(w_size.width/2,(w_size.height+h)/2);
	
	ADD_ELEMENT("beam-01");
	ADD_ELEMENT("beam-02");
	ADD_ELEMENT("beam-03");
	ADD_ELEMENT("beam-04");
	ADD_ELEMENT("beam-05");
	ADD_ELEMENT("beam-06");
	ADD_ELEMENT("beam-07");
	ADD_ELEMENT("beam-08");
	ADD_ELEMENT("beam-09");
	ADD_ELEMENT("wheel-01");
	ADD_ELEMENT("wheel-02");
	ADD_ELEMENT("wheel-03");
	ADD_ELEMENT("wheel-04");
	ADD_ELEMENT("wheel-05");
	ADD_ELEMENT("wheel-06");
	ADD_ELEMENT("engine-01");
	ADD_ELEMENT("engine-02");
	ADD_ELEMENT("engine-03");
	ADD_ELEMENT("rocket-01");
	ADD_ELEMENT("bumper-01");
	ADD_ELEMENT("wing-01");
	ADD_ELEMENT("driver");
	ADD_ELEMENT("box");
	
	menu_back->addChild(loop_menu);
	
	return true;
}

ElementRedactorScene::~ElementRedactorScene() {
}

bool ElementRedactorScene::beginAction(CCPoint w_pos,GestureType type) {
	
	return true;
}

float ElementRedactorScene::getScaleMult() {
	AutoElementRedactor* element = dynamic_cast<AutoElementRedactor*>(getChildByTag(ELEMENT_TAG));
	if( 0x0 == element) {
		return 1;
	}
	return element->getScale();
}
void ElementRedactorScene::scale(float scale) {
	AutoElementRedactor* element = dynamic_cast<AutoElementRedactor*>(getChildByTag(ELEMENT_TAG));
	if( 0x0 == element) {
		return;
	}
	element->setScale(scale);
}

#define EPSILON 20

void ElementRedactorScene::move(CCPoint w_pos,CCPoint delta,CCPoint move,cocos2d::CCPoint speed) {
	AutoElementRedactor* element = dynamic_cast<AutoElementRedactor*>(getChildByTag(ELEMENT_TAG));
	if( 0x0 == element) {
		return;
	}
	float eps = EPSILON;
	
	CCPoint last_pos = ccpSub(w_pos, delta);
	CCPoint tr = ccpMult(delta, 1.0f/element->getScale());
	
	if( ccpLength(delta) > 100) {
		return;
	}
	
	
	std::vector<AutoElementVisibleFixtureInfo>& v_fix = element->getFix();
	for( size_t i =0; i < v_fix.size(); i++) {
		if( v_fix[i].is_circle) {
			CCPoint pos = v_fix[i].center;
			pos = ccpMult(pos, element->getScale());
			pos = ccpAdd(element->getPosition(), pos);
			
			float d = ccpDistance(last_pos, pos);
			if( d < eps) {
				v_fix[i].center = ccpAdd(v_fix[i].center,tr);
				return;
			}
			
			float radius = v_fix[i].radius*0.5f*element->getScale();
			if( d-eps*0.5f < radius && radius < d+eps*0.5f) {
				if( ccpDistance(w_pos, pos) > ccpDistance(last_pos, pos)) {
					v_fix[i].radius += ccpLength(delta);
				} else {
					v_fix[i].radius -= ccpLength(delta);
				}
				if( v_fix[i].radius < eps*1.5f) {
					v_fix[i].radius = eps*1.5f;
				}
				
				return;
			}
			
		}else {
			size_t count = v_fix[i].points.size();
			for( size_t j =0; j < count; j++) {
				CCPoint pos = v_fix[i].points[j];
				pos = ccpMult(pos, element->getScale());
				pos = ccpAdd(element->getPosition(), pos);
				
				float d = ccpDistance(last_pos, pos);
				if( d < eps) {
					v_fix[i].points[j] = ccpAdd(v_fix[i].points[j],tr);
					return;
				}
			}
		}
		
	}
	
	
}
void ElementRedactorScene::endAction(CCPoint w_pos,GestureType type) {
	AutoElementRedactor* element = dynamic_cast<AutoElementRedactor*>(getChildByTag(ELEMENT_TAG));
	if( 0x0 == element) {
		return;
	}
	
	if( DOUBLE_CLICK == type ) {
		float eps = EPSILON;
		
		std::vector<AutoElementVisibleFixtureInfo>& v_fix = element->getFix();
		for( size_t i =0; i < v_fix.size(); i++) {
			CCPoint pos = ccpSub(w_pos,element->getPosition());
			pos = ccpMult(pos, 1.0f/element->getScale());
			if( !v_fix[i].is_circle) {
				size_t count = v_fix[i].points.size();
				for( size_t j =0; j < count; j++) {
					if( ccpDistance(v_fix[i].points[j], pos) < 20/element->getScale()) {
						v_fix[i].points.erase(v_fix[i].points.begin()+j);
						if( v_fix[i].points.size() <= 2) {
							v_fix.erase(v_fix.begin()+i);
						}
						
						return;
					}
				}
			} else {
				if( ccpDistance(v_fix[i].center, pos) < 20/element->getScale()) {
					v_fix.erase(v_fix.begin()+i);
					return;
				}
			}
		}
		
		for( size_t i =0; i < v_fix.size(); i++) {
			if( !v_fix[i].is_circle) {
				CCPoint pos = ccpSub(w_pos,element->getPosition());
				pos = ccpMult(pos, 1.0f/element->getScale());
				size_t count = v_fix[i].points.size();
				for( size_t j =0; j < count; j++) {
					CCPoint p0 = v_fix[i].points[j];
					CCPoint p1 = v_fix[i].points[(j+1)%count];
					CCPoint v = ccpNormalize(ccpSub(p1, p0));
					CCPoint w = ccpSub(pos, p0);
					float length = ccpCross(v, w);
					if( fabs(length) < eps*0.5f/element->getScale()) {
						CCPoint dir = ccp(v.y,-v.x);
						CCPoint new_point = ccpAdd(pos, ccpMult(dir, length));
						
						float min_x = MIN(p0.x,p1.x);
						float min_y = MIN(p0.y,p1.y);
						float max_x = MAX(p0.x,p1.x);
						float max_y = MAX(p0.y,p1.y);
						if( new_point.x > min_x && new_point.x < max_x &&
						    new_point.y > min_y && new_point.y < max_y) {
							v_fix[i].points.insert(v_fix[i].points.begin()+j+1, new_point);
							return;
						}
					}
				}
			}
		}
		///TODO: if point on line -> add new point
		
		AutoElementVisibleFixtureInfo new_fix;
		new_fix.density = 0.2f;
		new_fix.friction = 0.5f;
		new_fix.restitution = 0.5f;
		new_fix.is_circle = false;
		new_fix.points.push_back(ccp(-50,-20));
		new_fix.points.push_back(ccp(50,-20));
		new_fix.points.push_back(ccp(0,23));
		
		v_fix.push_back(new_fix);
		
		///TODO: else add new triangle
	}
	element->save();
}

void ElementRedactorScene::draw() {
	CCLayer::draw();
}

void ElementRedactorScene::visit() {
	CCLayer::visit();
	
	AutoElementRedactor* element = dynamic_cast<AutoElementRedactor*>(getChildByTag(ELEMENT_TAG));
	if( 0x0 == element) {
		return;
	}
	
	ccDrawColor4B(255, 0, 0, 255);
	ccPointSize(10);
	glLineWidth(3);
	
	const std::vector<AutoElementVisibleFixtureInfo>& v_fix = element->getFix();
	for( size_t i =0; i < v_fix.size(); i++) {
		if( v_fix[i].is_circle) {
			CCPoint pos = v_fix[i].center;
			pos = ccpMult(pos, element->getScale());
			pos = ccpAdd(element->getPosition(), pos);
			ccDrawCircle(pos, v_fix[i].radius*element->getScale()*0.5f,0,25,true);
			ccDrawPoint(pos);
		}else {
			size_t count = v_fix[i].points.size();
			for( size_t j =0; j < count; j++) {
				CCPoint pos1 = v_fix[i].points[j];
				CCPoint pos2 = v_fix[i].points[(j+1)%count];
				pos1 = ccpMult(pos1, element->getScale());
				pos2 = ccpMult(pos2, element->getScale());
				pos1 = ccpAdd(element->getPosition(), pos1);
				pos2 = ccpAdd(element->getPosition(), pos2);
				ccDrawLine(pos1, pos2);
				ccDrawPoint(pos1);
			}
		}
		
	}
}

SceneInformation ElementRedactorScene::getSceneInformation()
{
	SceneInformation info;
	info.createScene = &scene;
	info.p = 0x0;
	
	info.resources.push_back(LoadingData("game-scene/elements/beams"));
	info.resources.push_back(LoadingData("game-scene/elements/drivers"));
	info.resources.push_back(LoadingData("game-scene/elements/engines"));
	info.resources.push_back(LoadingData("game-scene/elements/wheels"));
	info.resources.push_back(LoadingData("game-scene/elements/liner"));
	info.resources.push_back(LoadingData("game-scene/elements/rocket"));
	info.resources.push_back(LoadingData("game-scene/physic"));
	info.resources.push_back(LoadingData("redactor-scene/mount"));
	info.resources.push_back(LoadingData("redactor-scene/menu"));
	info.resources.push_back(LoadingData("redactor-scene/backs"));
	
	return info;
}