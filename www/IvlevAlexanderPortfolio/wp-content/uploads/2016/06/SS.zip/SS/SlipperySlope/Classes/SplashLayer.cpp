//
//  SplashLayer.cpp
//  SlipperSlope
//
//  Created by Alexander Ivlev on 18.12.12.
//
//

#include "SplashLayer.h"
#include <GrizzlyJr/SceneController/SceneController.h>
#include "GameScene/RedactorScene.h"
#include "GameScene/ElementRedactorScene.h"
#include <Config/Config.h>
#include "GameScene/Elements/AutoElement.h"

//#define CREATE_AUTO_ELEMENT_MENU

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

void SplashLayer::create() {
	GrizzlyJr::Config::c->init();
	AutoElement::initGridCellSize();
	
	loadNextScene();
}


void SplashLayer::loadNextScene() {
#ifdef CREATE_AUTO_ELEMENT_MENU
	SceneController::get()->replace(ElementRedactorScene::getSceneInformation());
#else
	SceneController::get()->replace(RedactorScene::getSceneInformation());
#endif
}
