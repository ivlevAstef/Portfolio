#include "InercianalLayer.h"
#include "../FIOM/FIOMNode.h"
#include "../Location.h"

#define TIME_FOR_DONT_MOVE 0.1f
#define TOUCH_NUMBER 0

using namespace GrizzlyJr;
using namespace cocos2d;

InercianalLayer* InercianalLayer::create(std::string name) {
	InercianalLayer* layer = new InercianalLayer(name);
	if( layer) {
		layer->autorelease();
		return layer;
	}
	CC_SAFE_DELETE(layer);
	return 0x0;
}

InercianalLayer::InercianalLayer() {
	init("InercianalLayer");
}

InercianalLayer::InercianalLayer(std::string name) {
	init(name);
}

void InercianalLayer::init(std::string name)
{
	this->schedule(schedule_selector(InercianalLayer::tick));
	
	
	Location node = Location::get("DevicesInfo")[name];
	speed = node.getLFloat("speed",Location::CHANGE_NORMAL);
	acceselerometr = node.getLFloat("acceselerometr",Location::CHANGE_NORMAL);
	minDirLength = node.getLFloat("min_direction_length",Location::CHANGE_NORMAL);
	
	touches.clear();
	time = 0;
	isInercial = false;
	timeLastMove = 0;
	isPauseScroll = false;
	isPauseTouch = false;
	CCDirector::sharedDirector()->getTouchDispatcher()->addStandardDelegate(this, 0); 
}

void InercianalLayer::end() {
	CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this); 
}

void InercianalLayer::pauseTouch() {
	if( !isPauseTouch) {
		isPauseTouch = true;
	}
}
void InercianalLayer::resumeTouch() {
	if( isPauseTouch) {
		isPauseTouch = false;
	}
}

void InercianalLayer::pauseScroll() {
	isPauseScroll = true;
}
void InercianalLayer::resumeScroll() {
	isPauseScroll = false;
}

void InercianalLayer::pauseScrollAndTouch() {
	pauseTouch(); pauseScroll();
}
void InercianalLayer::resumeScrollAndTouch() {
	resumeTouch(); resumeScroll();
}

void InercianalLayer::addListener(IListener* listener)
{
	for( unsigned int i = 0; i < listeners.size(); i++) {
		if( listeners[i] == listener) {
			return;
		}
	}
	listeners.push_back(listener);
}
void InercianalLayer::removeListener(IListener* listener)
{
	for( unsigned int i = 0; i < listeners.size(); i++) {
		if( listeners[i] == listener) {
			listeners.erase(listeners.begin()+i);
			break;
		}
	}

}

void InercianalLayer::setPositionWithThisSize(float x, float y)
{
	CCSize winSize = CCDirector::sharedDirector()->getWinSize();
	x *= -1;
	if( x < 0) { x = 0; }
	if( y < 0) { y = 0; }
	
	if( x+winSize.width > this->getContentSize().width) { 
		x = this->getContentSize().width - winSize.width;
	}
	if( y+winSize.height > this->getContentSize().height) { 
		y = this->getContentSize().height - winSize.height;
	}
	
	x *= -1;
	this->setPosition(CCPoint(x,y));
}

void InercianalLayer::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	isInercial = false;
	CCSetIterator iter = pTouches->begin();
	for( int i = 0; i < pTouches->count(); i++) {
		CCTouch* pTouch = (CCTouch*)(*iter);
		CCPoint point = pTouch->locationInView();
		point = CCDirector::sharedDirector()->convertToGL(point);
		
		touchInformation touchInfo;
		touchInfo.touchBegin = point;
		touchInfo.touchLast = point;
		touchInfo.touchLastForNumber = pTouch->locationInView();
		
		if( 0 == touches.size() && !isPauseTouch) {
			thisBegin = this->getPosition();
			time = 0;
			dir = CCPoint(0,0);
		}
		
		EventChangeParameter parameter;
		parameter.pointOnView = pTouch->locationInView();
		parameter.pointOnView = this->convertToNodeSpace(parameter.pointOnView);
		parameter.pointOnView.y = CCDirector::sharedDirector()->getWinSize().height - parameter.pointOnView.y;
		parameter.beginPointOnView = pTouch->locationInView();
		parameter.beginPointOnView = this->convertToNodeSpace(parameter.beginPointOnView);
		parameter.beginPointOnView.y = CCDirector::sharedDirector()->getWinSize().height - parameter.beginPointOnView.y;
		
		parameter.lastE = BEGIN_TOUCH;
		parameter.newE = BEGIN_TOUCH;
		
		touchInfo.parameter = parameter;
		int number = touches.size();
		
		touches[number] = touchInfo;
		listenerAll(number);
		
		iter++;
	}
}

int InercianalLayer::getNumberTouch(CCTouch* touch)
{
	std::map<int,touchInformation>::iterator iter = touches.begin();
	for(; iter != touches.end(); iter++) {
		CCPoint prev = touch->previousLocationInView();
		CCPoint last = iter->second.touchLastForNumber;
		if( fabs(last.x-prev.x) < 5 && fabs(last.y-prev.y) < 5) {
			return iter->first;
		}
	}
	return 0;
}

void InercianalLayer::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
	CCSetIterator iter = pTouches->begin();
	for( int i = 0; i < pTouches->count(); i++) {
		CCTouch* pTouch = (CCTouch*)(*iter);
		CCPoint point = pTouch->locationInView();
		point = CCDirector::sharedDirector()->convertToGL(point);
		
		int number = getNumberTouch(pTouch);	
		touches[number].touchLastForNumber = pTouch->locationInView();
		if( BEGIN_TOUCH== touches[number].parameter.lastE && ccpLength(ccpSub(point, touches[number].touchBegin)) < minDirLength) {
			return;
		}
	
		if( TOUCH_NUMBER == number && !isPauseScroll  && !isPauseTouch) {
			CCPoint newPos = ccpAdd(thisBegin,ccpSub(point, touches[number].touchBegin));
			setPositionWithThisSize(newPos.x,newPos.y);
			dir = ccpSub(point, touches[number].touchLast);
			timeLastMove = 0;
		}
		
		touches[number].touchLast = point;
		
		touches[number].parameter.pointOnView = pTouch->locationInView();
		touches[number].parameter.pointOnView = this->convertToNodeSpace(touches[number].parameter.pointOnView);
		touches[number].parameter.pointOnView.y = CCDirector::sharedDirector()->getWinSize().height - touches[number].parameter.pointOnView.y;
		touches[number].parameter.lastE = touches[number].parameter.newE;
		touches[number].parameter.beginPointOnView = touches[number].parameter.beginPointOnView;
		touches[number].parameter.newE = MOVE_TOUCH;
		listenerAll(number);
	
		iter++;
	}
}

void InercianalLayer::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
	CCSetIterator iter = pTouches->begin();
	for( int i = 0; i < pTouches->count(); i++) {
		CCTouch* pTouch = (CCTouch*)(*iter);
		int number = getNumberTouch(pTouch);
		
		CCPoint point = pTouch->locationInView();
		point = CCDirector::sharedDirector()->convertToGL(point);
		
		if( TOUCH_NUMBER == number  && !isPauseTouch) {
			thisBegin = this->getPosition();
			time = 0;
			if( timeLastMove < TIME_FOR_DONT_MOVE && MOVE_TOUCH == touches[number].parameter.newE && touches.size() <= 1) {
				isInercial = true;
			}
		}
		
		touches[number].parameter.pointOnView = pTouch->locationInView();
		touches[number].parameter.pointOnView = this->convertToNodeSpace(touches[number].parameter.pointOnView);
		touches[number].parameter.pointOnView.y = CCDirector::sharedDirector()->getWinSize().height - touches[number].parameter.pointOnView.y;
		touches[number].parameter.lastE = touches[number].parameter.newE;
		touches[number].parameter.beginPointOnView = touches[number].parameter.beginPointOnView;
		touches[number].parameter.newE = END_TOUCH;
		listenerAll(number);
		
		touches.erase(touches.find(number));
		
		iter++;
	}
}

void InercianalLayer::ccTouchCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
	CCSetIterator iter = pTouches->begin();
	for( int i = 0; i < pTouches->count(); i++) {
		CCTouch* pTouch = (CCTouch*)(*iter);
		int number = getNumberTouch(pTouch);
		
		CCPoint point = pTouch->locationInView();
		point = CCDirector::sharedDirector()->convertToGL(point);
		
		if( TOUCH_NUMBER == number && !isPauseScroll) {
			thisBegin = this->getPosition();
			time = 0;
			if( timeLastMove < TIME_FOR_DONT_MOVE && MOVE_TOUCH == touches[number].parameter.newE && touches.size() <= 1) {
				isInercial = true;
			}
		}
		
		touches[number].parameter.pointOnView = pTouch->locationInView();
		touches[number].parameter.pointOnView = this->convertToNodeSpace(touches[number].parameter.pointOnView);
		touches[number].parameter.pointOnView.y = CCDirector::sharedDirector()->getWinSize().height - touches[number].parameter.pointOnView.y;
		touches[number].parameter.lastE = touches[number].parameter.newE;
		touches[number].parameter.newE = END_TOUCH;
		listenerAll(number);
		
		touches.erase(touches.find(number));
		
		iter++;
	}
}

void InercianalLayer::tick(float dt)
{		
	if( touches.size() > 0 || !isInercial) {
		timeLastMove+=dt;
		return;
	}
	
	float lt = (speed*time + acceselerometr*time*time);
	time += dt;
	float t = (speed*time + acceselerometr*time*time);
	
	if( t < lt) {
		isInercial = false;
		return;
	}
	
	float x = dir.x*t;
	float y = dir.y*t;
	
	setPositionWithThisSize(x+thisBegin.x, y+thisBegin.y);
}

void InercianalLayer::listenerAll(int number) {
	for( unsigned int i =0; i < listeners.size(); i++) {
		listeners[i]->eventStateChange(touches[number].parameter,number);
	}

}