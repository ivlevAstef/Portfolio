//
//  HelpElementInterface.h
//  SlipperSlope
//
//  Created by Alexander Ivlev on 04.10.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_HELP_ELEMENT_INTERFACE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_HELP_ELEMENT_INTERFACE_H_

#include "cocos2d.h"

namespace GrizzlyJr
{
	class HelpElementInterface {
	private:
		std::string thisId;
	public:
		virtual void enableOnHelp() =0;
		virtual void disableOnHelp() =0;
		
		virtual void dontUseNormalAction(){}
		
		virtual void addNodeChild(void* child) {}
		virtual float getWidth() {return 0;}
		virtual float getHeight() {return 0;}
		
		void setOnControllerUseId(std::string thisId);///add,change,remove
		
		~HelpElementInterface();
	protected:
		void clickOnSelf();
	};
};

#endif
