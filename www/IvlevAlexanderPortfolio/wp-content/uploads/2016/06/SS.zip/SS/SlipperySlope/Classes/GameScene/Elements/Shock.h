//
//  Shock.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 15.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SHOCK_H_
#define _GRIZZLY_JR_SLIPPERY_SHOCK_H_

#include "AutoElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Shock: public AutoElement {
		private:
			b2Body* body2;
			std::vector<b2Body*> springs;
		public:
			Shock(std::string name);
			
			virtual b2Body* getBody()const;
			virtual float getMass()const;
			virtual b2Body* getBodyFromPoint(b2Vec2 pos)const;
			
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale);
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale);
			
			virtual void updateImage();
		};
	};
};

#endif