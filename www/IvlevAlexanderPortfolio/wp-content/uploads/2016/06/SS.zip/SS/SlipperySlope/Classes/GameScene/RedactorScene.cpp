#include "RedactorScene.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Gesture/GesturesController.h>
#include <GrizzlyJr/Graphic/Button.h>
#include <GrizzlyJr/SceneController/SceneController.h>
#include <GrizzlyJr/Location.h>
#include "GameScene.h"


using namespace GrizzlyJr;
using namespace SlipperSlope;
using namespace cocos2d;

class MenuElement: public Button {
public:
	static cocos2d::CCPoint default_pos;
private:
	std::string type;
	std::string name;
	Auto* parent_auto;
public:
	static MenuElement* create(std::string type,std::string name,Auto* parent_auto) {
		MenuElement* node = new MenuElement();
		if( node && node->init(type,name,parent_auto) ) {
			node->autorelease();
			return node;
		}
		CC_SAFE_DELETE(node);
		return 0x0;
	}
	
	bool init(std::string type,std::string name,Auto* parent_auto) {
		this->parent_auto = parent_auto;
		this->type = type;
		this->name = name;
		if( Button::init("redactor-icon-back",this,menu_selector(MenuElement::click)) ) {
			std::string image = "redactor-icon-"+name+".png";
			addImage(image.c_str(),image.c_str());			
			return true;
		}
		return false;
	}
	
	std::string getType()const { return type; }
	std::string getName()const { return name; }
	
	void click(cocos2d::CCObject* obj) {
		AutoElement* elemenent = parent_auto->addElement(getType(), getName());
		elemenent->setPosition(default_pos);
		cocos2d::CCLog("%f,%f",elemenent->getPosition().x,elemenent->getPosition().y);
	}
};
cocos2d::CCPoint MenuElement::default_pos = ccp(0,0);


CCScene* RedactorScene::scene(void* point) {
	CCScene *scene = CCScene::create();
	RedactorScene* layer = new RedactorScene();
	if( scene && layer && layer->init()) {
		layer->autorelease();
		scene->addChild(layer);
		return scene;
	}
	CC_SAFE_DELETE(scene);
	CC_SAFE_DELETE(layer);
	return 0x0;
}


bool RedactorScene::init() {
	if( !CCLayer::init()) {
		return false;
	}
	
	AutoElement::initAutoPoint(ScaleCCSprite::createFN("object-point-off.png"));
	
	CCSize size = CCDirector::sharedDirector()->getWinSize();
	ScaleCCSprite* back = ScaleCCSprite::createFN("back.png");
	back->setPosition(ccp(size.width/2,size.height/2));
	this->addChild(back,-1);
	
	menu_back = ScaleCCSprite::createFN("back-bottom.png");
	CCSize m_size = menu_back->getContentSize();
	menu_back->setPosition(ccp(size.width/2,m_size.height/2));
	this->addChild(menu_back);
	
	
	grid_point = 0x0;
	grid_point = ScaleCCSprite::createFN("back-point.png");
	grid_point->retain();
	
	grid_init_rect = CCRect(size.width*0.0127f,m_size.height+size.height*0.0169f,size.width,size.height);
	grid_init_rect.size.width -= grid_init_rect.origin.x + size.width*0.0137f;
	grid_init_rect.size.height -= grid_init_rect.origin.y + size.height*0.0182f;
	
	float padding = AutoElement::grid_cell_size;
	grid_rect = grid_init_rect;
	grid_rect.origin.x += padding;
	grid_rect.origin.y += padding;
	grid_rect.size.width -= 2*padding;
	grid_rect.size.height -= 2*padding;
	
	grid_width = grid_rect.size.width/AutoElement::grid_cell_size;
	grid_height = grid_rect.size.height/AutoElement::grid_cell_size;
	grid_rect.size.width = grid_width*AutoElement::grid_cell_size;
	grid_rect.size.height = grid_height*AutoElement::grid_cell_size;
	
	{
	MenuElement::default_pos = ccp(5,grid_height-5);
	MenuElement::default_pos = ccpMult(MenuElement::default_pos,AutoElement::grid_cell_size);
	MenuElement::default_pos = ccpAdd(MenuElement::default_pos,grid_rect.origin);
	MenuElement::default_pos = ccpAdd(MenuElement::default_pos,ccp(-size.width*0.5f, -size.height*0.5f));
	}
	
	select = 0x0;
	self_auto = Auto::create();
	self_auto->setPosition(size.width/2,size.height/2);
	this->addChild(self_auto);
	
	if( !self_auto->load("self_auto",grid_rect.origin) ) {
		self_auto->addElement("driver", "driver");
	}
	
	loop_menu = ZoneLoopingMenu::createOnRect(CCRect((size.width-m_size.width)/2,0,m_size.width,m_size.height));
	loop_menu->setOrientation(OLM_HORIZONTAL);
	//loop_menu->setIsCircle(true);
	
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-01",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-02",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-03",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-04",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-05",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-06",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-07",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-08",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("beam","beam-09",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("wheel","wheel-01",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("wheel","wheel-02",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("wheel","wheel-03",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("wheel","wheel-04",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("wheel","wheel-05",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("wheel","wheel-06",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("engine","engine-01",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("engine","engine-02",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("engine","engine-03",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("rocket","rocket-01",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("liner","bumper-01",self_auto));
	((CCNode*)loop_menu)->addChild(MenuElement::create("liner","wing-01",self_auto));
	//((CCNode*)loop_menu)->addChild(MenuElement::create("shock","shock-01",self_auto));
	//((CCNode*)loop_menu)->addChild(MenuElement::create("driver","driver",self_auto));
	
	menu_back->addChild(loop_menu);
	
	
	Button* run = Button::create("redactor-button-next.png", "redactor-button-next.png", this, menu_selector(RedactorScene::clickRun));
	run->setPosition(ccp(size.width*0.95f,size.height*0.92f));
	this->addChild(run,100);
	
	Button* clean = Button::create("clear", this, menu_selector(RedactorScene::clickClean));
	clean->setPosition(ccp(size.width*0.055f,size.height*0.92f));
	this->addChild(clean,100);
	
	
	help_plashka = ScaleCCSprite::createFN("help-plashka.png");
	help_label = LabelLocalization::create("help", "help");
	help_plashka->addChild(help_label);
	help_plashka->setPosition(ccp(size.width/2,size.height/2));
	
	this->addChild(help_plashka,125);
	
	
	return true;
}

RedactorScene::~RedactorScene() {
	if( grid_point) {
		grid_point->release();
	}
	AutoElement::initAutoPoint(0x0);
}

void RedactorScene::clickRun(cocos2d::CCObject* obj) {
	loop_menu->pause();
	Button::disable_button = true;
	SceneInformation info = GameScene::getSceneInformation();
	info.p = self_auto;
	
	self_auto->save("self_auto",grid_rect.origin);
	SceneController::get()->push(info);
	help_label->stopAllActions();
	help_label->setOpacity(255);
	help_plashka->stopAllActions();
	help_plashka->setOpacity(255);
}

void RedactorScene::clickClean(cocos2d::CCObject* obj) {
	self_auto->clean();
	self_auto->addElement("driver", "driver");
	self_auto->save("self_auto",grid_rect.origin);
	help_label->stopAllActions();
	help_label->runAction(CCFadeTo::create(0.5f, 255));
	help_plashka->stopAllActions();
	help_plashka->runAction(CCFadeTo::create(0.5f, 255));
}

void RedactorScene::disableHelp() {
	help_label->stopAllActions();
	help_label->runAction(CCFadeTo::create(0.5f, 0));
	help_plashka->stopAllActions();
	help_plashka->runAction(CCFadeTo::create(0.5f, 0));
}

AutoElement* RedactorScene::getObjectIn(cocos2d::CCPoint w_pos,cocos2d::CCPoint& begin_pos) {
	const std::vector<AutoElement*>& elements = self_auto->getElements();
	AutoElement* result = 0x0;
	
	for( size_t i =0; i < elements.size(); i++) {
		CCPoint pos = elements[i]->convertToNodeSpace(w_pos);
		CCRect rect(0,0,0,0);
		rect.size = elements[i]->getContentSize();
		rect.origin = ccp(-rect.size.width*0.5f,-rect.size.height*0.5f);
		
		if( CCRect::CCRectContainsPoint(rect,pos)) {
			result = elements[i];
			begin_pos = result->getPosition();
		}
	}
	
	return result;
}

AutoElement* RedactorScene::getObjectIn(cocos2d::CCPoint w_pos) {
	cocos2d::CCPoint r = ccp(0,0);
	return getObjectIn(w_pos, r);
}

bool RedactorScene::beginAction(CCPoint w_pos,GestureType type) {
	if( SceneController::get()->getScene() != this->getParent()) {
		select = 0x0;
		return false;
	}
	
	select = getObjectIn(w_pos, begin_pos);
	
	if( GestureListener::MOVE == type ) {
		last_real_pos = ccp(0,0);
		last_speed = ccp(0,0);
	}
	
	disableHelp();
	
	return true;
}

float RedactorScene::getScaleMult() {
	return 1;
}
void RedactorScene::scale(float scale) {
	if( 0x0 == select) {
		return;
	}
	//select->setScale(scale);
}


#define SIGN(x) ((x)>0)?1:(((x)==0)?0:-1)
void RedactorScene::move(CCPoint pos,CCPoint delta,CCPoint move,cocos2d::CCPoint speed) {
	if( !select) {
		return;
	}
	
	CCPoint last_pos = select->getPosition();
	select->setPosition(ccpAdd(begin_pos, move));
	last_real_pos = select->getPosition();
	last_speed = speed;
	
	if( !setObjectInGrid(select)) {
		select->setPosition(last_pos);
	}
	
}

bool RedactorScene::setObjectInGrid(AutoElement* obj) {
	const std::vector<CCPoint>& mounting = obj->getMounting();
	
	CCPoint min_len(999999,999999);
	size_t mount_index = mounting.size();

	CCPoint cell_size = ccp(AutoElement::grid_cell_size,AutoElement::grid_cell_size);
	
	for( size_t i =0; i < mounting.size(); i++) {
		CCPoint pos = obj->convertToWorldSpace(mounting[i]);
		CCPoint pos_rect = ccpSub(pos,grid_rect.origin);
		int grid_x = round(pos_rect.x/cell_size.x);
		int grid_y = round(pos_rect.y/cell_size.y);
		grid_x = MIN(grid_x,(int)grid_width); grid_x = MAX(0, grid_x);
		grid_y = MIN(grid_y,(int)grid_height); grid_y = MAX(0, grid_y);
		
		CCPoint grid_pos = ccpAdd(grid_rect.origin, ccp(grid_x*cell_size.x,grid_y*cell_size.y));
		CCPoint len = ccpSub(pos, grid_pos);
		if( ccpLength(len) < ccpLength(min_len)) {
			min_len = len;
			mount_index = i;
		}
	}
	
	if( mount_index < mounting.size()) {
		obj->setPosition(ccpSub(obj->getPosition(),min_len));
		return true;
	}
	
	return false;
}

void RedactorScene::rotate(float angle,float delta_angle) {
	if( 0x0 != select && fabs(delta_angle) > 1.0f) {
		int rotation = select->getRotation();
		CCLog("%f",delta_angle);
		rotation = (delta_angle>0)?(rotation+90):(rotation-90);
		if( rotation < 0) { rotation = floor(fabs(rotation)/360.0f)*360 + rotation; }
		rotation = rotation%360;
		select->setRotation(rotation);
		setObjectInGrid(select);
		select = 0x0;
	}
	
}
void RedactorScene::endAction(CCPoint pos,GestureType type) {
	if( SceneController::get()->getScene() != this->getParent()) {
		return;
	}
	disableHelp();
	
	if( GestureListener::MOVE == type && select) {
		CCSize win_size = CCDirector::sharedDirector()->getWinSize();
		CCPoint next_pos = last_real_pos;
		int sx = next_pos.x;
		int sy = next_pos.y;
		next_pos.x -= SIGN(sx)*select->getContentSize().width;
		next_pos.y -= SIGN(sy)*select->getContentSize().height;
		
		CCPoint speed = ccpMult(last_speed,1.0f);
		next_pos.x += speed.x;
		next_pos.y += speed.y;
		
		next_pos.x += win_size.width*0.5f;
		next_pos.y += win_size.height*0.5f;
		
		cocos2d::CCLog("%d %d %f %f",sx,sy,speed.x,speed.y);
		if( (next_pos.x < grid_init_rect.origin.x && speed.x < 0 && sx < -win_size.width*0.2f) ||
		    (next_pos.y < grid_init_rect.origin.y && speed.y < 0 && sy < -win_size.height*0.2f) ||
		    (next_pos.x > grid_init_rect.origin.x+grid_init_rect.size.width && speed.x > 0 && sx > win_size.width*0.2f) ||
			(next_pos.y > grid_init_rect.origin.y+grid_init_rect.size.height && speed.y > 0 && sy > win_size.height*0.2f)) {
			cocos2d::CCLog("%f %f",next_pos.x,next_pos.y);
			if( select->getName() != "driver") {
				self_auto->removeElement(select);
				select = 0x0;
				return;
			}
		}
	}
	select = 0x0;
	
	if( GestureListener::DOUBLE_CLICK == type) {
		AutoElement* element = getObjectIn(pos);
		if( 0x0 != element) {
			element->flip();
		}	
	}
}

void RedactorScene::draw() {
	if( SceneController::get()->getScene() != this->getParent()) {
		loop_menu->pause();
		Button::disable_button = true;
	} else {
		loop_menu->resume();
		Button::disable_button = false;
	}
	
	CCLayer::draw();
	
	CCPoint cell_size = ccp(grid_rect.size.width/grid_width,grid_rect.size.height/grid_height);
	
	float x_b = grid_init_rect.origin.x;
	float y_b = grid_init_rect.origin.y;
	float x_e = x_b+grid_init_rect.size.width;
	float y_e = y_b+grid_init_rect.size.height;
	static const float tr = cell_size.x/3;
	float x_b_t = grid_rect.origin.x - tr*(int)((grid_rect.origin.x-x_b)/tr);
	float y_b_t = grid_rect.origin.y - tr*(int)((grid_rect.origin.y-y_b)/tr);
	
	ccDrawColor4B(67, 176, 223, 255);
	
	for( float x = x_b_t; x <= x_e; x+=tr) {
		ccDrawLine(ccp(x,y_b),ccp(x,y_e));
	}
	for (float y = y_b_t; y <= y_e; y += tr) {
		ccDrawLine(ccp(x_b,y),ccp(x_e,y));
	}
	ccDrawColor4B(255, 255, 255, 255);
	
	if(grid_point) {
		for( size_t x = 0; x <= grid_width; x++) {
			for (size_t y = 0; y <= grid_height; y++) {
				CCPoint pos = ccpAdd(grid_rect.origin, ccp(x*cell_size.x,y*cell_size.y));
				grid_point->setPosition(pos);
				grid_point->visit();
			}
		}
	}

}

void RedactorScene::visit() {
	CCLayer::visit();
	
}

SceneInformation RedactorScene::getSceneInformation()
{
	SceneInformation info;
	info.createScene = &scene;
	info.p = 0x0;
	
	info.resources.push_back(LoadingData("game-scene/elements/beams"));
	info.resources.push_back(LoadingData("game-scene/elements/drivers"));
	info.resources.push_back(LoadingData("game-scene/elements/engines"));
	info.resources.push_back(LoadingData("game-scene/elements/wheels"));
	info.resources.push_back(LoadingData("game-scene/elements/liner"));
	info.resources.push_back(LoadingData("game-scene/elements/rocket"));
	info.resources.push_back(LoadingData("game-scene/elements/shock"));
	info.resources.push_back(LoadingData("redactor-scene/mount"));
	info.resources.push_back(LoadingData("redactor-scene/menu"));
	info.resources.push_back(LoadingData("redactor-scene/backs"));
	
	return info;
}