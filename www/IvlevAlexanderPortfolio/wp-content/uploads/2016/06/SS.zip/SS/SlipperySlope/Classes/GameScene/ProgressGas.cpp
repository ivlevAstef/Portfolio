//
//  ProgressGas.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 29.08.13.
//
//

#include "ProgressGas.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>


using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

ProgressGas* ProgressGas::create(PhysicAuto* self_auto){
	ProgressGas* pr = new ProgressGas();
	if( pr && pr->init(self_auto)) {
		pr->autorelease();
		return pr;
	}
	CC_SAFE_DELETE(pr);
	return 0x0;
}

bool ProgressGas::init(PhysicAuto* self_auto) {
	this->self_auto = self_auto;
	
	ScaleCCSprite* back = ScaleCCSprite::createFN("gas-progress-back.png");
	CCSize size = back->getContentSize();
	this->setContentSize(size);
	this->addChild(back,-1);
	
	progress = ScaleCCSprite::createFN("gas-progress-center.png");
	progress_rect = progress->getTextureRect();
	progress_offset = progress->getOffsetPosition();
	this->addChild(progress,1);
	
	ScaleCCSprite* top = ScaleCCSprite::createFN("gas-progress-top.png");
	this->addChild(top,10);
	
	this->schedule(schedule_selector(ProgressGas::update));
	
	return true;
}

void ProgressGas::update(float dt){
	if( !self_auto || !progress) {
		return;
	}
	ScaleCCSprite* sprite = ((ScaleCCSprite*)progress);
	float prc = self_auto->getGas()/self_auto->getFullGas();
	
	CCRect rect = progress_rect;
	float width = rect.size.width*(1-prc)*sprite->getScaleFactorX()/CCDirector::sharedDirector()->getContentScaleFactor();
	rect.size.width *= prc;
	
	sprite->setTextureRectForScale(rect);
	sprite->setPosition(ccp( -width,0));
}

