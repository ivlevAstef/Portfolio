//
//  ProgressMap.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 29.08.13.
//
//

#include "ProgressMap.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>


using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;
	
void ProgressMap::AutoProgressInfo::init(PhysicAuto* pauto,AutoProgressPointType type,cocos2d::ccColor3B color) {
	this->pauto = pauto;
	progress = 0;
	switch (type) {
		case SELF_AUTO_POINT:node = ScaleCCSprite::createFN("progress-position.png");z_order = 2; break;
		case ENEMY_AUTO_POINT:node = ScaleCCSprite::createFN("progress-position.png");z_order = 1; break;
		case STATIC_POINT:node = ScaleCCSprite::createFN("progress-last.png");z_order = 0; break;
	}
	if( node) {
		node->setColor(color);
		node->retain();
	}
}
void ProgressMap::AutoProgressInfo::setParent(cocos2d::CCNode* parent) {
	if( 0x0 == node) {
		return;
	}
	if( node->getParent()) {
		node->getParent()->removeChild(node, true);
	}
	parent->addChild(node,z_order);
}
void ProgressMap::AutoProgressInfo::update(const cocos2d::CCPoint& begin,const cocos2d::CCPoint& end) {
	if( 0x0 != pauto) {
		this->auto_pos = pauto->getPosition();
	}
	
	if( fabs(begin.x-end.x) >= 1.0e-3f) {
		progress = (auto_pos.x-begin.x)/(end.x-begin.x);
	}
	
	if( node && node->getParent()) {
		CCSize bsize = node->getParent()->getContentSize();
		node->setPosition(ccp(bsize.width*progress,bsize.height*0.5f));
	}
}

void ProgressMap::AutoProgressInfo::setPos(cocos2d::CCPoint pos) {
	this->auto_pos = pos;
}

void ProgressMap::AutoProgressInfo::remove() {
	if( node && node->getParent()) {
		node->getParent()->removeChild(node, true);
	}
	CC_SAFE_RELEASE_NULL(node);
}


ProgressMap* ProgressMap::create(PhysicAuto* self_auto){
	ProgressMap* pr = new ProgressMap();
	if( pr && pr->init(self_auto)) {
		pr->autorelease();
		return pr;
	}
	CC_SAFE_DELETE(pr);
	return 0x0;
}
bool ProgressMap::init(PhysicAuto* self_auto) {
	back = ScaleCCSprite::createFN("progress.png");
	CCSize size = back->getContentSize();
	this->setContentSize(size);
	this->addChild(back,-1);
	
	AutoProgressInfo info;
	info.init(self_auto, SELF_AUTO_POINT, ccc3(255,255,255));
	info.setParent(back);
	autos.push_back(info);
	
	this->schedule(schedule_selector(ProgressMap::update));
	
	return true;
}

void ProgressMap::setBegin(cocos2d::CCPoint pos){
	this->begin = pos;
}
void ProgressMap::setEnd(cocos2d::CCPoint pos){
	this->end = pos;
}

bool ProgressMap::addAuto(PhysicAuto* enemy) {
	for( size_t i = 0; i < autos.size(); i++) {
		if( autos[i].pauto == enemy) {
			return false;
		}
	}
	
	AutoProgressInfo info;
	info.init(enemy, ENEMY_AUTO_POINT, ccc3(255,125,125));
	info.setParent(back);
	autos.push_back(info);
	return true;
}
bool ProgressMap::removeAuto(PhysicAuto* enemy){
	for( size_t i = 0; i < autos.size(); i++) {
		if( autos[i].pauto == enemy) {
			autos[i].remove();
			autos.erase(autos.begin()+i);
			return true;
		}
	}
	return false;
}

void ProgressMap::addStaticPoint(cocos2d::CCPoint pos) {
	AutoProgressInfo info;
	info.init(0x0, STATIC_POINT, ccc3(255,255,255));
	info.setPos(pos);
	info.setParent(back);
	autos.push_back(info);
}

void ProgressMap::update(float dt){
	for( size_t i = 0; i < autos.size(); i++) {
		autos[i].update(begin, end);
	}
}