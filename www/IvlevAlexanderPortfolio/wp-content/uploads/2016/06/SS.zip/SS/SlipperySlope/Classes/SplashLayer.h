//
//  SplashLayer.h
//  SlipperSlope
//
//  Created by Alexander Ivlev on 18.12.12.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_SPLASH_LAYER_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_SPLASH_LAYER_H_

#include "cocos2d.h"
#include <GrizzlyJr/Graphic/NodeWithResource.h>

namespace GrizzlyJr {
	namespace SlipperSlope {
		
		class SplashLayer: public NodeWithResource {
		public:
			static void create();
		private:
			static void loadNextScene();
		};
	};
};

#endif
