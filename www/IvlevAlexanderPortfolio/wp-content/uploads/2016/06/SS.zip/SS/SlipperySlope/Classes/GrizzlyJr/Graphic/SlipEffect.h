//
//  SlipEffect.h
//  particles
//
//  Created by Alexander Ivlev on 30.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_SLIP_EFFECT_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_SLIP_EFFECT_H_

#include "cocos2d.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		
		class SlipEffect: public cocos2d::CCNode {
		public:
			static const float scale;
		private:
			cocos2d::CCParticleSystemQuad* smoke;
			cocos2d::CCParticleSystemQuad* stone;
			
			SlipEffect():smoke(0x0),stone(0x0) {}
		public:
			static SlipEffect* create(cocos2d::CCPoint speed,cocos2d::CCSpriteFrame* smoke,cocos2d::CCSpriteFrame* stone);
			bool init(cocos2d::CCPoint speed,cocos2d::CCSpriteFrame* smoke,cocos2d::CCSpriteFrame* stone);
			
			void setStoneColor(cocos2d::ccColor3B color);
			void setSmokeColor(cocos2d::ccColor3B color);
			
			virtual void update(float dt);
		private:
			bool initSmoke(cocos2d::CCPoint speed,float duration,cocos2d::CCSpriteFrame* texture);
			bool initStone(cocos2d::CCPoint speed,float duration,cocos2d::CCSpriteFrame* texture);
			
			void end();
		};
	};
};

#endif