#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_GRAPHIC_NODE_WITH_RESOURCE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_GRAPHIC_NODE_WITH_RESOURCE_H_

#include "cocos2d.h"
#include "../SceneController/LoadingData.h"

namespace GrizzlyJr
{
	class NodeWithResource: public cocos2d::CCNode
	{
	private:
		std::vector<LoadingData> data;
	public:
		static NodeWithResource* node(std::vector<LoadingData> data);
		static NodeWithResource* node(LoadingData data);
		NodeWithResource() {}
		NodeWithResource(std::vector<LoadingData> data);
		NodeWithResource(LoadingData data);
		bool init(std::vector<LoadingData> data);
		bool init(LoadingData data);
		~NodeWithResource();
	};
};
#endif
