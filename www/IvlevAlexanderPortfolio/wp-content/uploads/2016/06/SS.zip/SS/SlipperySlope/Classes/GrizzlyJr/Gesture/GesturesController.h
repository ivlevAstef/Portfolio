//
//  GesturesController.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 24.05.13.
//
//

#ifndef _GRIZZLY_JR_GESTURE_CONTROLLER_H_
#define _GRIZZLY_JR_GESTURE_CONTROLLER_H_

#include "cocos2d.h"
#include "GestureListener.h"
#include <vector>

namespace GrizzlyJr
{
	class GestureController
	{
	private:
		static const float UNDEFINED_ANGLE;
		friend class GestureListener;
		struct ListenerInfo {
			GestureListener* listener;
			float scale_mult;
			
			float begin_angle;
			float last_angle;
			cocos2d::CCPoint begin_pos;
			cocos2d::CCPoint last_pos;
			
			cocos2d::CCRect zone;
		};
		std::vector<ListenerInfo> listeners;
		
		void* data;
	private:
		static GestureController* singleton;
		static GestureController* get();
		
		GestureController();
		
		void addListener(GestureListener* listener);
		void addListener(GestureListener* listener, cocos2d::CCRect zone);
		void removeListener(GestureListener* listener);
		void setZoneFor(GestureListener* listener, cocos2d::CCRect zone);
		
		~GestureController();
		
		void beginAction(cocos2d::CCPoint pos,GestureListener::GestureType type);
		void scale(float scale);
		void move(cocos2d::CCPoint pos,cocos2d::CCPoint speed);
		void rotate(float angle);
		void endAction(cocos2d::CCPoint pos,GestureListener::GestureType type);
	public:
		static void pause();
		static void resume();
		
	};
};
#endif
