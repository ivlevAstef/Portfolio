//
//  AutoElement.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_AUTO_ELEMENT_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_AUTO_ELEMENT_H_

#include "cocos2d.h"
#include "Box2D.h"
#include "3DElement.h"
#include "PhysicElement.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		
		class Auto;
		class AutoElement: public _3DElement, public PhysicElement {
		public:
			static int grid_cell_size;
			static void initGridCellSize();
		private:
			static cocos2d::CCSprite* auto_point;
		public:
			static void initAutoPoint(cocos2d::CCSprite* image);
			
		friend class Auto;
		protected:
			~AutoElement() {}
		protected:
			std::string type;
			std::string name;
			int z_order;
			std::vector<cocos2d::CCPoint> mount_points;
		public:
			std::string getType()const { return type; }
			std::string getName()const { return name; }
			int getZOrder()const { return z_order; }
			void flip();
			const std::vector<cocos2d::CCPoint>& getMounting() { return mount_points; }			
		private:
			virtual void draw();
		protected:
			void loadMountingFromFile();
			float getParameter(std::string name);
			
///////////PHYSIC
		public:
			virtual AutoElement* createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale) = 0;///create new AutoElement with body
			virtual AutoElement* createCopy(cocos2d::CCPoint translate,float scale) = 0;///create new AutoElement
			
			virtual void updateImage() { updateNode(this); }
		protected:
			AutoElement() {}
			
			void loadBodyFromFile(b2World* world);
			
			virtual void visit();
		};
		
#define GTRANSLATE(x,y) CCPoint g_tr = ccp(grid_cell_size*(x),grid_cell_size*(y))
#define GPOINT(gx,gy) ccp((gx)*grid_cell_size + g_tr.x,(gy)*grid_cell_size + g_tr.y)
		
	};
};

#endif