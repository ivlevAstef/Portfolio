//
//  Shock.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 15.08.13.
//
//

#include "Shock.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

Shock::Shock(std::string name) {
	this->name = name;
	z_order = 30;
	body = 0x0;
	body2 = 0x0;
	
	ScaleCCSprite* image = ScaleCCSprite::createFN(name+"-center.png");
	CCSize size = image->getContentSize();
	
	this->addChild(image,-1);
	this->setContentSize(size);
	
	loadMountingFromFile();
}

b2Body* Shock::getBody()const {
	return body;
}
float Shock::getMass()const {
	float mass = 0;
	if( 0x0 != body) { mass += body->GetMass(); }
	if( 0x0 != body2) { mass += body2->GetMass(); }
	for( size_t i = 0; i < springs.size(); i++) {
		mass += springs[i]->GetMass();
	}
	return mass;
}

static float getLength(b2Vec2 pos,b2Body* body) {
	if( 0x0 == body) {
		return 99999.9f;
	}
	b2Vec2 dir = body->GetPosition();
	dir -= pos;
	return dir.LengthSquared();
}

b2Body* Shock::getBodyFromPoint(b2Vec2 pos)const {
	b2Body* current = 0x0;
	float min_len = 9999.9f;
	
	float len = getLength(pos,body);
	if( len < min_len) { min_len = len; current = body; }
	
	len = getLength(pos,body2);
	if( len < min_len) { min_len = len; current = body; }
	
	return current;
}

AutoElement* Shock::createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale) {
	Shock* copy = (Shock*)createCopy(translate,scale);
	copy->loadBodyFromFile(world);
	
	return copy;
}

AutoElement* Shock::createCopy(cocos2d::CCPoint translate,float scale) {
	Shock* copy = new Shock(name);
	copy->setPosition(ccpAdd(translate,ccpMult(this->getPosition(),scale)));
	copy->setScaleX(this->getScaleX()*scale);
	copy->setScaleY(scale);
	copy->setRotation(this->getRotation());
	copy->type = this->type;
	copy->autorelease();
	
	return copy;
}


void Shock::updateImage() {
	
}