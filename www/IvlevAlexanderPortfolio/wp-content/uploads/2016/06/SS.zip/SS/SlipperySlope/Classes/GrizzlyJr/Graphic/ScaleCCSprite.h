#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_SCALE_CC_SPRITE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_SCALE_CC_SPRITE_H_

#include "cocos2d.h"

namespace GrizzlyJr
{
	class ScaleCCSprite: public cocos2d::CCSprite
	{
	private:
		bool disableOpacity;
		
		cocos2d::CCSize initSize;
		cocos2d::CCSize scaleSize;
		cocos2d::CCSize scaleFactor;
		bool isScaleContentSize;
		
		cocos2d::CCRect beginTextureRect;
	public:
		static ScaleCCSprite* createFN(std::string name);
		static ScaleCCSprite* createT(cocos2d::CCTexture2D* pTexture);
		static ScaleCCSprite* createF(cocos2d::CCSpriteFrame* pSpriteFrame);
				
		virtual bool initWithTexture(cocos2d::CCTexture2D *pTexture, const cocos2d::CCRect& rect, bool rotated);
		
		cocos2d::CCRect getBeginTextureRect()const { return beginTextureRect; }
		
		void setDisableOpacity(bool isDisable) { disableOpacity = isDisable; }
		
		virtual void setOpacity(GLubyte opacity) {
			if( disableOpacity) {
				CCSprite::setOpacity(255);
			} else {
				CCSprite::setOpacity(opacity);
			}
		}

		virtual GLubyte getOpacity(void) {
			if( disableOpacity) {
				return 255;
			}
			return CCSprite::getOpacity();
		}
		
		virtual void setContentSize(const cocos2d::CCSize& newSize);
		virtual void setFlipX(bool bFlipX);
		virtual void setFlipY(bool bFlipY);
		
		virtual void setDisplayFrame(cocos2d::CCSpriteFrame* pNewFrame);
		
		void setTextureRectForScale(const cocos2d::CCRect& rect);
		
		float getScaleFactorX()const { return scaleFactor.width; }
		float getScaleFactorY()const { return scaleFactor.height; }
		
		virtual void draw();
	};
};
#endif
