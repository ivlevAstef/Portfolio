#include "cocos2d.h"
#include "Config.h"
#include <GrizzlyJr/SceneController/SceneController.h>
#include <GrizzlyJr/FIOM/FIOMMain.h>

#include <GrizzlyJr/Location.h>
#include <GrizzlyJr/WinSizeInfo.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>
#include <GrizzlyJr/Graphic/LabelLocalization.h>

using namespace GrizzlyJr;
using namespace cocos2d;

Config* Config::c = 0x0;

const int Config::application_version = 2;
	
void initAllClasses() {
	std::vector<std::string> devices = Location::getDevicePriority(CCSize(Config::c->winWidth,Config::c->winHeight));
	std::vector<std::string> name_priority;
	for( unsigned int i = 0; i < devices.size(); i++) {
		std::map<std::string,std::string>::iterator iter = WinSizeInfo::file_postfix_by_device.find(devices[i]);
		if( WinSizeInfo::file_postfix_by_device.end() != iter) {
			name_priority.push_back( iter->second);
		}
	}
	SceneController::setPostfixs(name_priority);
	
	///TODO:create normal test
	if( "d960x640" == devices[0] || "d480x320" == devices[0] || "d1136x640" == devices[0]) {
		Config::c->menuType = Config::SMALL_MENU;
	} else {
		Config::c->menuType = Config::BIG_MENU;
	}
	
	Box2DCocos::init();
	
	FIOMMain::get()->loadFile("config/Elements");
	FIOMMain::get()->loadFile("config/LabelLocation");
	FIOMMain::get()->loadFile("config/Positions");	
}

Config::Config()
{
	isFirstLaunch = false;
	isRetina = false;
	winWidth = 0;
	winHeight = 0;
	srand((unsigned int)time(NULL));
	
	c = this;
	
	if( !CCUserDefault::sharedUserDefault()->getBoolForKey("isLaunching",false)) {
		isFirstLaunch = true;
	}
	
	//cocos2d::CCUserDefault::sharedUserDefault()->setBoolForKey("attention-new-task", true);
	
	CCUserDefault::sharedUserDefault()->setBoolForKey("isLaunching",true);
	CCUserDefault::sharedUserDefault()->flush();
}

void Config::init() {
	CCUserDefault::sharedUserDefault()->setIntegerForKey("current_version_application_file",Config::application_version);
	CCUserDefault::sharedUserDefault()->flush();
	
	initAllClasses();
}