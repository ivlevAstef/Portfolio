#include "ScaleCCSprite.h"
#include "../WinSizeInfo.h"
#include "../SceneController/SceneController.h"

using namespace GrizzlyJr;
using namespace cocos2d;

static CCSize getSpriteScale(ScaleCCSprite* sprite) {
	std::string postfix = SceneController::getTexturePostfix(sprite);
	if( postfix.empty()) {
		return CCSize(1,1);
	}
	CCSize size = WinSizeInfo::postfix_win_size[postfix];
	CCSize winSize = CCDirector::sharedDirector()->getWinSizeInPixels();
	
	return CCSize(winSize.height/size.height,winSize.height/size.height);
}

ScaleCCSprite* ScaleCCSprite::createFN(std::string name) {
	ScaleCCSprite* sprite = new ScaleCCSprite();
	if( sprite && sprite->CCSprite::initWithSpriteFrameName(name.c_str()) ) {
		sprite->autorelease();
		return sprite;
	}
	
	CC_SAFE_DELETE(sprite);
	return 0x0;
}

ScaleCCSprite* ScaleCCSprite::createF(cocos2d::CCSpriteFrame* pSpriteFrame) {
	ScaleCCSprite* sprite = new ScaleCCSprite();
	if( sprite && sprite->CCSprite::initWithSpriteFrame(pSpriteFrame) ) {
		sprite->autorelease();
		return sprite;
	}
	
	CC_SAFE_DELETE(sprite);
	return 0x0;
}

ScaleCCSprite* ScaleCCSprite::createT(cocos2d::CCTexture2D* pTexture) {
	ScaleCCSprite* sprite = new ScaleCCSprite();
	if( sprite && sprite->CCSprite::initWithTexture(pTexture) ) {
		sprite->autorelease();
		return sprite;
	}
	
	CC_SAFE_DELETE(sprite);
	return 0x0;
}


bool ScaleCCSprite::initWithTexture(cocos2d::CCTexture2D *pTexture, const cocos2d::CCRect& rect, bool rotated) {
	scaleFactor.width = 1;
	scaleFactor.height = 1;
	isScaleContentSize = false;
	if( CCSprite::initWithTexture(pTexture,rect,rotated)) {
		this->disableOpacity = false;
		scaleFactor = getSpriteScale(this);
		isScaleContentSize = true;
		this->setContentSize(getContentSize());
		
		this->beginTextureRect = rect;
		
		return true;
	}
	return false;
}

void ScaleCCSprite::setTextureRectForScale(const cocos2d::CCRect& rect) {
	isScaleContentSize = false;
	setTextureRect(rect, m_bRectRotated, initSize);
	isScaleContentSize = true;
	setContentSize(initSize);
	
}

void ScaleCCSprite::setContentSize(const cocos2d::CCSize& newSize) {
	initSize = newSize;
	scaleSize = CCSize(initSize.width*scaleFactor.width,initSize.height*scaleFactor.height);
	if( isScaleContentSize) {
		CCSprite::setContentSize(scaleSize);
	} else {
		CCSprite::setContentSize(initSize);
	}
}

void ScaleCCSprite::setFlipX(bool bFlipX) {
	if (m_bFlipX != bFlipX) {
		m_bFlipX = bFlipX;
		isScaleContentSize = false;
		setTextureRect(m_obRect, m_bRectRotated, initSize);
		isScaleContentSize = true;
		setContentSize(initSize);
	}
}

void ScaleCCSprite::setFlipY(bool bFlipY) {
	if (m_bFlipY != bFlipY) {
		m_bFlipY = bFlipY;
		isScaleContentSize = false;
		setTextureRect(m_obRect, m_bRectRotated, initSize);
		isScaleContentSize = true;
		setContentSize(initSize);
	}
}

void ScaleCCSprite::setDisplayFrame(CCSpriteFrame* pNewFrame)
{
	if( 0x0 == pNewFrame) {
		return;
	}
	m_obUnflippedOffsetPositionFromCenter = pNewFrame->getOffset();
	
	CCTexture2D *pNewTexture = pNewFrame->getTexture();
	if (pNewTexture != m_pobTexture) {
		setTexture(pNewTexture);
	}
	
	m_bRectRotated = pNewFrame->isRotated();
	
	isScaleContentSize = false;
	setTextureRect(pNewFrame->getRect(), pNewFrame->isRotated(), pNewFrame->getOriginalSize());
	isScaleContentSize = true;
	setContentSize(pNewFrame->getOriginalSize());
}

void ScaleCCSprite::draw() {
	ccV3F_C4B_T2F_Quad saveQuad = m_sQuad;
	
	float x1 = m_obOffsetPosition.x*scaleFactor.width;
	float y1 = m_obOffsetPosition.y*scaleFactor.height;
	float x2 = x1 + m_obRect.size.width*scaleFactor.width;
	float y2 = y1 + m_obRect.size.height*scaleFactor.height;
	
	m_sQuad.bl.vertices = vertex3( x1, y1, 0 );
	m_sQuad.br.vertices = vertex3( x2, y1, 0 );
	m_sQuad.tl.vertices = vertex3( x1, y2, 0 );
	m_sQuad.tr.vertices = vertex3( x2, y2, 0 );
	
	CCSprite::draw();
	
	m_sQuad = saveQuad;
}
