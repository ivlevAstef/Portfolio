//
//  Auto.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#include "Auto.h"
#include <GrizzlyJr/FIOM/FIOMNode.h>
#include "Elements/Beam.h"
#include "Elements/Driver.h"
#include "Elements/Engine.h"
#include "Elements/Wheel.h"
#include "Elements/Rocket.h"
#include "Elements/Liner.h"
#include "Elements/Shock.h"

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;


Auto::constructors_map_type Auto::initDefaultAutoConstructors() {
	std::map<std::string,constructor_function> result;
	addNewConstructorClass("beam",&executeConstructor<Beam>);
	addNewConstructorClass("driver",&executeConstructor<Driver>);
	addNewConstructorClass("engine",&executeConstructor<Engine>);
	addNewConstructorClass("wheel",&executeConstructor<Wheel>);
	addNewConstructorClass("rocket",&executeConstructor<Rocket>);
	addNewConstructorClass("liner",&executeConstructor<Liner>);
	addNewConstructorClass("shock",&executeConstructor<Shock>);
	return result;
}

void Auto::addNewConstructorClass(std::string type,constructor_function function) {
	constructors[type] = function;
}

Auto::constructors_map_type Auto::constructors = initDefaultAutoConstructors();

Auto::Auto() {
	
}

Auto* Auto::create() {
	Auto* new_auto = new Auto();
	if( new_auto && new_auto->init()) {
		new_auto->autorelease();
		return new_auto;
	}
	CC_SAFE_DELETE(new_auto);
	return 0x0;
}
bool Auto::init() {
	is_visible_mounting = true;
	return true;
}

AutoElement* Auto::getElement(std::string type, std::string name) {
	constructors_map_type::iterator find = constructors.find(type);
	if( find == constructors.end()) {
		return 0x0;
	}
	
	AutoElement* new_element = find->second(name);
	if( 0x0 == new_element) {
		return 0x0;
	}
	
	new_element->autorelease();
	new_element->type = type;
	return new_element;
}

AutoElement* Auto::addElement(std::string type, std::string name) {
	AutoElement* new_element = getElement(type,name);
	if( 0x0 == new_element) {
		return 0x0;
	}
	
	addChild(new_element,new_element->getZOrder(),0);
	
	return new_element;
}

bool Auto::removeElement(AutoElement* element) {
	removeChild(element, true);
	return true;
}

std::vector<AutoElement*> Auto::getElements()const {
	std::vector<AutoElement*> result;
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(m_pChildren, iter) {
		if( iter) {
			result.push_back((AutoElement*)iter);
		}
	}
	return result;
}
std::vector<AutoElement*> Auto::getElements(const std::string type)const {
	std::vector<AutoElement*> result;
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(m_pChildren, iter) {
		if( iter && ((AutoElement*)iter)->type == type) {
			result.push_back((AutoElement*)iter);
		}
	}
	return result;
}
std::vector<AutoElement*> Auto::getElements(const std::vector<std::string> types)const {
	std::vector<AutoElement*> result;
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(m_pChildren, iter) {
		for( size_t j =0; j < types.size(); j++) {
			if( iter && ((AutoElement*)iter)->type == types[j]) {
				result.push_back((AutoElement*)iter);
				break;
			}
		}
	}
	return result;
}

Auto::~Auto() {
}

//////////////////////////////////////////////

void Auto::addChild(CCNode* child) {
	CCNode::addChild(child);
}

void Auto::addChild(CCNode* child, int zOrder) {
	CCNode::addChild(child, zOrder);
}

void Auto::addChild(CCNode* child, int zOrder, int tag) {
	CCNode::addChild(child, zOrder, tag);
}

void Auto::clean() {
	this->removeAllChildrenWithCleanup(true);
}

void Auto::save(std::string name,cocos2d::CCPoint grid_begin) {
	FIOMMain::get()->loadFile("Auto");
	FIOMNode nauto = FIOMNode::get("Auto");
	nauto = nauto.addNextDepth(name, true, false);
	nauto.clear();
	
	std::vector<AutoElement*> elements = getElements();
	for( size_t i =0; i < elements.size(); i++) {
		CCPoint pos = elements[i]->getPosition();
		pos = ccpMult(ccpSub(pos, grid_begin), 1.0f/AutoElement::grid_cell_size);
		
		FIOMNode element = nauto.addNextDepth(i, false, false);
		element.set("n", elements[i]->getName());
		element.set("t", elements[i]->getType());
		element.set("x",pos.x);
		element.set("y",pos.y);
		element.set("r",elements[i]->getRotation());
		element.set("f", elements[i]->getScaleX());
	}
	
	last_grid = grid_begin;
	FIOMMain::get()->saveFile("Auto");
}
bool Auto::load(std::string name,cocos2d::CCPoint grid_begin) {
	FIOMMain::get()->loadFile("Auto");
	
	this->removeAllChildrenWithCleanup(true);
	
	FIOMNode nauto = FIOMNode::get("Auto")[name];
	size_t count = nauto.getArraySize();
	if ( 0 == count) {
		return false;
	}
	for( size_t i =0; i < count; i++) {
		FIOMNode element = nauto[(unsigned int)i];
		std::string name = element.getStr("n");
		std::string type = element.getStr("t");
		if( name.empty() || type.empty()) {
			continue;
		}
		AutoElement* new_element = this->addElement(type,name);
		float x = element.getFloat("x")*AutoElement::grid_cell_size + grid_begin.x;
		float y = element.getFloat("y")*AutoElement::grid_cell_size + grid_begin.y;
		
		new_element->setPosition(ccp(x,y));
		new_element->setRotation(element.getFloat("r"));
		new_element->setScaleX(element.getFloat("f"));
		setElementInGrid(new_element,grid_begin);
	}
	
	last_grid = grid_begin;
	return true;
}

void Auto::setElementInGrid(AutoElement* obj,cocos2d::CCPoint grid_begin) {
	const std::vector<CCPoint>& mounting = obj->getMounting();
	
	CCPoint min_len(999999,999999);
	size_t mount_index = mounting.size();
	
	CCPoint cell_size = ccp(AutoElement::grid_cell_size,AutoElement::grid_cell_size);
	
	for( size_t i =0; i < mounting.size(); i++) {
		CCPoint pos = obj->convertToWorldSpace(mounting[i]);
		CCPoint pos_rect = ccpSub(pos,grid_begin);
		int grid_x = round(pos_rect.x/cell_size.x);
		int grid_y = round(pos_rect.y/cell_size.y);
		
		CCPoint grid_pos = ccpAdd(grid_begin, ccp(grid_x*cell_size.x,grid_y*cell_size.y));
		CCPoint len = ccpSub(pos, grid_pos);
		if( ccpLength(len) < ccpLength(min_len)) {
			min_len = len;
			mount_index = i;
		}
	}
	
	if( mount_index < mounting.size()) {
		obj->setPosition(ccpSub(obj->getPosition(),min_len));
	}
}
