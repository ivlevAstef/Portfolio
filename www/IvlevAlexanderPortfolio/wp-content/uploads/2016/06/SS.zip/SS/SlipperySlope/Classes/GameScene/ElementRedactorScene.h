//
//  ElementRedactorScene.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 29.07.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_ELEMENT_REDACTOR_SCENE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_ELEMENT_REDACTOR_SCENE_H_

#include "cocos2d.h"
#include "Box2D.h"
#include <GrizzlyJr/SceneController/SceneInformation.h>
#include <GrizzlyJr/Gesture/GestureListener.h>
#include <GrizzlyJr/Graphic/ZoneLoopingMenu.h>
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <vector>

namespace GrizzlyJr {
	namespace SlipperSlope {
		
		
		struct AutoElementVisibleFixtureInfo {
		public:
			std::vector<cocos2d::CCPoint> points;
			cocos2d::CCPoint center;
			float radius;
			bool is_circle;
			AutoElementVisibleFixtureInfo():center(ccp(0,0)),radius(0),is_circle(false) {}
			
			float density;
			float friction;
			float restitution;
		};
		
		class AutoElementRedactor: public ScaleCCSprite {
		private:
			std::vector<AutoElementVisibleFixtureInfo> visible_fixture;
			std::string name;
			
		public:
			std::vector<AutoElementVisibleFixtureInfo>& getFix() {
				return visible_fixture;
			}
			
			static AutoElementRedactor* create(std::string name) {
				AutoElementRedactor* new_element = new AutoElementRedactor();
				if( new_element && new_element->CCSprite::initWithSpriteFrameName((name+".png").c_str())) {
					new_element->name = name;
					new_element->autorelease();
					new_element->load();
					return new_element;
				}
				CC_SAFE_DELETE(new_element);
				return 0x0;
			}
			
			void load();
			void save();
		};
		
		
		class ElementRedactorScene: public cocos2d::CCLayer, public GestureListener {
		private:
			cocos2d::CCSprite* menu_back;
			
			ZoneLoopingMenu* loop_menu;			
		public:
			ElementRedactorScene() {}
			virtual ~ElementRedactorScene();
			static cocos2d::CCScene* scene(void* p);
			
			static SceneInformation getSceneInformation();
			bool init();
		private:
			
			virtual void draw();
			virtual void visit();
			
			virtual bool beginAction(cocos2d::CCPoint pos,GestureType type);
			virtual float getScaleMult();
			virtual void scale(float scale);
			virtual void move(cocos2d::CCPoint pos,cocos2d::CCPoint delta,cocos2d::CCPoint move,cocos2d::CCPoint speed);
			virtual void endAction(cocos2d::CCPoint pos,GestureType type);
		};
	};
};
#endif
