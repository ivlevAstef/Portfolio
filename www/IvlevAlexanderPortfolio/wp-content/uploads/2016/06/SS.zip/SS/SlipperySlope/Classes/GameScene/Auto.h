//
//  Auto.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_AUTO_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_AUTO_H_

#include "Elements/AutoElement.h"
#include <vector>

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Auto: public cocos2d::CCNode {
		public:
			typedef AutoElement* (*constructor_function)(std::string name);
			template<typename TYPE> static AutoElement* executeConstructor(std::string name) {
				return new TYPE(name);
			}
			
			static void addNewConstructorClass(std::string type,constructor_function function);
		private:
			typedef std::map<std::string,constructor_function> constructors_map_type;
			static constructors_map_type constructors;
			static constructors_map_type initDefaultAutoConstructors();
			
			bool is_visible_mounting;
			
			cocos2d::CCPoint last_grid;
		private:
			Auto();
		public:
			static AutoElement* getElement(std::string type, std::string name);
			
			static Auto* create();
			virtual bool init();
			
			AutoElement* addElement(std::string type, std::string name);
			bool removeElement(AutoElement* element);
			
			std::vector<AutoElement*> getElements()const;///all
			std::vector<AutoElement*> getElements(const std::string type)const;
			std::vector<AutoElement*> getElements(const std::vector<std::string> types)const;
			
			void recalc();
			
			void clean();
			
			void save(std::string name,cocos2d::CCPoint grid_begin);
			bool load(std::string name,cocos2d::CCPoint grid_begin);
			cocos2d::CCPoint getLastGrid()const { return last_grid; }
			
			void setElementInGrid(AutoElement* element,cocos2d::CCPoint grid_begin);
			
			~Auto();
			
		private:
			virtual void addChild(CCNode* child);
			virtual void addChild(CCNode* child, int zOrder);
			virtual void addChild(CCNode* child, int zOrder, int tag);
		};
	};
};

#endif