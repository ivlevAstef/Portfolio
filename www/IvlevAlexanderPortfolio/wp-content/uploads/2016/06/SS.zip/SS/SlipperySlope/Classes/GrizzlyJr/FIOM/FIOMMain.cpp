#include "FIOMMain.h"
#include <exception>
#include "cocos2d.h"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>

#include "FIOMNode.h"
#include "FIOMTranslate.h"
#include "../Log/LogFunction.h"

using namespace GrizzlyJr;
using namespace std;

#define RELOAD_COUNT_MAX 3

static inline std::string& ltrim(std::string& s) {
	s.erase(s.begin(), std::find_if(s.begin(), s.end(), std::not1(std::ptr_fun<int, int>(std::isspace))));
	return s;
}

// trim from end
static inline std::string& rtrim(std::string& s) {
	s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
	return s;
}

// trim from both ends
static inline std::string& trim(std::string& s) {
	return ltrim(rtrim(s));
}

static FIOMMain::NodeFileImage loadFileStatic(MyVector<MyString>& elements, size_t& pos) {
	FIOMMain::NodeFileImage result;
	result.isArray = false;
	result.isSpecial = false;
	
	bool isBegin = false;
	char endSymbol = 0;
	if( '[' == elements.data[pos].text[0]) {
		result.isArray = true;
		result.isSpecial = false;
		endSymbol = ']';
	} else if( '<' ==elements.data[pos].text[0]) {
		result.isArray = false;
		result.isSpecial = true;
		endSymbol = '>';
	}else if( '{' == elements.data[pos].text[0]) {
		endSymbol = '}';
	}else {
		isBegin = true;
	}
	
	if( !isBegin) {
		pos++;
	}
	
	size_t size = elements.count;
	
	if( result.isArray) {
		int count = 0;
		string name = "0";
		char symbols[16] = {0};
		for( ; pos < size; pos++) {
			if( '[' == elements.data[pos].text[0] || '{' == elements.data[pos].text[0] || '<' == elements.data[pos].text[0]) {
				result.dirs[name] = loadFileStatic(elements,pos);
				count++;
				sprintf(symbols,"%d",count);
				name = symbols;
				name = trim(name);
				continue;
			}
			
			if( !isBegin && endSymbol == elements.data[pos].text[0]) {
				return result;
			}
			
			const char* texts = (char*)elements.data[pos].text;
			result.values[name] = std::string(texts,elements.data[pos].length);
			
			count++;
			sprintf(symbols,"%d",count);
			name = symbols;
			name = trim(name);
		}
		
		return result;
	}
	
	for( ; pos < size; pos++) {
		if( '=' == elements.data[pos].text[0]) {
			const char* texts = (char*)elements.data[pos-1].text;
			std::string name = std::string(texts,elements.data[pos-1].length);
			name = trim(name);
			pos++;
			
			const char* texts2 = (char*)elements.data[pos].text;
			result.values[name] = std::string(texts2,elements.data[pos].length);
			continue;
		}
		if( '[' == elements.data[pos].text[0] || '{' == elements.data[pos].text[0] || '<' == elements.data[pos].text[0]) {
			int savePos = pos-1;
			
			const char* texts = (char*)elements.data[savePos].text;
			std::string name = std::string(texts,elements.data[savePos].length);
			name = trim(name);
			result.dirs[name] = loadFileStatic(elements,pos);
			continue;
		}
		
		if( !isBegin && endSymbol == elements.data[pos].text[0]) {
			return result;
		}
	}
	
	return result;
}

FIOMMain* FIOMMain::singleton = 0x0;

FIOMNode FIOMMain::getRoot(const char* nameFile) {
	std::map<std::string,NodeFileImage>::iterator find = files.find(nameFile);
	if( find == files.end()) {
		return FIOMNode(0x0);
	}
	
	return FIOMNode(&(find->second));
}

FIOMMain::FIOMMain() {
	singleton = this;
}

FIOMMain* FIOMMain::get() {
	if( 0x0 == singleton) {
		return new FIOMMain();
	}
	return singleton;
}

FIOMMain::NodeFileImage* FIOMMain::getNode(std::string file_name) {
	map<string,NodeFileImage>::iterator iter = files.find(file_name);
	if( files.end() == iter ) {
		return 0x0;
	}
	return &iter->second;
}

std::string FIOMMain::fileNameFromFilePath(std::string file_path) {
	size_t found = file_path.find_last_of("/\\");
	if( found == file_path.npos) {
		return file_path;
	}
	return file_path.substr(found+1);
}

std::string FIOMMain::loadFile(std::string file_path) {
	closeFile(file_path);
	string file_name = fileNameFromFilePath(file_path);
		
	unsigned char* dataFile = 0x0;
	unsigned long sizeFile = 0;
	
	cocos2d::CCFileUtils::sharedFileUtils()->setPopupNotify(false);
#ifdef REPLACE_SESSION_MODE
	const char* pathChar = cocos2d::CCFileUtils::fullPathFromRelativePath(file_path.c_str());
	dataFile = cocos2d::CCFileUtils::getFileData(pathChar,"r",&sizeFile);
	CCAssert(dataFile, "Don't find file constant - "+pathStr);
#else 
	std::string file_full_path = cocos2d::CCFileUtils::sharedFileUtils()->getWriteablePath()+file_name;
	dataFile = cocos2d::CCFileUtils::sharedFileUtils()->getFileData(file_full_path.c_str(),"r",&sizeFile);
	if( 0x0 == dataFile) {
		const char* pathChar = cocos2d::CCFileUtils::sharedFileUtils()->fullPathFromRelativePath(file_path.c_str());
		dataFile = cocos2d::CCFileUtils::sharedFileUtils()->getFileData(pathChar,"r",&sizeFile);
		
		std::string msg = "Get data from file("+file_name+") failed!";
#ifdef DEBUG_FILE_MODE
		if( 0x0 == dataFile) {
			cocos2d::CCMessageBox(msg.c_str(), "Notification");
		}
#else
		//CCAssert(dataFile, "Don't find file constant - "+pathStr);
#endif
	}
#endif
	cocos2d::CCFileUtils::sharedFileUtils()->setPopupNotify(true);
	if( 0x0 == dataFile) {
		return "";
	}
	
	bool isLoad = loadFileData(file_name, dataFile, sizeFile);
	delete[] dataFile;
	if( isLoad) {
		return file_name;
	}
		
	return file_name;
}

static void print_fileDIR(FIOMMain::NodeFileImage& dir,int tabs =0) {
	std::map<std::string,FIOMMain::NodeFileImage>::iterator iter;
	std::string tabs_str;
	for( int i =0; i < tabs; i++) {
		tabs_str += "--";
	}
	
	for( iter = dir.dirs.begin(); iter != dir.dirs.end(); ++iter) {
		cocos2d::CCLog("%s",(tabs_str+iter->first).c_str());
		print_fileDIR(iter->second,tabs+1);
	}
}

bool FIOMMain::loadFileData(std::string file_name,unsigned char* dataFile, unsigned long sizeFile) {
	if( 0x0 == dataFile) {
		files[file_name];
		cocos2d::CCLog("file - %s zero", file_name.c_str());
		return false;
	}
	
	MyVector<MyString> elements;
	MyString temp;
	temp.text = dataFile;
	temp.length = sizeFile;
	translate(temp,elements);
	
	if( elements.count > 0) {
		size_t i = 0;
		files[file_name] = loadFileStatic(elements,i);
		NormalLog("load file - %s:",file_name.c_str());
	} else {
		files[file_name] = NodeFileImage();
		NormalLog("don't load file - %s. size =%ld",file_name.c_str(),sizeFile);
	}
	
	for( size_t i =0; i < elements.count; i++) {
		free(elements.data[i].text);
	}
	
	return true;
}

bool FIOMMain::isLoad(std::string path) {
	string file_name = fileNameFromFilePath(path);
	return (files.end() != files.find(file_name));
}

static bool test_NODE(const FIOMMain::NodeFileImage& node) {
	return (0 == node.dirs.size() + node.values.size());
}

int FIOMMain::saveFile(const NodeFileImage& node, std::string& output,bool isFirst) {
	if( test_NODE(node)) {
		return 0;
	}
	size_t node_count = 0;
	
	if( node.isArray && !isFirst) {
		output += "[ "; node_count++;
		
		for( unsigned int i=0; i < node.dirs.size()+node.values.size(); i++) {
			char number[32] = {0};
			sprintf(number,"%d",i);

			std::map<std::string,NodeFileImage>::const_iterator iter = node.dirs.find(number);
			if( iter != node.dirs.end() ) {
				node_count += saveFile(iter->second,output,false);
				continue;
			}
			std::map<std::string,std::string>::const_iterator iterV = node.values.find(number);
			if( iterV != node.values.end() ) {
				output += " \""+iterV->second+"\" "; node_count++;
				continue;
			}			
		}

		output += "] "; node_count++;
	} else {
		if( !isFirst) {
			output += "{ "; node_count++;
		}
		
		std::map<std::string,NodeFileImage>::const_iterator iter;
		for( iter = node.dirs.begin(); iter != node.dirs.end(); iter++) {
			if( !test_NODE(iter->second)) {
				output += iter->first; node_count++;
				node_count += saveFile(iter->second,output,false);
			}
		}
		std::map<std::string,std::string>::const_iterator iterV;
		for( iterV = node.values.begin(); iterV != node.values.end(); iterV++) {
			if( !iterV->first.empty() && !iterV->second.empty()) {
				output += iterV->first; node_count++;
				output += " = "; node_count++;
				output += "\""+iterV->second+"\" "; node_count++;
			}
		}
		
		if( !isFirst) {
			output += "} "; node_count++;
		}
	}
	
	return node_count;
}

void FIOMMain::closeFile(std::string path)  {
	string file_name = fileNameFromFilePath(path);
	
	std::map<std::string,NodeFileImage>::iterator iter = files.find(file_name);
	if( files.end() == iter ) {
		return;
	}
	
	cocos2d::CCLog("close file:%s",file_name.c_str());
	files.erase(iter);
}

void FIOMMain::saveFile(std::string file_path)  {
	std::string file_name = fileNameFromFilePath(file_path);
	std::string file_full_path = cocos2d::CCFileUtils::sharedFileUtils()->getWriteablePath()+file_name;
	
	NodeFileImage* node = getNode(file_name);
	if( !node) {
		return;
	}
	
	std::string data;
	size_t node_count = saveFile(*node, data,true);
	
	FILE* file = fopen(file_full_path.c_str(), "w");
	if( 0x0 != file) {
		NormalLog("save file - %s. count=%ld",file_name.c_str(),node_count);
		fprintf(file, "%s",data.c_str());
		fclose(file);
	} else {
		NormalLog("don't save file - %s.",file_name.c_str());
	}
}

void FIOMMain::removeFile(std::string path) {
	string file_name = fileNameFromFilePath(path);
	
	std::string file_full_path = cocos2d::CCFileUtils::sharedFileUtils()->getWriteablePath()+file_name;
	cocos2d::CCFileUtils::sharedFileUtils()->removeFile(file_full_path.c_str());
	
	if( isLoad(path)) {
		loadFile(path);
	}
	
	/*void CCFileUtils::removeFile(const char* pszFileName) {
		NSFileManager *fileManager = [NSFileManager defaultManager];
		[fileManager removeItemAtPath:[NSString stringWithUTF8String:pszFileName] error:nil];
	}*/
}

