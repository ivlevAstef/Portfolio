//
//  ZoneLoopingMenu.cpp
//  CuteHeroes
//
//  Created by Alexander Ivlev on 23.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "ZoneLoopingMenu.h"

#include "../Gesture/GesturesController.h"

#define SIGN(a) ((a)<0?-1:1)
#define SIGNFULL(a) ((-1.0e-3f<(a)&&(a)<1.0e-3f)?0:SIGN(a))

using namespace GrizzlyJr;
using namespace cocos2d;

ZoneLoopingMenu* ZoneLoopingMenu::createOnRect(CCRect rect,float scaleFactor)
{
	ZoneLoopingMenu* menu = new ZoneLoopingMenu();
	menu->initOnRect(rect);
	menu->autorelease();
	return menu;
}

bool ZoneLoopingMenu::initOnRect(CCRect rect,float scaleFactor) {
	if( CCLayerColor::initWithColor(ccc4(0,0,0,0)) ) {
		area = rect;
		isTouch = false;
		windowTranslate = ccp(0,0);
		
		visit_scale_factor = scaleFactor*CCDirector::sharedDirector()->getContentScaleFactor();
		is_circle = false;
		
		pos = 0;
		len = 0;
		lastDt = 0;
		isPause = false;
		nodeTranslateAdd = 0;
		autoScrollSpeed = 0;

		beginSpeed = 0;
		beginPos = 0;
		time = 0;
		lastMove = 0;
		accMult = 0;
		
		anchorPointForFewElements = 0;

		this->schedule(schedule_selector(ZoneLoopingMenu::tick));
		
		this->setScrollingSpeed(0.1f, -1);
		this->setOrientation(OLM_VERTICAL);
		this->setPadding(0);
		this->setPaddingEdge(0);
		this->updatePositionChildren();
				
		return true;
	}
	
	return false;
}

void ZoneLoopingMenu::addListener(ListenerZoneLoopingMenu* listener) {
	for( size_t i = 0; i < listeners.size(); i++) {
		if( listeners[i] == listener) {
			return;
		}
	}
	listeners.push_back(listener);
}
void ZoneLoopingMenu::removeListener(ListenerZoneLoopingMenu* listener) {
	for( size_t i = 0; i < listeners.size(); i++) {
		if( listeners[i] == listener) {
			listeners.erase(listeners.begin()+i);
			return;
		}
	}
}

void ZoneLoopingMenu::setOpacity(GLubyte) {
	
}

void ZoneLoopingMenu::onExit() {
	CCLayerColor::onExit();
}

ZoneLoopingMenu::~ZoneLoopingMenu() {
}


void ZoneLoopingMenu::addChild(CCNode* child, int zOrder, int tag) {
	CCLayerColor::addChild(child, getChildrenCount(), tag);
	this->updatePositionChildren();
}

void ZoneLoopingMenu::removeChild(CCNode* node, bool cleanup) {
	CCLayerColor::removeChild(node, cleanup);
	this->updatePositionChildren();
}

void ZoneLoopingMenu::changeChild(CCNode* child,CCNode* newChild) {
	int zOrder = child->getZOrder();
	this->cocos2d::CCNode::addChild(newChild,zOrder,newChild->getTag());
	sortAllChildren();
	this->removeChild(child, true);
}

void ZoneLoopingMenu::removeAllChildrenWithCleanup(bool cleanup) {
	CCLayerColor::removeAllChildrenWithCleanup(cleanup);
	this->updatePositionChildren();
}

void ZoneLoopingMenu::setScrollingSpeed(float speed_, float acc_) {
	this->speed = speed_;
	this->acceleration = acc_;
}

void ZoneLoopingMenu::setOrientation(OrientationLoopingMenu orient) {
	dir = ccp(1,0);
	
	switch (orient) {
		case OLM_HORIZONTAL:
			dir = ccp(1, 0);
			lenPos = area.size.width;
			break;
		case OLM_HORIZONTAL_REVERSE:
			dir = ccp(-1, 0);
			lenPos = area.size.width;
			break;
		case OLM_VERTICAL:
			dir = ccp(0, -1);
			lenPos = area.size.height;
			break;
		case OLM_VERTICAL_REVERSE:
			dir = ccp(0, 1);
			lenPos = area.size.height;
			break;
	}
	
	this->updatePositionChildren();
}

void ZoneLoopingMenu::setAutoScroll(float speed) {
	autoScrollSpeed = speed;
}

void ZoneLoopingMenu::setPadding(float padding_) {
	this->padding = padding_;
	this->updatePositionChildren();
}

void ZoneLoopingMenu::setPaddingEdge(float paddingEdge) {
	this->paddingEdge = paddingEdge;
	this->updatePositionChildren();
}

void ZoneLoopingMenu::setWindowTranslate(cocos2d::CCPoint translate) {
	this->windowTranslate = translate;
}

bool ZoneLoopingMenu::isFewElements() {
	if( is_circle) {
		return false;
	}
	if( fabs(dir.x) > fabs(dir.y)) {
		return len-paddingEdge*2 < area.size.width;
	}
	return len-paddingEdge*2 < area.size.height;
}

void ZoneLoopingMenu::updatePositionChildren() {
	float posL = paddingEdge;
	
	if( fabs(dir.x) > fabs(dir.y)) {
		posL += area.origin.x;
		if( dir.x < 0 ) { posL += area.size.width;}
	}else {
		posL += area.origin.y;
		if( dir.y < 0 ) { posL += area.size.height;}
	}
	
	len = paddingEdge;
	CCArray* children = getChildren();
	unsigned int count = 0;
	if( 0x0 != children) {
		count = children->count();
	}
	
	CCSize winSize= CCDirector::sharedDirector()->getWinSize();
	for( unsigned int i =0; i < count; i++) {
		CCNode* node = (CCNode*)children->objectAtIndex(i);
		CCSize size = node->getContentSize();
		size.width *= node->getScaleX();
		size.height *= node->getScaleY();
		if( fabs(dir.x) > fabs(dir.y)) {
			posL += SIGN(dir.x)*(size.width*0.5f + padding*0.5f);
			if( MENU_CHILD_USE_CENTER_WINDOW_TAG == node->getTag()) {
				node->setPosition(ccp(posL, winSize.height*0.5f));
			} else {
				node->setPosition(ccp(posL, area.origin.y + area.size.height*0.5f));
			}
			posL += SIGN(dir.x)*(size.width*0.5f + padding*0.5f);
			
			len += (size.width + padding);
		} else {
			posL += SIGN(dir.y)*(size.height*0.5f + padding*0.5f);
			if( MENU_CHILD_USE_CENTER_WINDOW_TAG == node->getTag()) {
				node->setPosition(ccp(winSize.width*0.5f,posL));
			} else {
				node->setPosition(ccp(area.origin.x + area.size.width*0.5f,posL));
			}
			
			posL += SIGN(dir.y)*(size.height*0.5f + padding*0.5f);
			
			len += (size.height + padding);
		}
	}
	
	len += paddingEdge;
	
	if( pos+lenPos > len) {
		pos = len-lenPos;
	}
	if( pos < 0) {
		pos = 0;
	}
	
	this->updatePosition();
}

void ZoneLoopingMenu::updatePosition() {
	if( isFewElements()) {
		float d = 0;
		if( fabs(dir.x) > fabs(dir.y)) {
			d = area.size.width-len+paddingEdge*2;
		} else {
			d = area.size.height-len+paddingEdge*2;
		}
		
		this->setPosition(ccp(SIGNFULL(dir.x)*d*anchorPointForFewElements,SIGNFULL(dir.y)*d*anchorPointForFewElements));
	} else {
		this->setPosition(ccp(-SIGNFULL(dir.x)*pos,-SIGNFULL(dir.y)*pos));
	}
}

void ZoneLoopingMenu::setPositionUseNode(CCNode* find) {
	if( 0x0 == find) {
		return;
	}
	
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(getChildren(), iter) {
		CCNode* node = dynamic_cast<CCNode*>(iter);
		if( node == find) {
			if( fabs(dir.x) > fabs(dir.y)) {
				pos = node->getPosition().x - this->getContentSize().width*this->getScaleX()/2;
			} else {
				pos = -(node->getPosition().y - this->getContentSize().height*this->getScaleY()/2);
			}
			pos += nodeTranslateAdd;			
			if( !is_circle) {
				if( pos+lenPos > len) {
					pos = len-lenPos;
				}
				if( pos < 0) {
					pos = 0;
				}
			}
			
			beginPos = pos;
			beginSpeed = 0;
			time = 0;
		}
	}
	
	this->updatePosition();
}

void ZoneLoopingMenu::resumeSchedulerAndActions(void) {
	CCLayerColor::resumeSchedulerAndActions();
	isPause = false;
}
void ZoneLoopingMenu::pauseSchedulerAndActions(void) {
	CCLayerColor::pauseSchedulerAndActions();
	isPause = true;
}

void ZoneLoopingMenu::tick(float dt) {
	if( testOnEnd() || isPause) {
		return;
	}
	
	lastDt = dt;
	
	float vel = 1 + time*acceleration*accMult;
	if( isTouch || vel < 0 || 0 == beginSpeed) {
		if( fabs(autoScrollSpeed) > 1.0e-3f && !isTouch){
			pos += autoScrollSpeed*dt;
			if( is_circle) {
				while( pos > 0) {
					pos -= len;
				}
				while( pos < -len) {
					pos += len;
				}
			} else if( pos+lenPos > len || pos < 0) {
				pos = (pos < 0)?0:(len-lenPos);
			}
			
			this->updatePosition();
		}
		return;
	}
	
	pos = beginPos + time*beginSpeed + time*time*0.5f*acceleration*accMult*beginSpeed;
	if( is_circle) {
		while ( pos > 0) {
			pos -= len;
		}
		while ( pos < -len) {
			pos += len;
		}
	} else if( (pos+lenPos > len || pos < 0) && (beginPos+lenPos < len && beginPos > 0 )) {
		pos = (pos < 0)?0:(len-lenPos);
		beginSpeed = 0;
		time = 0;
		beginPos = pos;
	}
	
	
	time += dt;
	
	this->updatePosition();
}

float ZoneLoopingMenu::getProcent()const {
	return pos/(len-lenPos);
}

void ZoneLoopingMenu::visit()
{
	kmGLPushMatrix();
    glEnable(GL_SCISSOR_TEST);
	
    float x = area.origin.x*visit_scale_factor;
    float y = area.origin.y*visit_scale_factor;
    float width = area.size.width*visit_scale_factor;
    float height = area.size.height*visit_scale_factor;
	
    glScissor(x,y,width,height);
	CCLayerColor::visit();
	if( is_circle) {
		CCPoint pos = this->getPosition();
		if( fabs(dir.x) > fabs(dir.y)) {
			width = len;
			height = 0;
		} else {
			width = 0;
			height = len;
		}
		
		this->setPosition(ccpSub(pos, ccp(width,height)));
		CCLayerColor::visit();
		this->setPosition(ccpAdd(pos, ccp(width,height)));
		CCLayerColor::visit();
		
		this->setPosition(ccpSub(pos, ccp(2*width,2*height)));
		CCLayerColor::visit();
		this->setPosition(ccpAdd(pos, ccp(2*width,2*height)));
		CCLayerColor::visit();
		
		this->setPosition(pos);
	}
    glDisable(GL_SCISSOR_TEST);
    kmGLPopMatrix();
}

void ZoneLoopingMenu::endTouch(float move)
{
	if( lastDt < 1.0e-3f) {
		return;
	}
	beginPos = pos;
	
	if( is_circle) {
		beginSpeed = move*speed/lastDt;
		accMult = 1;
	} else {		
		if( pos+lenPos > len) {
			accMult = 2;
			beginSpeed = 2.0f*acceleration*accMult*(beginPos-(len-lenPos));
		}else if( pos < 0) {
			accMult = 2;
			beginSpeed = 2.0f*acceleration*accMult*beginPos;
		}else {
			beginSpeed = move*speed/lastDt;
			accMult = 1;
		}
	}
	
	time = 0;
}

bool ZoneLoopingMenu::testOnEnd() {
	if( 0x0 == this->getParent()) {
		CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this);
		return true;
	}
	return false;
}

bool ZoneLoopingMenu::beginAction(cocos2d::CCPoint w_pos,GestureType type) {
	if( type != GestureListener::MOVE) {
		return false;
	}
	
	if( testOnEnd() ||  isTouch || isPause || !isVisible()) {
		return false;
	}
	
	lastMove = 0;
	this->endTouch(0);
	
	if( w_pos.x < area.origin.x || w_pos.x > area.origin.x + area.size.width ||
	   w_pos.y < area.origin.y || w_pos.y > area.origin.y + area.size.height ) {
		return false;
	}
	
	pre_node = findNodeForPosition(w_pos);
	
	isTouch = true;
	return true;
}

void ZoneLoopingMenu::move(cocos2d::CCPoint w_pos,cocos2d::CCPoint delta,cocos2d::CCPoint move,cocos2d::CCPoint speed) {
	if( !isTouch) {
		return;
	}
	
	if( fabs(dir.x) > fabs(dir.y)) {
		pos -= SIGN(dir.x)*delta.x;
		lastMove = -SIGN(dir.x)*speed.x;
	}else {
		pos -= SIGN(dir.y)*delta.y;
		lastMove = -SIGN(dir.y)*speed.y;
	}
	
	if( pre_node && fabs(lastMove) > area.size.width*0.02f) {
		pre_node = 0x0;
	}
	
	this->updatePosition();
}

void ZoneLoopingMenu::endAction(cocos2d::CCPoint w_pos,GestureType type) {
	if( type != GestureListener::MOVE) {
		return;
	}
	
	if( !isTouch) {
		return;
	}
	
	if( pre_node) {
		cocos2d::CCNode* node = findNodeForPosition(w_pos);
		if( pre_node == node) {
			for( size_t i =0; i < listeners.size(); i++) {
				listeners[i]->clickOnElement(node);
			}
			lastMove = 0;
		}
	}
	
	isTouch = false;
	this->endTouch(lastMove);
}

bool static testNode(CCNode* node,CCPoint pos,CCPoint translate) {
	pos = ccpAdd(pos,ccp(512,0));
	pos = ccpAdd(pos, translate);
	CCRect rect;
	rect.origin = node->getPosition();
	rect.size = node->getContentSize();
	rect.origin.x -= node->getContentSize().width*node->getAnchorPoint().x;
	rect.origin.y -= node->getContentSize().height*node->getAnchorPoint().y;
	return CCRect::CCRectContainsPoint(rect,pos);
}

cocos2d::CCNode* ZoneLoopingMenu::findNodeForPosition(cocos2d::CCPoint position) {
	CCObject* iter = 0x0;
	position.x += SIGNFULL(dir.x)*pos;
	position.y += SIGNFULL(dir.y)*pos;
	CCARRAY_FOREACH(m_pChildren, iter) {
		CCNode* node = (CCNode*)iter;
		
		CCPoint translate = ccp(0,0);
		if( fabs(dir.x) > fabs(dir.y)) {
			translate.x = len;
		} else {
			translate.y = len;
		}
		CCPoint translate2 = ccpMult(translate, 2);
		
		if( testNode(node,position,ccp(0,0))) {
			return node;
		}
		if( is_circle) {
			if( testNode(node,position,translate) || testNode(node,position,ccpNeg(translate)) ||
			   testNode(node,position,translate2) || testNode(node,position,ccpNeg(translate2)) ) {
				return node;
			}
		}
	}
	return 0x0;
}


