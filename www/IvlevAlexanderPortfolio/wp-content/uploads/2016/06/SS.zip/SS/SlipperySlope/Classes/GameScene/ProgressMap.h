//
//  ProgressMap.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 29.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_PROGRESS_MAP_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_PROGRESS_MAP_H_

#include "PhysicAuto.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class ProgressMap: public cocos2d::CCLayer {
		private:
			enum AutoProgressPointType {
				SELF_AUTO_POINT,
				ENEMY_AUTO_POINT,
				STATIC_POINT,
			};
			struct AutoProgressInfo {
			public:
				PhysicAuto* pauto;
			private:
				cocos2d::CCPoint auto_pos;
				float progress;
				int z_order;
				cocos2d::CCSprite* node;
			public:
				AutoProgressInfo():pauto(0x0),progress(0),node(0x0) {}
				
				void init(PhysicAuto* pauto,AutoProgressPointType type,cocos2d::ccColor3B color);
				void setParent(cocos2d::CCNode* parent);
				void update(const cocos2d::CCPoint& begin,const cocos2d::CCPoint& end);
				void setPos(cocos2d::CCPoint pos);
				void remove();
			};
		private:
			std::vector<AutoProgressInfo> autos;
			cocos2d::CCNode* back;
			
			cocos2d::CCPoint begin;
			cocos2d::CCPoint end;
		private:
			ProgressMap():begin(0,0),end(0,0){ }
		public:
			static ProgressMap* create(PhysicAuto* self_auto);
			bool init(PhysicAuto* self_auto);
						
			void setBegin(cocos2d::CCPoint pos);
			void setEnd(cocos2d::CCPoint pos);
			
			bool addAuto(PhysicAuto* enemy);
			bool removeAuto(PhysicAuto* enemy);
			
			void addStaticPoint(cocos2d::CCPoint pos);
			
		private:
			virtual void update(float dt);
		};
	};
};

#endif
