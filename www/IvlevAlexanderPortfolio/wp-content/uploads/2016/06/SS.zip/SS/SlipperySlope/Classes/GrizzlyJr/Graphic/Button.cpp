#include "Button.h"
#include "LabelLocalization.h"

using namespace GrizzlyJr;
using namespace cocos2d;

bool Button::disable_button = false;

Button* Button::create(const char* normal,const char* select,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector)
{
	Button* button = new Button();
	if( button->init(normal, select,target, selector)) {
		button->autorelease();
		return button;		
	}
	delete button;
	return 0x0;
}

Button* Button::create(const char* name,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector)
{
	Button* button = new Button();
	if( button->init(name,target, selector)) {
		button->autorelease();
		return button;		
	}
	delete button;
	return 0x0;
}

bool Button::init(const char* normalStr,const char* selectStr,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector)
{
	pressed_selector = 0x0;
	isPressed = false;
	isStartPress = false;
	if( CCMenu::init() ) {
		CCDirector::sharedDirector()->getTouchDispatcher()->addStandardDelegate(this, 0);
		isTab = false;
		ScaleCCSprite* normal = ScaleCCSprite::createFN(normalStr);
		ScaleCCSprite* select = ScaleCCSprite::createFN(selectStr);
				
		itemSprite = CCMenuItemSprite::create(normal,select,this,menu_selector(Button::clickButton));
		this->setContentSize(itemSprite->getContentSize());
		this->addChild(itemSprite, 0);
		radius = 0;
		
		this->b_target = target;
		this->b_selector = selector;
		return true;
	}
	return false;
}

bool Button::init(const char* name,cocos2d::CCObject* target,cocos2d::SEL_MenuHandler selector)
{
	char normalName[128] = {0};
	char selectName[128] = {0};
	strcpy(normalName, name);
	strcpy(selectName, name);
	strcat(normalName,".png");
	strcat(selectName,"-select.png");
	return init(normalName,selectName,target,selector);
}

Button::~Button() {
	//CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this);
	while (self_links.size() >0) {
		self_links[0]->removeLinkedButton(this);
	}
}

void Button::setPressedSelector(cocos2d::SEL_SCHEDULE pressed_selector) {
	this->pressed_selector = pressed_selector;
	this->schedule(schedule_selector(Button::update));
}

void Button::update(float dt) {
	if( b_target && pressed_selector && isPressed) {
		(b_target->*pressed_selector)(dt);
	}
}

void Button::addLinkedButton(Button* button) {
	for( size_t i =0; i < linked_button.size(); i++) {
		if( linked_button[i] == button) {
			return;
		}
	}
	linked_button.push_back(button);
	button->self_links.push_back(this);
}
void Button::removeLinkedButton(Button* button) {
	for( size_t i =0; i < linked_button.size(); i++) {
		if( linked_button[i] == button) {
			linked_button.erase(linked_button.begin()+i);
			break;
		}
	}
	for( size_t i =0; i < button->self_links.size(); i++) {
		if( button->self_links[i] == this) {
			button->self_links.erase(button->self_links.begin()+i);
			break;
		}
	}
}

cocos2d::CCSize Button::getSize() {
	return getContentSize();
}
float Button::getWidth() {
	return getContentSize().width;
}
float Button::getHeight() {
	return getContentSize().height;
}


void Button::addTextID(const char* idText,const char* idLocation) {
	addTextID(idText, idLocation, idLocation);
}
void Button::addTextID(const char* idText,const char* idLocationNormal,const char* idLocationSelect) {
	LabelLocalization* normal = LabelLocalization::create(idText, idLocationNormal);
	LabelLocalization* select = LabelLocalization::create(idText, idLocationSelect);
	getNormal()->addChild(normal,1);
	getSelect()->addChild(select,1);
}

void Button::addText(const char* text,const char* idLocation)
{
	addText(text, idLocation,idLocation);
}

void Button::addText(const char* text,const char* idLocationNormal,const char* idLocationSelect)
{
	LabelLocalization* normal = LabelLocalization::createT(text, idLocationNormal);
	LabelLocalization* select = LabelLocalization::createT(text, idLocationSelect);
	getNormal()->addChild(normal,1);
	getSelect()->addChild(select,1);
}

void Button::removeAllChild() {
	getNormal()->removeAllChildrenWithCleanup(true);
	getSelect()->removeAllChildrenWithCleanup(true);
}

void Button::addNumber(const char* prefix,int number,const char* idLocation)
{	
	addNumber(prefix, number, idLocation,idLocation);
}
void Button::addNumber(const char* prefix,int number,const char* idLocationNormal,const char* idLocationSelect)
{
	char text[128] = {0};
	if( 0x0 != prefix) {
		sprintf(text,"%s%d",prefix,number);
	}else {
		sprintf(text,"%d",number);
	}
	addText(text, idLocationNormal,idLocationSelect);
}

void Button::addImage(const char* name)
{
	char normalName[128] = {0};
	char selectName[128] = {0};
	strcpy(normalName, name);
	strcpy(selectName, name);
	strcat(normalName,".png");
	strcat(selectName,"-select.png");
	addImage(normalName,selectName);
}

void Button::addImage(const char* normal,const char* select)
{
	ScaleCCSprite* imageN = ScaleCCSprite::createFN(normal);
	ScaleCCSprite* imageS = ScaleCCSprite::createFN(select);
	
	CCSize size = getSize();
	imageN->setPosition(ccp(size.width/2,size.height/2));
	imageS->setPosition(ccp(size.width/2,size.height/2));
	
	getNormal()->addChild(imageN); 
	getSelect()->addChild(imageS); 
}

CCMenuItem* Button::itemForTouch(CCTouch *touch) {
	CCPoint touchLocation = touch->locationInView();
	touchLocation = CCDirector::sharedDirector()->convertToGL(touchLocation);
	
	if (m_pChildren && m_pChildren->count() > 0)
	{
		CCObject* pObject = NULL;
		CCARRAY_FOREACH(m_pChildren, pObject)
		{
			CCNode* pChild = dynamic_cast<CCNode*>(pObject);
			if (pChild && pChild->isVisible() && ((CCMenuItem*)pChild)->isEnabled()) {
				CCPoint local = pChild->convertToNodeSpace(touchLocation);
				
				CCSize size = this->getContentSize();
				
				CCRect r = CCRectMake( 0, 0, size.width, size.height);
				if (CCRect::CCRectContainsPoint(r,local)) {
					local = pChild->getParent()->convertToNodeSpace(touchLocation);
					float r = ccpLength(local);
					if( radius <= 0 || r< radius) {
						return (CCMenuItem*)pChild;
					}
				}
			}
		}
		
	}
	return NULL;
}

void Button::changeStateLinkedButtons() {
	if( itemSprite->isSelected()) {
		for(size_t i =0; i < linked_button.size(); i++) {
			linked_button[i]->itemSprite->selected();
		}
	} else {
		for(size_t i =0; i < linked_button.size(); i++) {
			linked_button[i]->itemSprite->unselected();
		}
	}
}

void Button::ccTouchesBegan(cocos2d::CCSet* pTouches, cocos2d::CCEvent* pEvent) {
//	cocos2d::CCLog("BEGAN = %d",pTouches->count());
//	if( disable_button && !working_all_time) {
//		return;
//	}
//	if( !isEnableClick || isStartPress) {
//		return;
//	}
//	if( isTab && itemSprite->isSelected()) {
//		return;
//	}
//	
//	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
//		CCTouch* touch = (CCTouch*)(*iter);
//		if( CCMenu::ccTouchBegan(touch, pEvent) ) {
//			changeStateLinkedButtons();
//			isStartPress = true;
//			isPressed = true;
//			this->begin_pos = this->convertToWorldSpace(ccp(0,0));
//			touch_pos = touch->locationInView();
//			return;
//		}
//	}
	
}
void Button::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
//	cocos2d::CCLog("MOVE = %d",pTouches->count());
//	if( !isStartPress) {
//		return;
//	}
//	cocos2d::CCPoint self_pos = this->convertToWorldSpace(ccp(0,0));
//	if( ccpDistance(begin_pos,self_pos) > 20) {
//		ccTouchesCancelled(pTouches, pEvent);
//		return;
//	}
//	
//	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
//		CCTouch* touch = (CCTouch*)(*iter);
//		if( ccpDistance(touch->previousLocationInView(),touch_pos) < 1) {
//			touch_pos = touch->locationInView();
//			CCMenu::ccTouchMoved(touch, pEvent);
//			if( m_pSelectedItem) {
//				isPressed = m_pSelectedItem->isSelected();
//			} else {
//				isPressed = false;
//			}
//			changeStateLinkedButtons();
//			return;
//		}
//	}
}
void Button::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
//	cocos2d::CCLog("ENDED = %d",pTouches->count());
//	if( disable_button && !working_all_time) {
//		return;
//	}
//	if( !isStartPress) {
//		return;
//	}
//	
//	bool isClick = (0x0 ==m_pSelectedItem)?false:true;
//	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
//		CCTouch* touch = (CCTouch*)(*iter);
//		if( ccpDistance(touch->previousLocationInView(),touch_pos) < 1) {
//			isPressed = false;
//			isStartPress = false;
//			CCMenu::ccTouchEnded(touch, pEvent);
//			changeStateLinkedButtons();
//			if( isClick) {
//				clickOnSelf();
//			}
//		}
//	}
}
void Button::ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
//	cocos2d::CCLog("CANCEL = %d",pTouches->count());
//	for(CCSetIterator iter = pTouches->begin(); iter != pTouches->end(); ++iter) {
//		CCTouch* touch = (CCTouch*)(*iter);
//		if( ccpDistance(touch->previousLocationInView(),touch_pos) < 1) {
//			isPressed = false;
//			isStartPress = false;
//			CCMenu::ccTouchCancelled(touch, pEvent);
//			changeStateLinkedButtons();
//		}
//	}
}

bool Button::ccTouchBegan(CCTouch* touch, CCEvent* event) {
	if( disable_button && !working_all_time) {
		return false;
	}
	if( !isEnableClick || isStartPress) {
		return false;
	}
	if( isTab && itemSprite->isSelected()) {
		return false;
	}
	
	if( CCMenu::ccTouchBegan(touch, event) ) {
		changeStateLinkedButtons();
		isStartPress = true;
		isPressed = true;
		this->begin_pos = this->convertToWorldSpace(ccp(0,0));
		return true;
	}
	return false;
	return false;
}
void Button::ccTouchMoved(cocos2d::CCTouch *touch, cocos2d::CCEvent *event) {
	if( !isStartPress) {
		return;
	}
	cocos2d::CCPoint self_pos = this->convertToWorldSpace(ccp(0,0));
	if( ccpDistance(begin_pos,self_pos) > 20) {
		ccTouchCancelled(touch, event);
		return;
	}
	
	CCMenu::ccTouchMoved(touch, event);
	if( m_pSelectedItem) {
		isPressed = m_pSelectedItem->isSelected();
	} else {
		isPressed = false;
	}
	changeStateLinkedButtons();
}
void Button::ccTouchEnded(CCTouch *touch, CCEvent* event) {
	if( !isStartPress) {
		return;
	}
	isPressed = false;
	isStartPress = false;
	if( disable_button && !working_all_time) {
		return;
	}

	bool isClick = (0x0 ==m_pSelectedItem)?false:true;
	CCMenu::ccTouchEnded(touch, event);
	changeStateLinkedButtons();
	
	if( isClick) {
		clickOnSelf();
	}
}
void Button::ccTouchCancelled(cocos2d::CCTouch *touch, cocos2d::CCEvent *event) {
	if( !isStartPress) {
		return;
	}
	isPressed = false;
	isStartPress = false;
	cocos2d::CCLog("CANCEL TOUCH");
	CCMenu::ccTouchCancelled(touch, event);
	changeStateLinkedButtons();
}

static void removeAllChildFromNodeUseOrder(cocos2d::CCNode* main,int order) {
RESTART_FIND:;
	CCObject* obj = 0x0;
	CCARRAY_FOREACH(main->getChildren(), obj) {
		CCNode* node = (CCNode*)obj;
		if( node && order == node->getZOrder()) {
			main->removeChild(node, true);
			goto RESTART_FIND;
		}
	}
}
#define CHILD_ORDER 999
void Button::enableOnHelp() {
	isEnableClick = true;
	removeAllChildFromNodeUseOrder(itemSprite,CHILD_ORDER);
}
void Button::disableOnHelp() {
	isEnableClick = false;
	removeAllChildFromNodeUseOrder(itemSprite,CHILD_ORDER);
}

void Button::addNodeChild(void* child) {
	itemSprite->addChild((CCNode*)child,CHILD_ORDER);
}

static void setColorStatic(const cocos2d::ccColor3B& color,CCNode* node) {
	CCArray* children = node->getChildren();
	
	if (children && children->count() > 0) {
		CCObject* pObject = NULL;
		CCARRAY_FOREACH(children, pObject) {
			CCNode* pChild = dynamic_cast<CCNode*>(pObject);
			if (pChild) {
				CCRGBAProtocol *pRGBAProtocol = dynamic_cast<CCRGBAProtocol*>(pChild);
				if (pRGBAProtocol) {
					pRGBAProtocol->setColor(color);
				}
				
				setColorStatic(color, pChild);
			}
		}
	}
}

void Button::setColor(const cocos2d::ccColor3B& color) {
	CCMenu::setColor(color);
	setColorStatic(color,getItemSprite());
}
const cocos2d::ccColor3B& Button::getColor(void) {
	return CCMenu::getColor();
}

static void setOpacityStatic(GLubyte opacity,CCNode* node) {
	CCArray* children = node->getChildren();
	
	if (children && children->count() > 0) {
		CCObject* pObject = NULL;
		CCARRAY_FOREACH(children, pObject) {
			CCNode* pChild = dynamic_cast<CCNode*>(pObject);
			if (pChild) {
				CCRGBAProtocol *pRGBAProtocol = dynamic_cast<CCRGBAProtocol*>(pChild);
				if (pRGBAProtocol) {
					pRGBAProtocol->setOpacity(opacity);
				}
				setOpacityStatic(opacity, pChild);
			}
		}
	}
}

void Button::clickButton(cocos2d::CCObject* obj) {
	//SoundController::get()->playEffect(0x0,"click-button");
	if (b_target && b_selector) {
		(b_target->*b_selector)(obj);
	}
}

GLubyte Button::getOpacity(void) {
	return CCMenu::getOpacity();
}
void Button::setOpacity(GLubyte opacity) {
	CCMenu::setOpacity(opacity);
	setOpacityStatic(opacity,getItemSprite());
}
		
void Button::flipX(bool isFlip)
{
	getNormal()->setFlipX(isFlip);
	getSelect()->setFlipX(isFlip);
}
void Button::flipY(bool isFlip)
{
	getNormal()->setFlipY(isFlip);
	getSelect()->setFlipY(isFlip);
}

ScaleCCSprite* Button::getNormal()
{
	return ((ScaleCCSprite*)itemSprite->getNormalImage());
}

ScaleCCSprite* Button::getSelect()
{
	return ((ScaleCCSprite*)itemSprite->getSelectedImage());
}

void Button::useRadialButtonTest(float radius) {
	this->radius = radius;
}