//
//  PhysicElementWith3D.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 14.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_3D_ELEMENT_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_3D_ELEMENT_H_

#include "cocos2d.h"
#include "Box2D.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class _3DElement: public cocos2d::CCNode {
		protected:
			cocos2d::CCPoint center;
			float depth;
			_3DElement();
		public:
			virtual void visit3dView(float glob_angle);
			
			float getDepth()const { return depth; }
		protected:
			cocos2d::CCPoint calc3dTranslate(float glob_angle);
		};
	};
};

#endif
