#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_LABEL_LOCALIZATION_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_LABEL_LOCALIZATION_H_

#include "cocos2d.h"
#include "../FIOM/FIOMNode.h"

namespace GrizzlyJr
{
	class LabelLocalization: public cocos2d::CCTextFieldTTF
	{
	private:
		time_t time_end;
	public:
		static LabelLocalization* create(std::string id_text,std::string id_name);
		static LabelLocalization* create(int number,std::string id_name);
		
		bool init(std::string id_text,std::string id_name);
		
		static LabelLocalization* createT(std::string text,std::string id_name);
		bool initT(std::string text,std::string id_name);
		
		static LabelLocalization* createDate(time_t time,std::string id_name);
		bool initDate(time_t time,std::string id_name);
		
		static std::string getFontName();
		
		virtual void draw();
	};
};
#endif
