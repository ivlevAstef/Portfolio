//
//  Translate.cpp
//  CreptingFiles
//
//  Created by Alexander Ivlev on 24.04.13.
//
//

#ifndef _GRIZZLY_JR_FIOM_TRANSLATE_FILE_H_
#define _GRIZZLY_JR_FIOM_TRANSLATE_FILE_H_

#include <string>
#include <stdlib.h>

#define ADD_SIZE_FOR_DECRYPT_SYSTEM 16
#define SIZE_ONE_NUMBER_STR 8

struct MyString {
	unsigned char* text;
	size_t length;
	MyString():text(0x0),length(0) {}
};

#define ONE_ALLOC_ADD_SIZE 10
template<typename TYPE>
struct MyVector {
	TYPE* data;
	size_t count;
	size_t memory_count;
	
	MyVector():data(0x0),count(0),memory_count(0) {}
	
	void alloc(size_t size) {
		if( 0x0 == data) {
			data = (TYPE*)calloc(size, sizeof(TYPE));
		} else {
			data = (TYPE*)realloc(data, sizeof(TYPE)*size);
		}
		memory_count = size;
	}
	void add(TYPE value) {
		if( count >= memory_count) {
			if( 0 == memory_count) {
				memory_count = ONE_ALLOC_ADD_SIZE;
			}
			alloc(memory_count+ONE_ALLOC_ADD_SIZE);
		}
		data[count++] = value;
	}
	
	void remove() {
		if( count > 0) {
			count--;
		}
	}
	
	~MyVector() {
		if( 0x0 != data) {
			free(data);
		}
	}
};

#define MAX_LENGTH_ONE_DATA 1024
static void add_and_new_buffer(MyString& buffer,MyVector<MyString>& elements) {
	if( 0 != buffer.length) {
		buffer.text = (unsigned char*)realloc(buffer.text, buffer.length*sizeof(unsigned char));
		elements.add(buffer);
		buffer.text = (unsigned char*)malloc(MAX_LENGTH_ONE_DATA*sizeof(unsigned char));
		buffer.length = 0;
	}
}


static void translate(MyString myStr,MyVector<MyString>& elements) {
	static const int countChars = 11;
	static const int countCharsSave = 7;
	static const char chars[countChars] = { ' ', '\n', '\r', '=', '{', '}', '[', ']','<','>','"'};
	static const char charsSave[countCharsSave] = { '=', '{', '}', '[', ']','<','>'};
	
	bool beginBracketText = false;
	bool beginGlobalComment = false;
	size_t length = myStr.length;
	const unsigned char* str = myStr.text;
	
	MyString buffer;
	buffer.text = (unsigned char*)malloc(MAX_LENGTH_ONE_DATA*sizeof(unsigned char));
	buffer.length = 0;
	for( size_t i =0; i < length; i++) {
		if( '/' == str[i] && i+1< length && '*' == str[i+1] && !beginBracketText) {
			beginGlobalComment = true;
			i++;
		}
		
		if( '*' == str[i] && i+1< length && '/' == str[i+1] && !beginBracketText) {
			beginGlobalComment = false;
			i+=2;
		}
		
		unsigned char ch = str[i];
		if( beginGlobalComment) {
			continue;
		}
		
		if( '/' == str[i] && i+1< length && '/' == str[i+1] && !beginBracketText) {
			for(; i < length; i++) {
				if( '\n' == str[i]) {
					if( i > 0){ i--; }
					break;
				}
			}
			continue;
		}
		
		if( '"' == str[i] && i+1< length && '"' == str[i+1] && beginBracketText) {
			buffer.text[buffer.length++] = ch;
			i++;
			continue;
		}
		
		if( '"' == str[i] && beginBracketText) {
			if( 0 == buffer.length) {
				buffer.text[buffer.length++] = ' ';
			}
			add_and_new_buffer(buffer,elements);
			beginBracketText = false;
			continue;
		}
		
		if( 9 == ch) {///TAB
			continue;
		}
		
		if( !beginBracketText) {
			if( '"' == ch) {
				beginBracketText = true;
				continue;
			}
			bool isBegin = false;
			for( size_t j = 0; j < countChars; j++) {
				if( chars[j] == ch) {
					add_and_new_buffer(buffer,elements);
					isBegin = true;
					break;
				}
			}
			
			for( size_t j = 0; j < countCharsSave; j++) {
				if( charsSave[j] == ch) {
					if( elements.count > 0 && '=' == elements.data[elements.count-1].text[0]) {
						elements.remove();
					}
					MyString strNew;
					strNew.text = (unsigned char*)malloc(1*sizeof(unsigned char));
					strNew.text[0] = ch;
					strNew.length = 1;
					elements.add(strNew);
					break;
				}
			}
			
			if( isBegin) {
				continue;
			}
		}
		
		if( buffer.length+1 < MAX_LENGTH_ONE_DATA) {
			buffer.text[buffer.length++] = ch;
		}
	}
	
	if( buffer.length > 0) {
		buffer.text = (unsigned char*)realloc(buffer.text, buffer.length*sizeof(unsigned char));
		elements.add(buffer);
	}else {
		free(buffer.text);
	}
}

void addSizeInString(std::string& string,size_t size) {
	std::string add_data;
	for( size_t i =0; i < SIZE_ONE_NUMBER_STR; i++) {
		int data = size%10;
		size /= 10;
		add_data = (char)(data+'0') + add_data;
	}
	string = add_data+string;
}

bool test_for_correct(unsigned char* dataFile,std::string& input,MyVector<MyString>& elements) {
	size_t file_size = 0;
	for( size_t i =0; i < SIZE_ONE_NUMBER_STR; i++) {
		file_size *= 10;
		file_size += dataFile[i]-'0';
	}
	
	size_t node_count = 0;
	for( size_t i =SIZE_ONE_NUMBER_STR; i < SIZE_ONE_NUMBER_STR*2; i++) {
		node_count *= 10;
		node_count += dataFile[i]-'0';
	}
	
	if( input.size() != file_size) {
		printf("INPUT= %ld",input.size());
		return false;
	}
	if( node_count != elements.count) {
		printf("ELEMENTS= %ld",elements.count);
		return false;
	}
	return true;
}

#endif

