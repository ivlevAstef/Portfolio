//
//  PhysicElement.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 14.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_PHYSIC_ELEMENT_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_PHYSIC_ELEMENT_H_

#include "cocos2d.h"
#include "Box2D.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		class PhysicElement {
		protected:
			b2Body* body;
			uint16 categoryBits;
			uint16 maskBits;
			
			PhysicElement(): body(0x0),categoryBits(0x0002),maskBits(0x0004) {}
		public:
			virtual b2Body* getBody()const { return body; }
			virtual float getMass()const { if( 0x0 == body) {return 0; } return body->GetMass(); }
			virtual b2Body* getBodyFromPoint(b2Vec2 pos)const { return body; }
			
			
		protected:
			b2Body* loadBodyFromFile(b2World* world,std::string name,cocos2d::CCNode* node);
			void setPosAndAngleBodyDef(b2BodyDef& bdef,cocos2d::CCNode* node);
			void updateNode(cocos2d::CCNode* node);
		};
	};
};

#endif
