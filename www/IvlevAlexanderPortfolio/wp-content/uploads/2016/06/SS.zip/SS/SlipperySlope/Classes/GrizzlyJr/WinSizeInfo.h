#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_WIN_SIZE_INFO_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_WIN_SIZE_INFO_H_

#include "cocos2d.h"
#include <string>
#include <map>
#include <vector>

namespace GrizzlyJr
{
	struct WinSizeInfo {
		static std::map<std::string,cocos2d::CCSize> win_size_names;
		static std::vector<cocos2d::CCSize> win_sizes;
		static std::vector<std::string> win_size_names_array;
		
		static std::map<std::string,std::string> file_postfix_by_device;
		
		static std::map<std::string,cocos2d::CCSize> postfix_win_size;
	};
};

#endif
