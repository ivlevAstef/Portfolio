//
//  GestureGeometryController.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 05.09.13.
//
//

#ifndef _GRIZZLY_JR_GESTURE_GEOMETRY_CONTROOLER_H_
#define _GRIZZLY_JR_GESTURE_GEOMETRY_CONTROOLER_H_

#include "cocos2d.h"
#include "GestureGeometryListener.h"
#include <string>
#include <vector>

namespace GrizzlyJr {
	class GestureGeometryController: public cocos2d::CCTouchDelegate {
	public:
		static GestureGeometryController* get();
		
		bool addListener(GestureGeometryListener* listener);
		bool removeListener(GestureGeometryListener* listener);
		
		void useAutoRecord(bool auto_record);
		
		bool startRecord();
		bool endRecord();
		
		bool saveGesture(std::string gesture_name);
		
		bool isGestureEqual(std::string gesture_name);
		std::string getGestureName();
		
	private:
		GestureGeometryController();
		void executeListener(std::function<void (GestureGeometryListener* l)> function);
		
		struct GestureOneTouchInfo {
			std::vector<cocos2d::CCPoint> points;
			float draw_time;
		};
		typedef std::vector<GestureOneTouchInfo> GestureInfo;
		
		enum class ComponentType {
			SIMPLE_GEOMETRY,
			COMPONENT_GEOMETRY,
			DELAY
		};
		
		class Component {
		public:
			virtual ComponentType getType()const = 0;
		};
		
		class Delay: public Component {
		private:
			float delay;
		public:
			Delay():Delay(0) {}
			Delay(float delay):delay(delay) {}
			void setDelay(float delay) { this->delay = delay; }
			float getDelay()const { return delay; }
			virtual ComponentType getType()const override { return ComponentType::DELAY; }
		};
		
		
		class SimpleGeometry: public Component {
		private:
			GestureInfo self_info;
		public:
			virtual bool is(const GestureInfo& gesture_info);
			
			virtual ComponentType getType()const override { return ComponentType::SIMPLE_GEOMETRY; }
		};
		
		class ComponentGeometry: public SimpleGeometry {
		private:
			std::vector<Component*> components;
		public:
			virtual bool is(const GestureInfo& gesture_info) override;
			virtual ComponentType getType()const override { return ComponentType::COMPONENT_GEOMETRY; }
		};
		
		void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
		void ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
	private:
		static GestureGeometryController* singleton;
		
		bool is_auto_record;
		bool is_record;
		std::vector<GestureGeometryListener*> listeners;
		GestureInfo current;
	};
};

#endif
