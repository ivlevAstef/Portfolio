//
//  GestureListener.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 24.05.13.
//
//

#ifndef _GRIZZLY_JR_GESTURE_LISTENER_H_
#define _GRIZZLY_JR_GESTURE_LISTENER_H_

#include "cocos2d.h"

namespace GrizzlyJr {
	class GestureController;
	class GestureListener {
	public:
		enum GestureType {
			SCALE,
			MOVE,
			ROTATION,
			DOUBLE_CLICK,
			CLICK,
		};
	protected:
		GestureListener();
		virtual ~GestureListener();
	private:
		friend class GestureController;
		virtual bool beginAction(cocos2d::CCPoint pos,GestureType type) = 0;
		virtual float getScaleMult() { return 1; }
		virtual void scale(float scale) {};
		///dx,dy = pos-last_pos, mx,my = pos-begin_pos
		virtual void move(cocos2d::CCPoint pos,cocos2d::CCPoint delta,cocos2d::CCPoint move,cocos2d::CCPoint speed) {};
		virtual void rotate(float angle,float delta_angle) {};
		virtual void endAction(cocos2d::CCPoint pos,GestureType type) = 0;
	};
};
#endif