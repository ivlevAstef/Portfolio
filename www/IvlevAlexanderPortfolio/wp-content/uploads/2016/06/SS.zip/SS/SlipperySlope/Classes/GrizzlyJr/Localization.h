#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_LOCALIZATION_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_LOCALIZATION_H_

#include <vector>
#include <string>
#include <map>

namespace GrizzlyJr
{
	class Localization
	{
	private:
		static Localization* singleton;
		std::string locale;		
	public:
		void init();
		void init(std::string locale);
		static Localization* get();
	
		std::string getText(std::string idText)const;
		std::string getTextForLocale(std::string idText,std::string locale)const;
		
		bool setLocale(std::string locale);
		std::string getLocale()const;
		int getIndexLocale()const;
		std::string getSystemLocale()const;
		
		void changeOnNextLocale();
		void changeOnSystemLocale();
		
		std::vector<std::string> getAllLocales()const;
		
		
		static std::string text(std::string idText) { 
			return get()->getText(idText); 
		}
		static std::string textForLocale(std::string idText,std::string locale)  { 
			return get()->getTextForLocale(idText,locale); 
		}
	};
};
#endif
