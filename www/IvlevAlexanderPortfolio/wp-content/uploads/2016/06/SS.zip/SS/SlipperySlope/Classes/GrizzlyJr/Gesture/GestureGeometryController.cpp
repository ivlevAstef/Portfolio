//
//  GestureGeometryController.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 05.09.13.
//
//

#include "GestureGeometryController.h"

using namespace GrizzlyJr;
USING_NS_CC;

GestureGeometryController* GestureGeometryController::singleton = nullptr;

GestureGeometryController* GestureGeometryController::get() {
	if( nullptr == singleton) {
		singleton = new GestureGeometryController();
	}
	return singleton;
}

GestureGeometryController::GestureGeometryController() {
	is_auto_record = true;
	is_record = false;
	CCDirector::sharedDirector()->getTouchDispatcher()->addStandardDelegate(this, 0);
}
	
bool GestureGeometryController::addListener(GestureGeometryListener* listener) {
	for(auto iter: this->listeners ) {
		if( listener == iter) {
			return false;
		}
	}
	
	listeners.push_back(listener);
	return true;
}
bool GestureGeometryController::removeListener(GestureGeometryListener* listener) {
	auto iter = std::remove_if(listeners.begin(), listeners.end(), [&listener](decltype(listener) iter) -> bool {
		return iter == listener;
	});
	if( iter != listeners.end()) {
		return listeners.erase(iter),true;
	}
	
	return false;
}

void GestureGeometryController::executeListener(std::function<void (GestureGeometryListener* l)> function) {
	for(auto iter: this->listeners ) {
		function(iter);
	}
}

void GestureGeometryController::useAutoRecord(bool auto_record) {
	is_auto_record = auto_record;
}

bool GestureGeometryController::startRecord() {
	if( is_record) {
		return false;
	}
	is_record = true;
	executeListener([](GestureGeometryListener* l) { l->beginGestureRecord(); });
	return true;
}
bool GestureGeometryController::endRecord() {
	if( !is_record) {
		return false;
	}
	
	is_record = false;
	std::string name = getGestureName();
	if( !name.empty()) {
		executeListener([&name](GestureGeometryListener* l) { l->createGesture(name); });
	}
	
	executeListener([](GestureGeometryListener* l) { l->endGestureRecord(); });
	
	return true;
}

bool GestureGeometryController::saveGesture(std::string gesture_name) {
	return false;
}

bool GestureGeometryController::isGestureEqual(std::string gesture_name) {
	return false;
}
std::string GestureGeometryController::getGestureName() {
	return "";
}


////Gesture Recognition
bool GestureGeometryController::SimpleGeometry::is(const GestureInfo& gesture_info) {
	return false;
}
bool GestureGeometryController::ComponentGeometry::is(const GestureInfo& gesture_info) {
	return false;
}

////Touches
void GestureGeometryController::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	if( !is_record && !is_auto_record) {
		return;
	}
	
	
}
void GestureGeometryController::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	
}
void GestureGeometryController::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	
}
void GestureGeometryController::ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent) {
	
}