//
//  Engine.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 23.05.13.
//
//

#include "Engine.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include <GrizzlyJr/Graphic/Box2DCocos.h>
#include <math.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

Engine::Engine(std::string name) {
	this->name = name;
	z_order = -1;
	body = 0x0;
	
	ScaleCCSprite* image = ScaleCCSprite::createFN(name+".png");
	CCSize size = image->getContentSize();
	
	this->addChild(image,-1);
	this->setContentSize(size);
	
	loadMountingFromFile();
	torque = getParameter("torque");
	accelerate = getParameter("accelerate");
	max_speed = getParameter("max_speed");
	
	float gas1 = getParameter("gas1");
	float gas2 = getParameter("gas2");
	degree = getParameter("degree");
	
	float log1 = log(1)/log(degree);
	float log2 = log(max_speed)/log(degree);
	b = (gas1-gas2)/(log2-log1);
	a = gas1+log1*b;
}

AutoElement* Engine::createPhysicCopy(b2World* world,cocos2d::CCPoint translate,float scale) {
	Engine* copy = (Engine*)createCopy(translate,scale);
	copy->loadBodyFromFile(world);
	
	return copy;
}

AutoElement* Engine::createCopy(cocos2d::CCPoint translate,float scale) {
	Engine* copy = new Engine(name);
	copy->setPosition(ccpAdd(translate,ccpMult(this->getPosition(),scale)));
	copy->setScaleX(this->getScaleX()*scale);
	copy->setScaleY(scale);
	copy->setRotation(this->getRotation());
	copy->type = this->type;
	copy->autorelease();
	
	return copy;
}



void Engine::visit3dView(float auto_angle) {
}

void Engine::setScaleX(float scale) {
	AutoElement::setScaleX(scale);
	float mult = MIN(fabs(getScaleX()),fabs(getScaleY()));
	torque *= mult*mult;
}
void Engine::setScaleY(float scale) {
	AutoElement::setScaleY(scale);
	float mult = MIN(fabs(getScaleX()),fabs(getScaleY()));
	torque *= mult*mult;
}
void Engine::setScale(float scale) {
	AutoElement::setScale(scale);
	torque *= scale*scale;
}

