#ifndef _GRIZZLY_JR_SCENE_INFORMATION_H_
#define _GRIZZLY_JR_SCENE_INFORMATION_H_

#include "LoadingData.h"
#include "layers_scenes_transitions_nodes/CCScene.h"
#include <vector>

namespace GrizzlyJr
{
	struct SceneInformation
	{
		std::vector<LoadingData> resources;
		cocos2d::CCScene* (*createScene)(void* p);
		cocos2d::CCScene* (*createSceneWithTextures)(void* p,std::vector<cocos2d::CCTexture2D*> textures);
		
		std::vector<cocos2d::CCTexture2D*> (*createTexture)(void* p);
		std::vector<LoadingData> resources_use_only_texture;
		
		void* p;
			
		SceneInformation():createScene(0x0),createSceneWithTextures(0x0),p(0x0),createTexture(0x0) { 
			resources.clear(); 
			resources_use_only_texture.clear();
		}
	};
};

#endif
