#include "AnimatedSprite.h"
#include "MultiAnimate.h"
#include "RemoveAction.h"
#include "../FileImageOnMemory/FIOMNode.h"
#include <iostream>
#include <fstream>

#define MAX_COUNT_CHANGE 10000

using namespace GrizzlyJr;
using namespace cocos2d;
using namespace std;

const unsigned int AnimatedSprite::animatedSpriteTag = 200;

AnimatedSprite* AnimatedSprite::node(string mapName)
{
	AnimatedSprite* pRet = new AnimatedSprite(mapName);
	pRet->autorelease();
	return pRet;
}

AnimatedSprite* AnimatedSprite::node(std::string mapName, std::string* postfix, unsigned int count)
{
	AnimatedSprite* pRet = new AnimatedSprite(mapName,postfix,count);
	pRet->autorelease();
	return pRet;
}

AnimatedSprite* AnimatedSprite::node(std::string mapName, std::vector<std::string> postfixs)
{
	AnimatedSprite* pRet = new AnimatedSprite(mapName,postfixs);
	pRet->autorelease();
	return pRet;
}

struct MapInformation {
	cocos2d::CCAnimate* anim;
	std::string sound;
};
struct VectorInformation {
	float change;
	std::string name;
};
std::map<std::string, MapInformation> info;
std::vector<VectorInformation> probability;


AnimatedSprite::AnimatedSprite()
{
	bIsFlipX = false;
	bIsFlipY = false;
	color = ccc3(255, 255, 255);
	opacity = 255;
}

AnimatedSprite::AnimatedSprite(std::string mapName)
{
	std::string postfix[1] = {""};
	init(mapName,postfix,1);
}

AnimatedSprite::AnimatedSprite(std::string mapName, std::string* postfix, unsigned int count)
{
	init(mapName,postfix,count);
}

AnimatedSprite::AnimatedSprite(std::string mapName, std::vector<std::string> postfixs)
{
	init(mapName,&(postfixs[0]),postfixs.size());
}

std::string AnimatedSprite::getFullNameSprite(std::string name,std::string postfix)
{
	std::string beginName = name;
	if( postfix.length() > 0) {
		postfix = "-"+postfix;
	}
	std::string::size_type pos = name.find('.');
	std::string type = "";
	if( pos == name.npos) {
		type = "png";
	} else {
		type = name.substr(pos+1);
		name = name.substr(0,pos);
	}

	std::string base = name;

	name = base+postfixAllName+postfix+"."+type;
	CCSpriteFrame *pFrame = 0x0;
	if( base.size() > 5) {
		pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name.c_str());
		if( 0x0 == pFrame) {
			std::string number = base.substr(base.size()-5);
			std::string baseN = base.substr(0,base.size()-5);
			
			name = baseN+postfixAllName+postfix+number+"."+type;
		} else {
			return name;
		}

		pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name.c_str());
		if( 0x0 == pFrame) {
			std::string number = base.substr(base.size()-5);
			std::string baseN = base.substr(0,base.size()-5);	
			name = baseN+postfixAllName+number+postfix+"."+type;
		} else {
			return name;
		}
		
		pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name.c_str());
		if( 0x0 == pFrame) {
			std::string number = base.substr(base.size()-5);
			std::string baseN = base.substr(0,base.size()-5);
			name = baseN+postfixAllName+postfix+"."+type;
		} else {
			return name;
		}
	}
	pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name.c_str());
	if( 0x0 == pFrame) {
		return beginName;
	}
	
	return name;
}

void AnimatedSprite::init(std::string mapName,std::string* postfix, unsigned int countNames)
{
	if( mapName.empty()) {
		return;
	}
	bIsFlipX = false;
	bIsFlipY = false;
	color = ccc3(255, 255, 255);
	opacity = 255;
		
	for( unsigned int k = 0; k < countNames; k++) {
		postfixSave[postfix[k]] = k;
	}	
	this->countNames = countNames;
	
	string defaultName;
	
	string mapFullName = "animationMap/"+mapName;
	if( !FIOMMain::get()->isLoad(mapFullName)) {
		FIOMMain::get()->loadFile(mapFullName);
	}
	mapName = FIOMMain::get()->getNameFromPath(mapFullName);
	
	FIOMNode node = FIOMNode::get(mapName.c_str());
	///DEFAULT
	{
		std::string nameBegin = node.getStr("default");
		
		CCSize size;
		for( unsigned int k = 0; k < countNames; k++) {
			std::string name = getFullNameSprite(nameBegin,postfix[k]);
			ScaleCCSprite* sprite = ScaleCCSprite::createWithSpriteFrameName(name.c_str());
			
			sprites.push_back(sprite);
			this->addChild(sprite);
			
			size = sprite->getContentSize();
			sprite->setPosition(ccp(0, 0));
			this->setContentSize(size);
		}
	}
	
	///INFORMATION
	{
		CCSpriteFrameCache* cache = CCSpriteFrameCache::sharedSpriteFrameCache();
		FIOMNode nodeAnims = node["information"];
		
		
		std::vector<std::string> anims =  nodeAnims.getCatalogNames();
		for( unsigned int i =0; i < anims.size(); i++) {
			FIOMNode nodeAnim = nodeAnims[anims[i]];
			MapInformation mapInfo;
			float frameDelay = nodeAnim.getFloat("frame-delay");
			
			mapInfo.anim = new CCAnimation[countNames]();
			mapInfo.sound = nodeAnim.getStr("sound");
			mapInfo.soundLength = nodeAnim.getFloat("sound-length");
			
			for( unsigned int k = 0; k < countNames; k++) {
				mapInfo.anim[k].init();
				mapInfo.anim[k].setDelayPerUnit(frameDelay);
			}
		
			FIOMNode nodeFrames = nodeAnim["frames"];
			size_t count = nodeFrames.getArraySize();
			for( unsigned int f =0; f < count; f++) {
				for( unsigned int k = 0; k < countNames; k++) {
					int count =  nodeFrames[f].getInt("count");
					std::string nameF = nodeFrames[f].getStr("name");
					for( int r = 0; r < count; r++) {
						std::string name = getFullNameSprite(nameF,postfix[k]);
						mapInfo.anim[k].addSpriteFrame(cache->spriteFrameByName(name.c_str()));
					}
				}
			}
			
			info[anims[i]] = mapInfo;
		}
	}
	
	///PROBABILITY
	{
		fullChange = 0;
		FIOMNode nodeP = node["probability"];
		std::vector<std::string> prob = nodeP.getValueNames();
		for( unsigned int i =0; i < prob.size(); i++) {
			VectorInformation vInfo;
			vInfo.name = prob[i];
			vInfo.change = nodeP.getFloat(vInfo.name);
			probability.push_back(vInfo);
			fullChange += vInfo.change;
		}
	}
}


AnimatedSprite::~AnimatedSprite() {
	this->stopAllActions();
	removeAllChildrenWithCleanup(true);
	std::map<std::string, MapInformation>::iterator iter = info.begin();
	for( ; iter != info.end(); iter++) 
	{
		cocos2d::CCAnimation* anim = iter->second.anim;
		if( 0x0 != anim) {
			delete[] anim;
		}
	}
	info.clear();
}

void AnimatedSprite::setBeginSprite(std::string name) {
	if( info.end() == info.find(name) ) {
		return;
	}
	
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return;
	}
	
	for( unsigned int i =0; i < sprites.size(); i++)
	{
		CCArray* pFrames = anim[i].getFrames();
		unsigned int numberOfFrames = pFrames->count();
		if( 0 == numberOfFrames) {
			continue;
		}

		unsigned int idx = 0;
		ScaleCCSprite *pSprite = sprites[i];

		CCAnimationFrame* aframe = (CCAnimationFrame*)pFrames->objectAtIndex(idx);
		CCSpriteFrame* frame = aframe->getSpriteFrame();	
		if (! pSprite->isFrameDisplayed(frame)) {
			pSprite->setDisplayFrame(frame);
		}
	}
}

CCActionInterval* AnimatedSprite::getAnimate(string name)
{
	if( info.end() == info.find(name) ) {
		return 0x0;
	}
	
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* manim = MultiAnimate::actionWithAnimation(anim, countNames);
	manim->setSound(info[name].sound, info[name].soundLength);
	
	return manim;
}

CCActionInterval* AnimatedSprite::run(string name)
{
	if( info.end() == info.find(name) ) {
		return 0x0;
	}
	
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* res = MultiAnimate::actionWithAnimation(anim, countNames);
	res->setSound(info[name].sound, info[name].soundLength);
	CCCallFunc* call = CCCallFunc::create(this, callfunc_selector(AnimatedSprite::runProbabilityNotResult));
	CCSequence* seq = CCSequence::createWithTwoActions(res, call);
	seq->setTag(animatedSpriteTag);
	
	this->stopActionByTag(animatedSpriteTag);
	this->runAction(seq);
	setBeginSprite(name);
	
	return res;
}

cocos2d::CCActionInterval* AnimatedSprite::runForever(std::string name)
{
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* res = MultiAnimate::actionWithAnimation(anim, countNames);
	res->setSound(info[name].sound, info[name].soundLength);
	
	CCRepeat* rep = CCRepeat::create(res, 99999999);
	rep->setTag(animatedSpriteTag);
	
	this->stopActionByTag(animatedSpriteTag);
	this->runAction(rep);
	setBeginSprite(name);
	
	return res;
}

cocos2d::CCActionInterval* AnimatedSprite::runRemove(std::string name)
{
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* res = MultiAnimate::actionWithAnimation(anim, countNames);
	res->setSound(info[name].sound, info[name].soundLength);
	
	RemoveAction* remove = RemoveAction::create();
	CCSequence* seq = CCSequence::createWithTwoActions(res, remove);
	seq->setTag(animatedSpriteTag);
	
	this->stopActionByTag(animatedSpriteTag);
	this->runAction(seq);
	setBeginSprite(name);
		
	return res;
}

CCActionInterval* AnimatedSprite::runStop(string name)
{
	if( info.end() == info.find(name) ) {
		return 0x0;
	}
	
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* res = MultiAnimate::actionWithAnimation(anim, countNames);    
	res->setSound(info[name].sound, info[name].soundLength);
	res->setTag(animatedSpriteTag);
	
	this->stopActionByTag(animatedSpriteTag);
	this->runAction(res);
	setBeginSprite(name);
	
	return res;
}

CCActionInterval* AnimatedSprite::runCall(string name, CCObject* pSelectorTarget, SEL_CallFunc selector)
{
	if( info.end() == info.find(name) ) {
		return 0x0;
	}
	
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* res = MultiAnimate::actionWithAnimation(anim, countNames);
	res->setSound(info[name].sound, info[name].soundLength);
	
	CCCallFunc* call = CCCallFunc::create(this, callfunc_selector(AnimatedSprite::runProbabilityNotResult));
	CCCallFunc* call2 = CCCallFunc::create(pSelectorTarget, selector);
	CCSpawn* spawn = CCSpawn::createWithTwoActions(call,call2);
	
	CCSequence* seq = CCSequence::createWithTwoActions(res, spawn);
	seq->setTag(animatedSpriteTag);
	
	this->stopActionByTag(animatedSpriteTag);
	this->runAction(seq);
	setBeginSprite(name);
	
	return res;
}

CCActionInterval* AnimatedSprite::runCallStop(string name, CCObject* pSelectorTarget, SEL_CallFunc selector)
{
	if( info.end() == info.find(name) ) {
		return 0x0;
	}
	
	CCAnimation* anim = info[name].anim;
	if( 0x0 == anim) {
		return 0x0;
	}
	
	MultiAnimate* res = MultiAnimate::actionWithAnimation(anim, countNames);
	res->setSound(info[name].sound, info[name].soundLength);
	CCCallFunc* call = CCCallFunc::create(pSelectorTarget, selector);
	CCSequence* seq = CCSequence::createWithTwoActions(res, call);
	seq->setTag(animatedSpriteTag);
	
	this->stopActionByTag(animatedSpriteTag);
	this->runAction(seq);
	setBeginSprite(name);
	
	return res;
}

CCActionInterval* AnimatedSprite::runProbability()
{
	if( 0 == probability.size()) {
		return 0x0;
	}
	
	int index = (rand()%MAX_COUNT_CHANGE);
	float mult = MAX_COUNT_CHANGE/fullChange;
	float pr = 0;
	
	for( unsigned int i =0; i < probability.size(); i++) {
		pr += probability[i].change*mult;
		if( pr >= index) {
			return this->run(probability[i].name);
		}
	}
	
	return this->run(probability[probability.size()-1].name);
}

void AnimatedSprite::setFlipX(bool bFlipX)
{
	if (bIsFlipX != bFlipX)
	{
		bIsFlipX = bFlipX;
		for( unsigned int i =0; i < sprites.size(); i++) {
			sprites[i]->setFlipX(bFlipX);
		}
	}
}
void AnimatedSprite::setFlipY(bool bFlipY)
{
	if (bIsFlipY != bFlipY)
	{
		bIsFlipY = bFlipY;
		for( unsigned int i =0; i < sprites.size(); i++) {
			sprites[i]->setFlipX(bFlipY);
		}
	}
}

bool AnimatedSprite::isFlipX()
{
	return bIsFlipX;
}
bool AnimatedSprite::isFlipY()
{
	return bIsFlipY;
}

bool AnimatedSprite::isFindPostfix(std::string postfix)
{
	if( postfixSave.find(postfix) == postfixSave.end() ) {
		return false;
	}
	return true;
}

int AnimatedSprite::getPostfixIndex(std::string postfix) 
{
	if( postfixSave.find(postfix) == postfixSave.end() ) {
		return 0;
	}
	return postfixSave[postfix];
}

void AnimatedSprite::replacePostfix(std::string lastPost, std::string newPost)
{
	std::map<std::string,int>::iterator iter = postfixSave.find(lastPost);
	if( iter == postfixSave.end() ) {
		return;
	}
	postfixSave[newPost] = postfixSave[lastPost];
	postfixSave.erase(iter);
}

void AnimatedSprite::setShaderProgram(cocos2d::CCGLProgram* var)
{
	for( size_t i =0; i < sprites.size(); i++) {
		sprites[i]->setShaderProgram(var);
	}
}

void AnimatedSprite::setBlendFunc(cocos2d::ccBlendFunc func) {
	for( size_t i =0; i < sprites.size(); i++) {
		sprites[i]->setBlendFunc(func);
	}
}

void AnimatedSprite::setColor(const cocos2d::ccColor3B& color, unsigned int number) {
	if( number >= sprites.size() ) {
		return;
	}
	
	sprites[number]->setColor(color);
}
void AnimatedSprite::setOpacity(GLubyte opacity, unsigned int number) {
	if( number >= sprites.size() ) {
		return;
	}
	
	sprites[number]->setOpacity(opacity);
}


const cocos2d::ccColor3B& AnimatedSprite::getColor(unsigned int number) {
	if( number >= sprites.size() ) {
		CCAssert(number < sprites.size(), "AnimatedSprite::getColor-> number sprite incorrect");
	}
	
	return sprites[number]->getColor();
}

void AnimatedSprite::setOpacity(GLubyte opacity, std::string postfix){
	setOpacity(opacity, postfixSave[postfix]);
}
void AnimatedSprite::setColor(const cocos2d::ccColor3B& color, std::string postfix) {
	std::map<std::string,int>::iterator find = postfixSave.find(postfix);
	if( postfixSave.end() != find ) {
		setColor(color, find->second);
	}
}
const cocos2d::ccColor3B& AnimatedSprite::getColor(std::string postfix) {
	return getColor(postfixSave[postfix]);
}

void AnimatedSprite::setColor(const cocos2d::ccColor3B& color)
{
	this->color = color;
	for( unsigned int i =0; i < sprites.size();i++) {
		sprites[i]->setColor(color);
	}
}
const cocos2d::ccColor3B& AnimatedSprite::getColor()
{
	return color;
}
GLubyte AnimatedSprite::getOpacity()
{
	return opacity;
}
void AnimatedSprite::setOpacity(GLubyte opacity)
{
	this->opacity = opacity;
	for( unsigned int i =0; i < sprites.size();i++) {
		sprites[i]->setOpacity(opacity);
	}
}

void AnimatedSprite::setSizeOnTexture(cocos2d::CCPoint addOrigin,cocos2d::CCSize size, bool scalex2ifNeed)
{
	for( unsigned int i =0; i < sprites.size();i++) {
		CCRect rect = sprites[i]->getBeginTextureRect();
		rect.origin.x += addOrigin.x;
		rect.origin.y += addOrigin.y;
		CCSize localSize = size;
		if( scalex2ifNeed) {
			localSize.width /= sprites[i]->getScaleFactorX();
			localSize.height /= sprites[i]->getScaleFactorY();
		}
		
		/*if( sprites[i]->isTextureRectRotated()) {
			realSize.width = rect.size.height;
			realSize.height = rect.size.width;
		}*/
		
		if( localSize.width > 0 && localSize.width < rect.size.width) {
			rect.size.width = localSize.width;
		}
		if( localSize.height > 0 && localSize.height < rect.size.height) {
			rect.size.height = localSize.height;
		}
		
		sprites[i]->setTextureRectForScale(rect);
	}
}

void AnimatedSprite::runProbabilityNotResult()
{
	runProbability();
}