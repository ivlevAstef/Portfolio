//
//  GameScene.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.06.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_GAME_SCENE_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_GAME_SCENE_H_

#include "cocos2d.h"
#include <GrizzlyJr/SceneController/SceneInformation.h>
#include <GrizzlyJr/Gesture/GestureListener.h>
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>
#include "Auto.h"
#include "PhysicAuto.h"
#include "Elements/Box.h"
#include "Replay.h"
#include "ProgressMap.h"

namespace GrizzlyJr {
	namespace SlipperSlope {
		
		class GameScene: public cocos2d::CCLayer {
		private:
			struct ObjectOnMap {
				ScaleCCSprite* sprite;
				float speed;
				int z_order;
				void addSprite(std::string name) { sprite = ScaleCCSprite::createFN(name); sprite->retain(); }
				void remove() { if( sprite) { sprite->release();  sprite = 0x0;} }
			};
			struct CameraEffects {
			private:
				cocos2d::CCPoint need;
				cocos2d::CCPoint current;
				PhysicAuto* self_auto;
				cocos2d::CCPoint auto_translate;
				float last_translate_len;
			public:
				void setAuto(PhysicAuto* self_auto,cocos2d::CCPoint translate);
				void calc(float dt);
				const cocos2d::CCPoint& get()const;
			} camera_effect;
			
			std::vector<ObjectOnMap> objects;
			std::vector<Box*> physics;
			cocos2d::CCPoint physic_translate;
			
			cocos2d::CCPoint line_size;
			
			PhysicAuto* self_auto;
			PhysicAuto* enemy_auto;
			Auto* image_auto;
			b2World* world;

			b2Vec2 gravity;
			
			std::vector<b2Vec2> positions;
			
			cocos2d::CCTexture2D* texture_for_back;
			
			cocos2d::CCTexture2D* texture_for_way;
			cocos2d::CCTexture2D* texture_for_top;
			cocos2d::CCTexture2D* texture_for_snow;
			cocos2d::CCTexture2D* texture_for_shadow;
			
			ScaleCCSprite* rotate_right;
			ScaleCCSprite* rotate_left;
			
			ScaleCCSprite* run_right;
			ScaleCCSprite* run_left;
			
			std::vector<cocos2d::CCPoint> touch_positions;
			
			bool is_pause;
			float time_click_run;
			
			Replay record_game;
			Replay play_game;
			
			ProgressMap* progress_map;
			
			cocos2d::CCNode* slip_effects;
		public:
			GameScene():world(0x0),self_auto(0x0) {}
			virtual ~GameScene();
			static cocos2d::CCScene* scene(void* p);///Auto*
			
			static SceneInformation getSceneInformation();
			bool init(Auto* self_auto);
			
			virtual void update(float dt);
						
			virtual void draw();
			virtual void visit();
			
			void clickRedactor(cocos2d::CCObject* obj);
			
		private:
			virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
			virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
			virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
			virtual void ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
			
			void loadMap(std::string map_name);
			
			void drawBackFrontTexture(std::vector<std::pair<cocos2d::CCPoint*, cocos2d::CCPoint*> >& points,unsigned int number, float mult);
			void calcPoints(std::vector<std::pair<cocos2d::CCPoint*, cocos2d::CCPoint*> >& points);
			void drawBack(float speed);
			void visibleObjects(int z_begin, int z_end);
			void visiblePhysics();
			void visibleShadow(PhysicAuto* a,std::vector<std::pair<cocos2d::CCPoint*, cocos2d::CCPoint*> >& points, cocos2d::CCPoint translate);
			
			void visitSlipEffects();
			
			void stepWorld(float dt);
			
			void addSlipEffects(PhysicAuto* a,float dt,float speed_add);
		};
	};
};

#endif
