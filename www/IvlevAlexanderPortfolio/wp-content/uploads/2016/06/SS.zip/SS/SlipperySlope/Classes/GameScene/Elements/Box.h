//
//  Box.h
//  SlipperySlope
//
//  Created by Alexander Ivlev on 14.08.13.
//
//

#ifndef _GRIZZLY_JR_SLIPPERY_SLOPE_BOX_H_
#define _GRIZZLY_JR_SLIPPERY_SLOPE_BOX_H_

#include "cocos2d.h"
#include "Box2D.h"
#include "3DElement.h"
#include "PhysicElement.h"
#include <GrizzlyJr/Graphic/ScaleCCSprite.h>

namespace GrizzlyJr {
	namespace SlipperSlope {
		class Box: public _3DElement, public PhysicElement {
		private:
			ScaleCCSprite* back;
			
		protected:
			std::string name;
			size_t self_id;
			Box();
		public:
			static Box* create(std::string name);
			bool init(std::string name);
			
			void physicInit(b2World* world);
			
			std::string getName()const { return name; }
			void setFlipX(bool flipX);
			void setFlipY(bool flipY);
			
			void updateImage() { updateNode(this); }
			
			virtual void visit3dView(float glob_angle);
			
			virtual ~Box();
		};
				
	};
};

#endif