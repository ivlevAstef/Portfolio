//
//  HelpElementInterface.cpp
//  SlipperSlope
//
//  Created by Alexander Ivlev on 04.10.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "HelpElementInterface.h"
//#include "HelpController.h"

using namespace GrizzlyJr;

void HelpElementInterface::setOnControllerUseId(std::string thisId) {
	/*if( "" == thisId && "" == this->thisId) {
		return;
	}
	
	if( "" == thisId) {
		SlipperSlope::HelpController::get()->removeElement(this->thisId,0x0);
		this->thisId = thisId;
		return;
	}
	
	if( "" != this->thisId) {
		SlipperSlope::HelpController::get()->changeId(this->thisId, thisId);
		this->thisId = thisId;
		return;
	}
	
	this->thisId = thisId;
	SlipperSlope::HelpController::get()->addElement(thisId, this);*/
}

void HelpElementInterface::clickOnSelf() {
	//SlipperSlope::HelpController::get()->clickOnElement(this);
}

HelpElementInterface::~HelpElementInterface() {
	//SlipperSlope::HelpController::get()->removeElement(thisId,this);
}