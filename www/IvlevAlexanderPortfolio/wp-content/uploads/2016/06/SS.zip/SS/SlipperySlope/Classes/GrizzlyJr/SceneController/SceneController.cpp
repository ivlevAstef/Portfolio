#include "SceneController.h"
#include "cocos2d.h"
#include "../Log/LogFunction.h"
#include <algorithm>

using namespace GrizzlyJr;
using namespace cocos2d;

#define USE_CATALOG_NAME_FOR_NAME
#define USE_PATH_PREFIX 

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	#define NAME_BEGIN_DIRECTORIES ""
#else
	#define NAME_BEGIN_DIRECTORIES "frames"
#endif

SceneController::TextureInformationMap SceneController::textureInformation;

std::vector<std::string> SceneController::postfixsPriority;
std::string SceneController::prefix = "";
SceneController* SceneController::singleton = 0x0;
cocos2d::CCScene* SceneController::saveScene = 0x0;


void LoadDynamicSceneInterface::initDynamicScene(SceneInformation info) {
	this->info = info;
	index = 0;
	currentSize = 0;
	
	sizeOnCreateTexture = 0;
	if( 0x0 != info.createTexture) {
		for( size_t i =0; i < info.resources_use_only_texture.size();i++) {
			sizeOnCreateTexture += info.resources_use_only_texture[i].size;
		}
	}
		
	fullSize = 2*sizeOnCreateTexture;
	for( size_t i =0; i < info.resources.size();i++) {
		fullSize += info.resources[i].size;
	}
	
	privateScene.resources = info.resources;
}
	
bool LoadDynamicSceneInterface::loadNextResource() {
	size_t sizeTexture = info.resources_use_only_texture.size();
	
	if( sizeTexture > index && 0x0 != info.createTexture) {
		SceneController::get()->loadDataIsNeeded(info.resources_use_only_texture[index]);
		currentSize += info.resources_use_only_texture[index].size;
		
		index++;
		return false;
	}
	
	if( sizeTexture == index && 0x0 != info.createTexture && index > 0) {
		privateScene.texture_resources = info.createTexture(info.p);
		currentSize += sizeOnCreateTexture;
		
		index++;
		
		for( size_t i = 0; i < sizeTexture; i++) {
			SceneController::get()->unloadDataIsNeeded(info.resources_use_only_texture[i]);
		}
		return false;
	}
	
	size_t index2 = index;
	if( sizeTexture > 0 && 0x0 != info.createTexture) {
		index2 -= sizeTexture+1;
	}
	
	if( info.resources.size() > index2) {
		SceneController::get()->loadDataIsNeeded(info.resources[index2]);
		index++;
		return false;
	}
	return true;
}
float LoadDynamicSceneInterface::getProgress() {
	return currentSize/fullSize;
}

void LoadDynamicSceneInterface::endDynamicScene() {
	SceneController::get()->replace(info, privateScene);
}

SceneController::SceneController()
{
	alldata.clear();
}

SceneController::PrivateSceneInformation SceneController::loadResourceForScene(SceneInformation scene) {
	PrivateSceneInformation privateScene;
	privateScene.resources = scene.resources;
	
	if( scene.resources_use_only_texture.size() > 0 && 0x0 != scene.createTexture) {
		for( size_t i = 0; i < scene.resources_use_only_texture.size(); i++) {
			loadDataIsNeeded(scene.resources_use_only_texture[i]);
		}
		
		privateScene.texture_resources = scene.createTexture(scene.p);
		
		for( size_t i = 0; i < scene.resources_use_only_texture.size(); i++) {
			unloadDataIsNeeded(scene.resources_use_only_texture[i]);
		}
	}
		
	for( size_t i = 0; i < privateScene.resources.size(); i++) {
		loadDataIsNeeded(privateScene.resources[i]);
	}
	
	return privateScene;
}
			
void SceneController::push(SceneInformation newScene)
{	
	PrivateSceneInformation privateScene = loadResourceForScene(newScene);
	
	CCScene* scene = 0x0;
	if( 0x0 != newScene.createSceneWithTextures) {
		scene = newScene.createSceneWithTextures(newScene.p,privateScene.texture_resources);
	} else {
		scene = newScene.createScene(newScene.p);
	}
	
	if( 0x0 == CCDirector::sharedDirector()->getRunningScene()) {
		CCDirector::sharedDirector()->runWithScene(scene);		
	} else {
		CCDirector::sharedDirector()->getRunningScene()->pauseSchedulerAndActions();
		CCDirector::sharedDirector()->pushScene(scene);
	}
	saveScene = scene;
	
	scenes.push_back(privateScene);
	sceneInfoForReload.push_back(newScene);
}

bool SceneController::pop()
{
	if( 0 == scenes.size()) {
		return false;
	}
	cleanLastSceneResource();
	scenes.pop_back();
	sceneInfoForReload.pop_back();
	
	CCDirector::sharedDirector()->popScene();
	CCDirector::sharedDirector()->drawScene();
	CCDirector::sharedDirector()->getRunningScene()->resumeSchedulerAndActions();
	saveScene = CCDirector::sharedDirector()->getRunningScene();
	return true;
}

void SceneController::replace(SceneInformation newScene) {
	if( 0 != scenes.size()) {
		newScene.resources = cleanLastSceneResourceWithUseNew(newScene.resources);
		scenes.pop_back();
		sceneInfoForReload.pop_back();
	}
	
	PrivateSceneInformation privateScene = loadResourceForScene(newScene);
	
	CCScene* scene = 0x0;
	if( 0x0 != newScene.createSceneWithTextures) {
		scene = newScene.createSceneWithTextures(newScene.p,privateScene.texture_resources);
	}else {
		scene = newScene.createScene(newScene.p);
	}
	
	if( CCDirector::sharedDirector()->getRunningScene()) {
		CCDirector::sharedDirector()->replaceScene(scene);
	} else {
		CCDirector::sharedDirector()->runWithScene(scene);
	}
	saveScene = scene;
	
	scenes.push_back(privateScene);
	sceneInfoForReload.push_back(newScene);
}

void SceneController::replace(SceneInformation newScene,PrivateSceneInformation privateScene) {
	if( 0 != scenes.size()) {
		cleanLastSceneResource();
		scenes.pop_back();
		sceneInfoForReload.pop_back();
	}
	
	CCScene* scene = 0x0;
	if( 0x0 != newScene.createSceneWithTextures) {
		scene = newScene.createSceneWithTextures(newScene.p,privateScene.texture_resources);
	}else {
		scene = newScene.createScene(newScene.p);
	}
	
	if( CCDirector::sharedDirector()->getRunningScene()) {
		CCDirector::sharedDirector()->replaceScene(scene);
	} else {
		CCDirector::sharedDirector()->runWithScene(scene);
	}
	saveScene = scene;
	
	scenes.push_back(privateScene);
	sceneInfoForReload.push_back(newScene);
}

void SceneController::replace(SceneInformation newScene, SceneInformation loadScene) {
	if( 0 != scenes.size()) {
		cleanLastSceneResource();
		scenes.pop_back();
		sceneInfoForReload.pop_back();
	}

	PrivateSceneInformation privateScene = loadResourceForScene(loadScene);
	
	CCScene* scene = 0x0;
	if( 0x0 != loadScene.createSceneWithTextures) {
		scene = loadScene.createSceneWithTextures(&newScene,privateScene.texture_resources);
	}else {
		scene = loadScene.createScene(&newScene);
	}
	
	if( CCDirector::sharedDirector()->getRunningScene()) {
		CCDirector::sharedDirector()->replaceScene(scene);
	} else {
		CCDirector::sharedDirector()->runWithScene(scene);
	}
	
	saveScene = scene;
	scenes.push_back(privateScene);
	sceneInfoForReload.push_back(newScene);
}

void SceneController::restart(cocos2d::CCScene* scene) {
	saveScene = 0x0;
	if( 0 == scenes.size()) {
		CCDirector::sharedDirector()->runWithScene(scene);
		return;
	}
	
	while (scenes.size() > 1) {
		cleanLastSceneResource();
		scenes.pop_back();
		sceneInfoForReload.pop_back();
		CCDirector::sharedDirector()->popScene();
	}
	cleanLastSceneResource();
	scenes.pop_back();
	sceneInfoForReload.pop_back();
	
	CCDirector::sharedDirector()->replaceScene(scene);
}

void SceneController::cleanLastSceneResource()
{
	if( 0 == scenes.size()) {
		return;
	}
	
	PrivateSceneInformation& info = scenes[scenes.size()-1];
	for( size_t i = 0; i < info.resources.size(); i++) {
		unloadDataIsNeeded(info.resources[i]);
	}
	
	for( size_t i = 0; i < info.texture_resources.size(); i++) {
		info.texture_resources[i]->release();
	}
}

std::vector<LoadingData> SceneController::cleanLastSceneResourceWithUseNew(std::vector<LoadingData>& newResources) 
{
	std::vector<LoadingData> result;
	if( 0 == scenes.size()) {
		return result;
	}
	
	result = newResources;
	
	PrivateSceneInformation& info = scenes[scenes.size()-1];
	for( unsigned int i = 0; i < info.resources.size(); i++)
	{
		unsigned int index = 0;
		bool isFind = false;
		for( unsigned int j = 0; j < result.size(); j++)
		{
			if( info.resources[i].name == result[j].name) {
				isFind = true;
				index = j;
				break;
			}
		}
		
		if( !isFind) {
			unloadDataIsNeeded(info.resources[i]);
		}else {
			result.erase(result.begin()+index);
		}
	}
	for( size_t i = 0; i < info.texture_resources.size(); i++) {
		info.texture_resources[i]->release();
	}
	
	return result;
}

void SceneController::loadDataIsNeeded(std::string name) {
	loadDataIsNeeded(LoadingData(name));
}
void SceneController::unloadDataIsNeeded(std::string name) {
	unloadDataIsNeeded(LoadingData(name));
}

void SceneController::loadDataIsNeeded(const char* name) {
	loadDataIsNeeded(LoadingData(name));
}
void SceneController::unloadDataIsNeeded(const char* name) {
	unloadDataIsNeeded(LoadingData(name));
}

void SceneController::loadDataIsNeeded(LoadingData d) {
	if( 0 == d.name.length() ) {
		return;
	}
	
	if( alldata.end() == alldata.find(d) ){
		alldata[d].reference = 0;
	}
	
	if( 0 == alldata[d].reference) {
		alldata[d].texture = loadData(d.name,convertTextureFormat(d.format));
	}
	alldata[d].reference++;
}
void SceneController::unloadDataIsNeeded(LoadingData d) {
	if( 0 == d.name.length() || alldata.end() == alldata.find(d) || 0 == alldata[d].reference){
		return;
	}
	
	alldata[d].reference--;
	if( 0 == alldata[d].reference) {
		unloadData(alldata[d].texture);
		alldata[d].texture = 0x0;
		alldata.erase(alldata.find(d));
	}
}

///////////// STATIC FUNCTION
SceneController* SceneController::get()
{
	if( 0x0 == singleton) {
		singleton = new SceneController();
	}
	return singleton;
}

CCTexture2DPixelFormat SceneController::convertTextureFormat(LoadingData::Format texrureFormat) {
	switch (texrureFormat) {
		case LoadingData::PIXEL_RGBA8888:	return kCCTexture2DPixelFormat_RGBA8888;
		case LoadingData::PIXEL_RGBA4444:	return kCCTexture2DPixelFormat_RGBA4444;
		case LoadingData::PIXEL_RGB565:		return kCCTexture2DPixelFormat_RGB565;
		case LoadingData::PIXEL_RGBA5551:	return kCCTexture2DPixelFormat_RGB5A1;
		case LoadingData::PIXEL_A8:			return kCCTexture2DPixelFormat_A8;
		default: return kCCTexture2DPixelFormat_Default;
	}
}

static std::string greatePathUsePostfix(std::string prefix,std::string name, std::string postfix)
{
	std::string result;
	
#ifdef USE_CATALOG_NAME_FOR_NAME
	size_t posFound = name.rfind("/");
	if( posFound != std::string::npos) {
		std::string nameFile = name.substr(posFound+1,name.length());
		result = prefix+name+"/"+nameFile+"-"+postfix;
	} else {
		result = prefix+name+"/"+name+"-"+postfix;
	}
#else
	result = prefix+name+"-"+postfix;
#endif
	
#ifdef USE_PATH_PREFIX
	if( result.c_str()[0] == '/' || result.c_str()[0] == '\\') {
		result = postfix+result;
	} else {
		result = postfix+"/"+result;
	}
#endif
	
	while ( result.c_str()[0] == '/' || result.c_str()[0] == '\\') {
		result = result.substr(1);
	}
	
	std::string begin_directory = NAME_BEGIN_DIRECTORIES;
	if( begin_directory.empty()) {
		return result;
	}
	return begin_directory+"/"+result;
}

static CCTexture2D* loadTexture(std::string path_plist,std::string& texture_path) {
	FILE* file = fopen(CCFileUtils::sharedFileUtils()->fullPathFromRelativePath(path_plist.c_str()), "r");
	bool is_writeble = false;
	
	if( 0x0 == file) {
		is_writeble = true;
		std::replace( path_plist.begin(), path_plist.end(), '\\', '_');
		std::replace( path_plist.begin(), path_plist.end(), '/', '_');

		std::string wr_path = CCFileUtils::sharedFileUtils()->getWriteablePath()+path_plist;
		file = fopen(wr_path.c_str(), "r");
	}
	
	if( 0x0 == file) {
		return 0x0;
	}
	fclose(file);
	
	CCDictionary* dict = CCDictionary::createWithContentsOfFileThreadSafe(path_plist.c_str());
	texture_path = "";
	
	CCDictionary* metadataDict = (CCDictionary*)dict->objectForKey("metadata");
	if (metadataDict) {
		texture_path = metadataDict->valueForKey("textureFileName")->getCString();
		if( is_writeble) {
			texture_path = CCFileUtils::sharedFileUtils()->getWriteablePath()+texture_path;
		} else {
			texture_path = CCFileUtils::sharedFileUtils()->fullPathFromRelativeFile(texture_path.c_str(), path_plist.c_str());
		}
	}
	
	if (texture_path.empty()) {
		texture_path = path_plist;
		
		size_t start_pos = texture_path.find_last_of(".");
		texture_path = texture_path.erase(start_pos);
		texture_path = texture_path.append(".png");
	}
	
	CCTexture2D *pTexture = CCTextureCache::sharedTextureCache()->addImage(texture_path.c_str());
	
	if (pTexture) {
		CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithDictionary(dict, pTexture);
	}
	
	dict->release();
	
	return pTexture;
}

cocos2d::CCTexture2D* SceneController::loadData(std::string name,cocos2d::CCTexture2DPixelFormat format) {
	if( 0 != prefix.size()) { prefix += "-"; }
	
	for( unsigned int i =0; i < postfixsPriority.size(); i++) {
		std::string path = greatePathUsePostfix(prefix,name,postfixsPriority[i]);
		
		std::string pathPlist = path+".plist";
		
		std::string texture_path = "";
		CCTexture2D::setDefaultAlphaPixelFormat(format);
		CCTexture2D* texture = loadTexture(pathPlist, texture_path);
		CCTexture2D::setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_Default);
		if( 0x0 == texture)	 {
			continue;
		}
		
		textureInformation[texture].texture_path = texture_path;
		NormalLog("LOAD_RESOURCE =%s name=%d",path.c_str(),texture->getName());
			
		textureInformation[texture].postfix = postfixsPriority[i];
		textureInformation[texture].path = path;
		textureInformation[texture].format = format;
			
		return texture;
	}
	return 0x0;
}
void SceneController::unloadData(cocos2d::CCTexture2D* texture) {
	if( 0x0 == texture) {
		return;
	}

	TextureInformationMap::iterator find = textureInformation.find(texture);
	if( find != textureInformation.end()) {
		CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromTexture(texture);
	
		/*for( size_t i = 1; i < texture->retainCount(); i++) {
			texture->release();
		}*/
	
		CCTextureCache::sharedTextureCache()->removeTexture(texture);
		textureInformation.erase(find);
	}
}

std::string SceneController::getTexturePostfix(cocos2d::CCSprite* sprite)
{
	TextureInformationMap::iterator find = textureInformation.find(sprite->getTexture());
	if( find != textureInformation.end()) {
		return find->second.postfix;
	}

	return "";
}

void SceneController::remove() {
	CC_SAFE_DELETE(singleton); singleton = 0x0;
	CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFrames();
	CCTextureCache::sharedTextureCache()->removeAllTextures();
}

////////////UNLOAD DATA FOR BACKGROUND
class CCDynamicTexture2D : public CCTexture2D {
public:
	void removeData() {
		if(m_uName) {
			ccGLDeleteTexture(m_uName);
		}
	}
	void reloadData(std::string path) {
		path = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath(path.c_str());
		
		std::string fullpath = path;
		std::string lowerCase(path);
		
		for (unsigned int i = 0; i < lowerCase.length(); ++i) {
			lowerCase[i] = tolower(lowerCase[i]);
		}
		
		// all images are handled by UIImage except PVR extension that is handled by our own handler
		if (std::string::npos != lowerCase.find(".pvr")) {
			initWithPVRFile(fullpath.c_str());
		} else {
			CCImage::EImageFormat eImageFormat = CCImage::kFmtUnKnown;
			if (std::string::npos != lowerCase.find(".png")) {
				eImageFormat = CCImage::kFmtPng;
			} else if (std::string::npos != lowerCase.find(".jpg") || std::string::npos != lowerCase.find(".jpeg")) {
				eImageFormat = CCImage::kFmtJpg;
			} else if (std::string::npos != lowerCase.find(".tif") || std::string::npos != lowerCase.find(".tiff")) {
				eImageFormat = CCImage::kFmtTiff;
			}
			
			CCImage image;
			unsigned long nSize = 0;
			unsigned char* pBuffer = CCFileUtils::sharedFileUtils()->getFileData(fullpath.c_str(), "rb", &nSize);
			if (!image.initWithImageData((void*)pBuffer, nSize, eImageFormat)) {
				CC_SAFE_DELETE_ARRAY(pBuffer);
				return;
			} else {
				CC_SAFE_DELETE_ARRAY(pBuffer);
			}
						
			initWithImage(&image);
		}
	}
};

///for work:
///in file CCTexture2D.h add line: "static bool is_reload_texture;"
///in file CCTexture2D.cpp add line: "bool CCTexture2D::is_reload_texture = false;"
///replace all "glGenTextures" on "if(!CCTexture2D::is_reload_texture) { glGenTextures();}"
///in class constructor CCTexturePVR  add (unsigned int m_uName = 0)
///and change all constructors on "CCTexturePVR(m_uName);"
/// in file "CCTexturePVR.cpp" in function "initWithContentsOfFile" remove line "m_uName = 0;"

bool SceneController::getOrSetState(int new_state) {
	static bool last_state = true;
	if( new_state < 0) {
		last_state = false;
	}
	if( new_state > 0) {
		last_state = true;
	}
	
	return last_state;
}

CCNode* SceneController::loadUnloadAllResourceWithSaveState(bool isLoad,CCNode* label_for_visit) {
	static CCNode* load_label = 0x0;
	if( isLoad == getOrSetState(0)) {
		return load_label;
	}
	if( isLoad) {
		getOrSetState(1);
	} else {
		getOrSetState(-1);
	}
	
	if( !isLoad) {
		load_label = label_for_visit;
		if( 0x0 != load_label) {
			CCDirector::sharedDirector()->getRunningScene()->addChild(load_label,100500);
			CCDirector::sharedDirector()->drawScene();
		}
	}
	
	TextureInformationMap::iterator iter;
	CCTexture2D::is_reload_texture = true;
	
	for( iter = textureInformation.begin(); iter != textureInformation.end(); ++iter) {
		if( isLoad) {
			CCTexture2D::setDefaultAlphaPixelFormat(iter->second.format);
			((CCDynamicTexture2D*)iter->first)->reloadData(iter->second.texture_path);
			CCTexture2D::setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_Default);
		} else {
			((CCDynamicTexture2D*)iter->first)->removeData();
		}
	}
	
	CCTexture2D::is_reload_texture = false;
	
	if( isLoad) {
		CCNode* last_label = load_label;
		load_label = 0x0;
		return last_label;
	}
	return load_label;
}