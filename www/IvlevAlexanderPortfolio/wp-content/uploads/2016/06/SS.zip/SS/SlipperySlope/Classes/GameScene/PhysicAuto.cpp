//
//  PhysicAuto.cpp
//  SlipperySlope
//
//  Created by Alexander Ivlev on 27.06.13.
//
//

#include "PhysicAuto.h"
#include <GrizzlyJr/Graphic/Box2DCocos.h>
#include "Engine.h"
#include "Wheel.h"
#include <math.h>

using namespace GrizzlyJr;
using namespace SlipperSlope;
USING_NS_CC;

PhysicAuto* PhysicAuto::create(Auto* image_auto,b2World* world,float scale) {
	PhysicAuto* new_auto = new PhysicAuto();
	if( new_auto && new_auto->init(image_auto,world,scale)) {
		new_auto->autorelease();
		return new_auto;
	}
	CC_SAFE_DELETE(new_auto);
	return 0x0;
}

bool PhysicAuto::init(Auto* image_auto,b2World* world,float scale) {
	initGas(0);
	gas_air_mult = 0.9f;
	gas_ground_mult = 1.0f;
	
	auto_scale = scale;
	const std::vector<AutoElement*>& elements = image_auto->getElements();
	translate = ccp(0,0);
	driver = 0x0;
	speed = ccp(0,0);
	
	CCSize win_size = CCDirector::sharedDirector()->getWinSize();
	
	mass = 0;
	
	depth = 0;
	CCPoint min = ccp(99999,99999);
	CCPoint max = ccp(-99999,-99999);
	for (size_t i =0; i < elements.size(); i++) {
		AutoElement* phys_element = elements[i]->createPhysicCopy(world,ccp(0,win_size.height*0.2f),auto_scale);
		if( "driver" == phys_element->getType()) {
			driver = phys_element;
			begin_angle = driver->getRotation();
		}
		if( "wheel" == phys_element->getType()) {
			wheels.push_back(phys_element);
		}
		
		if( 0x0 != phys_element) {
			addChild(phys_element,phys_element->getZOrder(),0);
			depth = MAX(depth,phys_element->getDepth());
			min.x = MIN(min.x, phys_element->getPosition().x-phys_element->getContentSize().width*0.5f);
			min.y = MIN(min.y, phys_element->getPosition().y-phys_element->getContentSize().height*0.5f);
			max.x = MAX(max.x, phys_element->getPosition().x+phys_element->getContentSize().width*0.5f);
			max.y = MAX(max.y, phys_element->getPosition().y+phys_element->getContentSize().height*0.5f);
		}
	}
	
	angle = 0;
	
	dimensions.origin = min;
	dimensions.size.width = max.x-min.x;
	dimensions.size.height = max.y-min.y;
	if( driver ) {
		dimensions.origin = ccpSub(dimensions.origin, driver->getPosition());
	}
	
	
	std::vector<bool> is_mounting;
	size_t count = getChildrenCount();
	
	is_mounting.resize(count);
	for( size_t i = 0; i < count; i++) {
		is_mounting[i] = false;
		if( m_pChildren->objectAtIndex(i) == driver) {
			is_mounting[i] = true;
		}
	}
	
	
	for( size_t i1 = 0; i1 < count; i1++) {
		for( size_t i2 = i1+1; i2 < count; i2++) {
			AutoElement* a1 = (AutoElement*)m_pChildren->objectAtIndex(i1);
			AutoElement* a2 = (AutoElement*)m_pChildren->objectAtIndex(i2);
			bool is_mount = is_mounting[i1] | is_mounting[i2];
			
			
			std::vector<cocos2d::CCPoint> points = findMounting(a1, a2);
			if( is_mount && points.size() > 0) {
				is_mounting[i1] = is_mounting[i2] = true;
			}
			
			for( size_t k = 0; k < points.size(); k++) {
				createRevoluteJoint(points[k],a1,a2,world);
			}
		}
	}
	
	for( size_t i = 0; i < count; i++) {
		AutoElement* a = (AutoElement*)m_pChildren->objectAtIndex(i);
		if( is_mounting[i]) {
			mass += a->getMass();
		}
	}
	
	setTranslate(ccp(0,0));
	
	return true;
}

PhysicAuto* PhysicAuto::create(Auto* image_auto,float scale) {
	PhysicAuto* new_auto = new PhysicAuto();
	if( new_auto && new_auto->init(image_auto,scale)) {
		new_auto->autorelease();
		return new_auto;
	}
	CC_SAFE_DELETE(new_auto);
	return 0x0;
}
bool PhysicAuto::init(Auto* image_auto,float scale) {
	auto_scale = scale;
	const std::vector<AutoElement*>& elements = image_auto->getElements();
	translate = ccp(0,0);
	speed = ccp(0,0);
	driver = 0x0;
	
	CCSize win_size = CCDirector::sharedDirector()->getWinSize();
	
	CCPoint min = ccp(99999,99999);
	CCPoint max = ccp(-99999,-99999);
	mass = 0;
	depth = 0;
	for (size_t i =0; i < elements.size(); i++) {
		AutoElement* phys_element = elements[i]->createCopy(ccp(0,win_size.height*0.2f),auto_scale);		
		if( 0x0 != phys_element) {
			addChild(phys_element,phys_element->getZOrder(),0);
			depth = MAX(depth,phys_element->getDepth());
			min.x = MIN(min.x, phys_element->getPosition().x-phys_element->getContentSize().width*0.5f);
			min.y = MIN(min.y, phys_element->getPosition().y-phys_element->getContentSize().height*0.5f);
			max.x = MAX(max.x, phys_element->getPosition().x+phys_element->getContentSize().width*0.5f);
			max.y = MAX(max.y, phys_element->getPosition().y+phys_element->getContentSize().height*0.5f);
		}
		if( "driver" == phys_element->getType()) {
			driver = phys_element;
			begin_angle = driver->getRotation();
		}
	}
	
	angle = 0;
	
	dimensions.origin = min;
	dimensions.size.width = max.x-min.x;
	dimensions.size.height = max.y-min.y;
	if( driver ) {
		dimensions.origin = ccpSub(dimensions.origin, driver->getPosition());
	}
	
	setTranslate(ccp(0,0));
	
	return true;
}

void PhysicAuto::recalcDriver() {
	if( driver) {
		CCPoint my_pos = driver->getPosition();
		this->setPosition(my_pos);
		driver_pos = my_pos;
		angle = driver->getRotation()-begin_angle;
	}
	

	speed = ccp(0,0);
	size_t count = 0;
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(m_pChildren, iter) {
		b2Body* body = ((AutoElement*)iter)->getBody();
		if( body) {
			CCPoint l_speed = Box2DCocos::convert(body->GetLinearVelocity());
			speed = ccpAdd(speed, l_speed);
			count++;
		}
	}
	
	speed = ccpMult(speed,(1.0f/(float)count));
	
	speed_five.push_back(speed);
	if( speed_five.size() > 5) {
		speed_five.pop_front();
	}
	
	speed = ccp(0,0);
	for( size_t i =0; i < speed_five.size(); i++) {
		speed = ccpAdd(speed, speed_five[i]);
	}
	speed = ccpMult(speed,(1.0f/(float)speed_five.size()));
}


std::vector<cocos2d::CCPoint> PhysicAuto::findMounting(AutoElement* a1, AutoElement* a2) {
	std::vector<cocos2d::CCPoint> result;
	
	const std::vector<cocos2d::CCPoint>& m1 = a1->getMounting();
	const std::vector<cocos2d::CCPoint>& m2 = a2->getMounting();
	for( size_t i =0; i < m1.size(); i++) {
		CCPoint w1 = convertToNodeSpace(a1->convertToWorldSpace(m1[i]));
		for( size_t j =0; j < m2.size(); j++) {
			CCPoint w2 = convertToNodeSpace(a2->convertToWorldSpace(m2[j]));
			if( ccpDistance(w1, w2) < 1) {
				result.push_back(w1);
				break;
			}
			
		}
	}
	
	return result;
}

void PhysicAuto::createRevoluteJoint(cocos2d::CCPoint point,AutoElement* e1, AutoElement* e2, b2World* world) {
	b2RevoluteJointDef jointDef;
	cocos2d::CCLog("ADD JOINT (%f,%f)",point.x,point.y);
	b2Vec2 pos = Box2DCocos::convert(point);
	jointDef.Initialize(e1->getBodyFromPoint(pos), e2->getBodyFromPoint(pos), pos);
	
	jointDef.collideConnected = false;
	b2RevoluteJoint* joint = (b2RevoluteJoint*)world->CreateJoint(&jointDef);
	
	createMotorIfNeed(e1, e2, joint);
	createMotorIfNeed(e2, e1, joint);
}

void PhysicAuto::createMotorIfNeed(AutoElement* e1, AutoElement* e2,b2RevoluteJoint* joint) {
	if( "engine" == e1->getType()  && "wheel" == e2->getType()) {
		joint->EnableMotor(false);
		joint->SetMaxMotorTorque(((Engine*)e1)->getTorque());
		Motor new_motor = {joint ,e2,((Engine*)e1)};
		motors.push_back(new_motor);
	}
}


#define CHANGE_SPEED_MULT 5
void PhysicAuto::setSpeed(float mult,float dt) {
	if( gas <= 0) {
		mult = 0;
	}
	
	std::map<Engine*,b2RevoluteJoint*> is_use;
	float gas_step = 0;
	for( size_t i = 0; i < motors.size(); i++) {
		Engine* engine = (Engine*)motors[i].engine;
		b2RevoluteJoint* find = is_use[engine];
		if( find) {
			motors[i].motor->EnableMotor(find->IsMotorEnabled());
			motors[i].motor->SetMotorSpeed(find->GetMotorSpeed());
			continue;
		}
		
		float c_speed = motors[i].motor->GetMotorSpeed();
		float max_speed = engine->getMaxSpeed();
		float accelerate = engine->getAccelerate();
				
		if( 0 == mult) {
			if( fabs(c_speed) < accelerate*dt) {
				c_speed = 0;
			}
			motors[i].motor->EnableMotor(false);
		} else {
			if( !motors[i].motor->IsMotorEnabled()) {
				c_speed = motors[i].wheel->getBody()->GetAngularVelocity();
			}
			motors[i].motor->EnableMotor(true);
		}
		
		c_speed += accelerate*dt*mult;
		c_speed = (c_speed > max_speed)? max_speed : c_speed;
		c_speed = (c_speed < -max_speed)? -max_speed : c_speed;
		
		motors[i].motor->SetMotorSpeed(c_speed);
		
		if( motors[i].motor->IsMotorEnabled()) {
			float speed = fabs(motors[i].motor->GetMotorSpeed()*motors[i].motor->GetMotorTorque(1/dt));
			if( speed > 1) {
				b2ContactEdge* contacts = motors[i].wheel->getBody()->GetContactList();
				float mult = (contacts)?gas_ground_mult:gas_air_mult;				
				float logs = log(speed)/log(engine->getDegree());
				gas_step += mult*(engine->getA() - engine->getB()*logs);
			}
		}
		is_use[engine] = motors[i].motor;
	}
	
	gas_step *= dt;
	gas -= gas_step;
	gas = MAX(0,gas);
}

void PhysicAuto::rotateLeft(float dt) {
	if( driver) {
		driver->getBody()->ApplyAngularImpulse(15*mass*dt*auto_scale);
	}
}
void PhysicAuto::rotateRight(float dt) {
	if( driver) {
		driver->getBody()->ApplyAngularImpulse(-15*mass*dt*auto_scale);
	}
}

#define SIGN(a) ((a)>0?1:-1)
void PhysicAuto::stabilization(float dt) {
	if( driver ) {
		bool is_find = false;
		for( size_t i =0; i < wheels.size(); i++) {
			b2ContactEdge* contacts = wheels[i]->getBody()->GetContactList();
			if( contacts) {
				is_find = true;
			}
		}
		
		if( is_find) {
			air_time = 0;
		} else {
			air_time += dt;
		}
		if( air_time < 0.25f) {
			return;
		}
		
		float angle = driver->getRotation();
		
		float force = angle-begin_angle;
		force -= ((int)(force/360))*360;
		if( fabs(force) > 180) {
			force = SIGN(force)*(force-360);
		}
		
		float velocity = driver->getBody()->GetAngularVelocity();
		if( SIGN(velocity) != SIGN(force) && fabs(force) > 30) {
			if( fabs(velocity) > 5) { velocity = SIGN(velocity)*5; }
			
			force = (force/90)*fabs(velocity)*fabs(velocity)*mass*mass;
			driver->getBody()->ApplyAngularImpulse(force*dt);
			cocos2d::CCLog("STABILIZATION");
		}
	}
}

std::vector<PhysicAuto::ContactWheelInfo> PhysicAuto::getAllContactsWheel() {
	std::vector<ContactWheelInfo> result;
	b2WorldManifold worldManifold;
	
	for( size_t i =0; i < wheels.size(); i++) {
		ContactWheelInfo wheel_info;
		
		b2ContactEdge* contacts = wheels[i]->getBody()->GetContactList();
		if( !contacts) {
			continue;
		}
		b2Manifold* info = contacts->contact->GetManifold();
		if( !info || 0 ==info->pointCount) {
			continue;
		}
		contacts->contact->GetWorldManifold(&worldManifold);
		
		b2ManifoldPoint point_info = info->points[0];
		wheel_info.wpos = Box2DCocos::convert(worldManifold.points[0]);
		
		float impulse = point_info.normalImpulse;
		wheel_info.normal_impulse = Box2DCocos::convert(worldManifold.normal);
		wheel_info.normal_impulse = ccpMult(wheel_info.normal_impulse, impulse);
		
		wheel_info.angular_speed = wheels[i]->getBody()->GetAngularVelocity();
		wheel_info.angular_speed *= ((Wheel*)wheels[i])->getRadius();
		wheel_info.speed = Box2DCocos::convert(wheels[i]->getBody()->GetLinearVelocity());
		result.push_back(wheel_info);
	}
	return result;
}

void PhysicAuto::update(float dt) {
	CCObject* iter = 0x0;
	CCARRAY_FOREACH(m_pChildren, iter) {
		((AutoElement*)iter)->updateImage();
	}
	
	recalcDriver();
}

void PhysicAuto::visit() {
	CCPoint pos = this->getPosition();
	this->setPosition(getPositionOnScreen());
	
	visit3dView();
	visitNormal();
	
	this->setPosition(pos);
}

cocos2d::CCPoint PhysicAuto::getPositionOnScreen() {
	return ccpAdd(this->getPosition(), translate);
}

void PhysicAuto::visit3dView() {
    kmGLPushMatrix();
    this->transform();
	
    if(m_pChildren && m_pChildren->count() > 0) {
		CCNode* pNode = 0x0;
        ccArray *arrayData = m_pChildren->data;
        for( unsigned int i = 0; i < arrayData->num; i++ ) {
            pNode = (CCNode*) arrayData->arr[i];
            if (pNode) {
				CCPoint pos = pNode->getPosition();
				pNode->setPosition(ccpSub(pos, driver_pos));
                ((AutoElement*)pNode)->visit3dView(0);
				pNode->setPosition(pos);
            }
        }
    }
	
    kmGLPopMatrix();
}

void PhysicAuto::visitNormal() {
	kmGLPushMatrix();
    this->transform();
	
    if(m_pChildren && m_pChildren->count() > 0) {
		CCNode* pNode = 0x0;
        ccArray *arrayData = m_pChildren->data;
        for( unsigned int i = 0; i < arrayData->num; i++ ) {
            pNode = (CCNode*) arrayData->arr[i];
            if (pNode) {
				CCPoint pos = pNode->getPosition();
				pNode->setPosition(ccpSub(pos, driver_pos));
                pNode->visit();
				pNode->setPosition(pos);
            }
        }
    }
	
    kmGLPopMatrix();
}
