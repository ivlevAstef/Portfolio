//
//  MyLogFunction.cpp
//  CuteHeroes
//
//  Created by Alexander Ivlev on 12.04.13.
//
//

#include "LogFunction.h"
#include "cocos2d.h"

#define MAX_LENGTH_LOG 16*1024
void GrizzlyJr::NormalLog(const char * pszFormat, ...) {
	char szBuf[MAX_LENGTH_LOG];
	va_list ap;
	va_start(ap, pszFormat);
	vsnprintf(szBuf, MAX_LENGTH_LOG, pszFormat, ap);
	va_end(ap);
	
	cocos2d::CCLog("Grizzly JR: %s",szBuf);
}