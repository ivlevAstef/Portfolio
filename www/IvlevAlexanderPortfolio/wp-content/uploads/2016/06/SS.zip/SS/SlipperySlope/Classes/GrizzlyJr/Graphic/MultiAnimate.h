#ifndef _GRIZZLY_JR_MULTI_ANIMATE_H_
#define _GRIZZLY_JR_MULTI_ANIMATE_H_

#include "cocos2d.h"

namespace GrizzlyJr
{
	class MultiAnimate: public cocos2d::CCActionInterval
	{
	public:
		inline cocos2d::CCAnimation* getAnimation() { return animation; }
		inline void setAnimation(cocos2d::CCAnimation* animation,unsigned int count) {
			this->animation = animation;
			this->count = count;
		}

		bool initWithAnimation(cocos2d::CCAnimation* animation,unsigned int count);
		bool initWithDuration(float duration, cocos2d::CCAnimation* animation,unsigned int count);

		virtual CCObject* copyWithZone(cocos2d::CCZone* pZone);
		virtual void startWithTarget(cocos2d::CCNode* target);
		virtual void stop(void);
		virtual void update(float time);
		virtual CCActionInterval* reverse(void);
		virtual bool isDone(void);
		
		void setSound(std::string nameSound,float soundLength) {
			this->nameSound = nameSound;
			this->soundLength = soundLength;
		}

		MultiAnimate();
		~MultiAnimate();
	public:
		static MultiAnimate* actionWithAnimation(cocos2d::CCAnimation* animation,unsigned int count);
		static MultiAnimate* create(float duration, cocos2d::CCAnimation* animation,unsigned int count);
		
	protected:
		float soundLength;
		std::string nameSound;
		
		cocos2d::CCAnimation* animation;
		unsigned int count;
		
		int                 m_nNextFrame;
	};
};
#endif
