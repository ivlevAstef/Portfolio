#ifndef _GRIZZLY_JR_FILE_IMAGE_ON_MEMORY_H_
#define _GRIZZLY_JR_FILE_IMAGE_ON_MEMORY_H_

#include <map>
#include <string>
#include <vector>

namespace GrizzlyJr
{	
	class FIOMNode;
	class FIOMMain {
	public:
		struct NodeFileImage {
			std::map<std::string,std::string> values;
			std::map<std::string,NodeFileImage> dirs;
			bool isSpecial;
			bool isArray;
			
			NodeFileImage():isSpecial(false),isArray(false) {}
			
			~NodeFileImage() {
				values.clear();
				dirs.clear();
			}
		};
		
	private:
		std::map<std::string,NodeFileImage> files;
		std::vector<std::string> is_BAK_file;

		static FIOMMain* singleton;
		
	public:
		FIOMMain();

		std::string loadFile(std::string path);///return NameFile
		bool loadFileData(std::string name,unsigned char* dataFile, unsigned long sizeFile);
		void saveFile(std::string path);
		void removeFile(std::string path);
		void closeFile(std::string path);
		bool isLoad(std::string path);
		
		FIOMNode getRoot(const char* nameFile);

		static FIOMMain* get();
		
		
		static std::string fileNameFromFilePath(std::string file_path);
	private:
		int saveFile(const NodeFileImage& node, std::string& output,bool isFirst);///return count string for save
		
		NodeFileImage* getNode(std::string file_name);
	};
};
#endif
