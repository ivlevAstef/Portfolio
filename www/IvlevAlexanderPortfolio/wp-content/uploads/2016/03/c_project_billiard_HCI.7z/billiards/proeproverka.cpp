#pragma once
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <MATH.h>
#include <sys/timeb.h>
#include "var.h"
#include "mous.h"
#define loader "redaktor/map/pole.map"  
struct zelovek zel; 
struct zelovek vr[kolvr]; 
char load[50];
int i,j,rasmx,rasmy;
int ewidth,eheigth,Even;
short int UpDown,vrema,vihod,plmn,EnterK;
AUX_RGBImageRec *men[2],*exito;
unsigned int ment[2],exitot;
float znaz,vrPad,oke,nomerr=0;
struct orugie orug[5];
int anim[5];
struct patron pt[30];
struct volna vl[30];
struct ekran ek;
struct karta kar;
struct teksturi TeSt;
objtype zelov[3];
objtype granat;
objtype pistol;
objtype avtomat;
objtype raket;
objtype laser;
void ris(objtype object,float ras)
{
	int l_index;
	glBegin(GL_TRIANGLES); 
	glColor3ub(object.r,object.g,object.b);
	for (l_index=0;l_index<object.polygons_qty;l_index++)
    {        
        glVertex3d( object.vertex[ object.polygon[l_index].a ].x*ras,
                    object.vertex[ object.polygon[l_index].a ].y*ras,
                    object.vertex[ object.polygon[l_index].a ].z*ras);
        glVertex3d( object.vertex[ object.polygon[l_index].b ].x*ras,
					object.vertex[ object.polygon[l_index].b ].y*ras,
                    object.vertex[ object.polygon[l_index].b ].z*ras);      
        glVertex3d( object.vertex[ object.polygon[l_index].c ].x*ras,
                    object.vertex[ object.polygon[l_index].c ].y*ras,
                    object.vertex[ object.polygon[l_index].c ].z*ras);
    }
    glEnd();
}
void lo3d(objtypeprt obte, char *filna,char *filna2)
{
	int i;
	FILE *l_file;
	unsigned short l_chunk_id; //id ????? (chunk) 2 ?????
	unsigned int l_chunk_length;//?????? chunk�?, 4 ?????.
	unsigned char l_char;
	unsigned short l_qty; // ?????????????? ????????, ????? ??????? ??? ????????? ?????????? ? ?????????? ???????? ??????????.
	unsigned short l_face_flags;
	if ((l_file=fopen(filna,"rb"))==NULL) return;
	while (ftell(l_file)<filelength(fileno(l_file))){
		fread (&l_chunk_id, 2, 1, l_file); //?????? ????????? chunk'a
		fread (&l_chunk_length, 4, 1, l_file); //?????? ????? ?????
		switch (l_chunk_id) {
			case 0x4d4d: break;	//0x4d4d -hex- ??? ???????? ?????
			case 0x3d3d: break; //0x3d3d -hex- the 3D EDITOR CHUNK ?? ????? ??? ?? ????? ?????? ??? ??? ???? ???? ?????????? ??????
			case 0x4000: //Object Block - ?? ???? ?????? ??? ??????? ?????? ?????? ?? ????? =)
				i=0;
				do
				{
					fread (&l_char, 1, 1, l_file);
					obte->name[i]=l_char;
					i++;
				}
				while(l_char != '\0' && i<20);
				break;
			case 0x4100: break;
			case 0x4110: //??? ??? ??? ????? ??? ???????? ???? ?????????? ?????.. vertex VERTICES LIST
				fread (&l_qty, sizeof (unsigned short), 1, l_file); //?????? "quantity" ????? ????? ;)
				obte->vertices_qty = l_qty;
				for (i=0; i<l_qty; i++){
					fread (&obte->vertex[i].x, sizeof(float), 1, l_file);
					fread (&obte->vertex[i].y, sizeof(float), 1, l_file);
					fread (&obte->vertex[i].z, sizeof(float), 1, l_file);
				}
				break;
			case 0x4120://FACESDESCRIPTION ???????? ???????? ????????? ???????.
				fread (&l_qty, sizeof (unsigned short), 1, l_file);
				obte->polygons_qty = l_qty;
				for (i=0; i<l_qty; i++){
					fread (&obte->polygon[i].a, sizeof (unsigned short), 1, l_file);
					fread (&obte->polygon[i].b, sizeof (unsigned short), 1, l_file);
					fread (&obte->polygon[i].c, sizeof (unsigned short), 1, l_file);
					fread (&l_face_flags, sizeof (unsigned short), 1, l_file);
				}
				break;
			case 0x4140://MAPPING COORDINATES LIST
				fread (&l_qty, sizeof (unsigned short), 1, l_file);
				for (i=0; i<l_qty; i++){
					fread (&obte->mapcoord[i].u, sizeof (float), 1, l_file);
					fread (&obte->mapcoord[i].v, sizeof (float), 1, l_file);
				}
				break;
			default: fseek(l_file, l_chunk_length-6, SEEK_CUR);//???? ?? ??? ???? ?????? ????? ?????? ??????????? ??????? =)
		}
	}
	fclose(l_file);
	{
	FILE *f=fopen(filna2,"r");
	fscanf(f,"%d",&obte->r);
	fscanf(f,"%d",&obte->g);
	fscanf(f,"%d",&obte->b);
    fclose(f);
	}
	return;
}/**/
int randoms(int low,int hight)
{
	int val;
	do
	{
		val=rand();
	}while((val < low)|| (val > hight));

	return val;
}
void zelovek(struct zelovek zel)
{
	GLUquadricObj *quadObj; 
    quadObj = gluNewQuadric(); 
    gluQuadricTexture(quadObj, GL_TRUE);
    gluQuadricDrawStyle(quadObj, GLU_FILL); 
glPushMatrix();
	  glTranslated(0,5.4,0);
	  glTranslated(0,-0.6,0);
	  {
	  glPushMatrix();
	  glTranslated(0,2,0);
	  glTranslated((float)zel.hp/60,0,0);
	  {
	  int r,g=255;
	  r=255-(zel.hp-50)*5.1;
	  if(r>=255){g=255-(r-255);r=255;}
      glColor3ub(r,g,0);
      glBegin(GL_QUADS);     
          glVertex3d(0,0,0);
          glVertex3d(-(float)zel.hp/30,0,0);
          glVertex3d(-(float)zel.hp/30,0.2,0);
          glVertex3d(0,0.2,0);
      glEnd();
	  }
      glPopMatrix();
	  }
	  //tulovihe
      glPushMatrix();
	    //glRotated(-kar.ugl,0,1,0);
	    glTranslated(0,-2.5,0);
	    glRotated(-90+zel.tulu,1,0,0);
		////////////////rhjdm
		if(zel.hp<=0)
		{
			int i;
			glColor3d(1,0,0);
		  glBegin(GL_POLYGON);
		    glVertex3d(0,0,0);
			for(i=0;i<360;i+=15)
			{
		    glVertex3d(sin(i*3.14/180)*3,0,cos(i*3.14/180)*3);
			}
		  glEnd();
		}
		glColor3d(1,1,1);
		glRotated(90,1,0,0);
		if(zel.hp>0) ris(zelov[(int)(nomerr)],0.1);
		if(zel.hp<=0) ris(zelov[0],0.1);
		nomerr+=0.5;
		if(nomerr>2)nomerr=0;
		/////////////////////
/*	    glEnable(GL_TEXTURE_2D);
	    glBindTexture(GL_TEXTURE_2D,zel.t.telot);
	    gluCylinder(quadObj,0.3,0.31,2.5,7,7); 
		//golova
		glPushMatrix();
		  glTranslated(0,0,3.1);
	      glRotated(180,0,0,1);
	      glBindTexture(GL_TEXTURE_2D,zel.t.golovat);
	      gluSphere(quadObj,0.8,10,10); 
	    glPopMatrix();  
	  glTranslated(0,0,2.2);
	  //ruk1
	  glPushMatrix();
	  glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	    glTranslated(0.4,0,0);
	    glRotated(90-zel.tulu,1,0,0);
	    glRotated(90,0,1,0);
		glRotated(90-zel.rk11u,1,0,0);
		glRotated(zel.rk11u2,0,1,0);
	    gluCylinder(quadObj,0.1,0.1,1.2,7,7); 
		glColor3d(0,0,0);
		gluSphere(quadObj,0.099,7,7); 
		glBindTexture(GL_TEXTURE_2D,zel.t.rukt);////////////////////////
		glColor3d(1,1,0);
		glTranslated(0,0,1.2);
		gluSphere(quadObj,0.099,7,7); 
		glColor3d(1,1,1);
	 	glPushMatrix();
		  glRotated(-zel.rk12u,0,1,0);
		  glColor3d(1,1,1);
	      glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	      gluCylinder(quadObj,0.1,0.1,1.2,7,7); 
		  glBindTexture(GL_TEXTURE_2D,zel.t.rukt);/////////////////////
		  glTranslated(0,0,1.2);
		  glColor3d(1,1,0);
		  gluSphere(quadObj,0.099,7,7); 
		  if(zel.no==3)
		  {
			  ris(granat);
		  }
		  glColor3d(1,1,1);
        glPopMatrix();
      glPopMatrix();
	  ///ruk2
	  glPushMatrix();
	  glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	    glTranslated(-0.4,0,0);
	    glRotated(90-zel.tulu,1,0,0);
	    glRotated(90,0,1,0);
		glRotated(90+zel.rk21u,1,0,0);
		glRotated(zel.rk21u2,0,1,0);
	    gluCylinder(quadObj,0.1,0.1,1.2,7,7); 
		glColor3d(0,0,0);
		gluSphere(quadObj,0.099,7,7); 
		glBindTexture(GL_TEXTURE_2D,zel.t.rukt);///////////////////
		glColor3d(1,1,0);
		glTranslated(0,0,1.2);
		gluSphere(quadObj,0.099,7,7); 
		glColor3d(1,1,1);
		glPushMatrix();
		  glRotated(-zel.rk12u,0,1,0);
		  glColor3d(1,1,1);
	      glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	      gluCylinder(quadObj,0.1,0.1,1.2,7,7); 
		  glBindTexture(GL_TEXTURE_2D,zel.t.rukt);///////////////
		  glTranslated(0,0,1.2);
		  glColor3d(1,1,0);
		  gluSphere(quadObj,0.099,7,7); 
		  glColor3d(1,1,1);
        glPopMatrix();
      glPopMatrix();
	  glPopMatrix();
	  glTranslated(0,-2.1,0);
	  //noga1
	  glPushMatrix();
	    glColor3d(1,1,1);
	    glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	    //glRotated(-kar.ugl,0,1,0);
	    glTranslated(0.25,0,0);
	    glRotated(90,0,1,0);
		glRotated(90-zel.ng11u,1,0,0);
		glRotated(zel.ng11u2,0,1,0);
	    gluCylinder(quadObj,0.13,0.13,1.3,7,7); 
		glColor3d(0,0,0);
		gluSphere(quadObj,0.129,7,7); 
		glTranslated(0,0,1.3);
		gluSphere(quadObj,0.129,7,7); 
		glPushMatrix();
		  glRotated(zel.ng11u,1,0,0);
		  glRotated(zel.ng12u,0,1,0);
		  glColor3d(1,1,1);
	      glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	      gluCylinder(quadObj,0.13,0.13,1.3,7,7); 
		  glColor3d(0,0,0);
		  glTranslated(0,0,1.3);
		  gluSphere(quadObj,0.129,7,7); 
        glPopMatrix();
		glColor3d(1,1,1);
      glPopMatrix();
	  //noga2
	  glPushMatrix();
	  glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	  //glRotated(-kar.ugl,0,1,0);
	    glTranslated(-0.25,0,0);
	    glRotated(90,0,1,0);
		glRotated(90+zel.ng21u,1,0,0);
		glRotated(zel.ng21u2,0,1,0);
	    gluCylinder(quadObj,0.13,0.13,1.3,7,7); 
		glColor3d(0,0,0);
		gluSphere(quadObj,0.129,7,7); 
		glBindTexture(GL_TEXTURE_2D,zel.t.rukt);//////
		glTranslated(0,0,1.3);
		glColor3d(1,1,0);
		gluSphere(quadObj,0.129,7,7); 
		glColor3d(1,1,1);
		glPushMatrix();
		  glColor3d(1,1,1);
		  glRotated(-zel.ng21u,1,0,0);
		  glRotated(zel.ng22u,0,1,0);
	      glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
	      gluCylinder(quadObj,0.13,0.13,1.3,7,7); 
		  glColor3d(0,0,0);
		  glTranslated(0,0,1.3);
		  gluSphere(quadObj,0.129,7,7); 
        glPopMatrix();*/
      glPopMatrix();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
	gluDeleteQuadric(quadObj);
}
void ZagrTextur()
{
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	  zel.t.golova=auxDIBImageLoad("image/zel/golova.bmp"); 
	  zel.t.telo=auxDIBImageLoad("image/zel/telo1.bmp"); 
	  zel.t.ruk=auxDIBImageLoad("image/zel/rk1.bmp"); 
	  men[0]=auxDIBImageLoad("image/dop/men.bmp"); 
	  men[1]=auxDIBImageLoad("image/dop/men2.bmp"); 
	  exito=auxDIBImageLoad("image/dop/exit.bmp"); 
	  TeSt.sten.dver[0]=auxDIBImageLoad("image/sten/dver1.bmp"); 
	  TeSt.sten.dver[1]=auxDIBImageLoad("image/sten/dver2.bmp"); 
	  TeSt.sten.dver[2]=auxDIBImageLoad("image/sten/dverb.bmp"); 
	  TeSt.sten.kir[0]=auxDIBImageLoad("image/sten/kir1.bmp"); 
	  TeSt.sten.kir[1]=auxDIBImageLoad("image/sten/kir2.bmp"); 
	  TeSt.sten.metal[0]=auxDIBImageLoad("image/sten/metal1.bmp"); 
	  TeSt.sten.metal[1]=auxDIBImageLoad("image/sten/metal2.bmp"); 
	  TeSt.sten.bet[0]=auxDIBImageLoad("image/sten/bet1.bmp"); 
	  TeSt.sten.bet[1]=auxDIBImageLoad("image/sten/bet2.bmp"); 
	  TeSt.sten.steklo[0]=auxDIBImageLoad("image/sten/steklo1.bmp"); 
	  TeSt.sten.steklo[1]=auxDIBImageLoad("image/sten/steklo2.bmp"); 
	  TeSt.pol.trav=auxDIBImageLoad("image/pol/trav.bmp"); 
	  TeSt.pol.led=auxDIBImageLoad("image/pol/led.bmp"); 
	  TeSt.pol.derevo=auxDIBImageLoad("image/pol/derevo.bmp"); 
	  TeSt.pol.derevo2=auxDIBImageLoad("image/pol/derevo2.bmp"); 
	  TeSt.pol.zemla=auxDIBImageLoad("image/pol/zemla.bmp"); 
	  TeSt.pol.vater=auxDIBImageLoad("image/pol/vater.bmp"); 
	  TeSt.pol.plitka=auxDIBImageLoad("image/pol/plitka.bmp"); 
      TeSt.pol.st=auxDIBImageLoad("image/pol/st.bmp"); 
	  TeSt.pol.ex=auxDIBImageLoad("image/pol/exit.bmp"); 
	  orug[3].pul=auxDIBImageLoad("image/gr.bmp"); 
	  glGenTextures(1, &orug[3].pult);
	  glBindTexture(GL_TEXTURE_2D,orug[3].pult);
	  gluBuild2DMipmaps(GL_TEXTURE_2D,3, orug[3].pul->sizeX, orug[3].pul->sizeY, GL_RGB, GL_UNSIGNED_BYTE, orug[3].pul->data);
	  for(i=0;i<kolvr;i++)
	  {
	  vr[i].t.golova=auxDIBImageLoad("image/zel/golova.bmp"); 
	  if(i%3==0)vr[i].t.telo=auxDIBImageLoad("image/zel/telo1.bmp"); 
	  if(i%3==1)vr[i].t.telo=auxDIBImageLoad("image/zel/telo2.bmp"); 
	  if(i%3==2)vr[i].t.telo=auxDIBImageLoad("image/zel/telo3.bmp"); 
	  if(i%3==0)vr[i].t.ruk=auxDIBImageLoad("image/zel/rk1.bmp"); 
	  if(i%3==1)vr[i].t.ruk=auxDIBImageLoad("image/zel/rk2.bmp"); 
	  if(i%3==2)vr[i].t.ruk=auxDIBImageLoad("image/zel/rk3.bmp"); 
	  glGenTextures(1, &vr[i].t.rukt);
	  glBindTexture(GL_TEXTURE_2D,vr[i].t.rukt);
	  gluBuild2DMipmaps(GL_TEXTURE_2D,3, vr[i].t.ruk->sizeX, vr[i].t.ruk->sizeY, GL_RGB, GL_UNSIGNED_BYTE, vr[i].t.ruk->data);
	glGenTextures(1, &vr[i].t.telot);
	glBindTexture(GL_TEXTURE_2D,vr[i].t.telot);
	gluBuild2DMipmaps(GL_TEXTURE_2D,3, vr[i].t.telo->sizeX, vr[i].t.telo->sizeY, GL_RGB, GL_UNSIGNED_BYTE, vr[i].t.telo->data);
	  glGenTextures(1, &vr[i].t.golovat);
	  glBindTexture(GL_TEXTURE_2D,vr[i].t.golovat);
	  gluBuild2DMipmaps(GL_TEXTURE_2D,3, vr[i].t.golova->sizeX, vr[i].t.golova->sizeY,GL_RGB, GL_UNSIGNED_BYTE, vr[i].t.golova->data);
	  }
	glGenTextures(1, &exitot);
	glBindTexture(GL_TEXTURE_2D,exitot);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, exito->sizeX, exito->sizeY, GL_RGB, GL_UNSIGNED_BYTE, exito->data);
	  glGenTextures(1, &ment[0]);
	  glBindTexture(GL_TEXTURE_2D,ment[0]);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, men[0]->sizeX, men[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE, men[0]->data);
	glGenTextures(1, &ment[1]);
	glBindTexture(GL_TEXTURE_2D,ment[1]);
	gluBuild2DMipmaps(GL_TEXTURE_2D,3, men[1]->sizeX, men[1]->sizeY, GL_RGB, GL_UNSIGNED_BYTE, men[1]->data);
      glGenTextures(1, &zel.t.rukt);
	  glBindTexture(GL_TEXTURE_2D,zel.t.rukt);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, zel.t.ruk->sizeX, zel.t.ruk->sizeY, GL_RGB, GL_UNSIGNED_BYTE, zel.t.ruk->data);
	glGenTextures(1, &zel.t.telot);
	glBindTexture(GL_TEXTURE_2D,zel.t.telot);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, zel.t.telo->sizeX, zel.t.telo->sizeY, GL_RGB, GL_UNSIGNED_BYTE, zel.t.telo->data);
	  glGenTextures(1, &zel.t.golovat);
	  glBindTexture(GL_TEXTURE_2D,zel.t.golovat);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, zel.t.golova->sizeX, zel.t.golova->sizeY, GL_RGB, GL_UNSIGNED_BYTE, zel.t.golova->data);
	glGenTextures(1, &TeSt.sten.dvert[2]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.dvert[2]);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.dver[2]->sizeX,TeSt.sten.dver[2]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.dver[2]->data);
	  glGenTextures(1, &TeSt.sten.dvert[0]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.dvert[0]);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.dver[0]->sizeX,TeSt.sten.dver[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.dver[0]->data);
	  glGenTextures(1, &TeSt.sten.dvert[1]);
	  glBindTexture(GL_TEXTURE_2D,TeSt.sten.dvert[1]);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.dver[1]->sizeX,TeSt.sten.dver[1]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.dver[1]->data);
	glGenTextures(1, &TeSt.sten.steklot[0]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.steklot[0]);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.steklo[0]->sizeX,TeSt.sten.steklo[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.steklo[0]->data);
	  glGenTextures(1, &TeSt.sten.steklot[1]);
	  glBindTexture(GL_TEXTURE_2D,TeSt.sten.steklot[1]);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.steklo[1]->sizeX,TeSt.sten.steklo[1]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.steklo[1]->data);
	glGenTextures(1, &TeSt.sten.kirt[0]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.kirt[0]);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.kir[0]->sizeX,TeSt.sten.kir[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.kir[0]->data);
	  glGenTextures(1, &TeSt.sten.kirt[1]);
	  glBindTexture(GL_TEXTURE_2D,TeSt.sten.kirt[1]);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.kir[1]->sizeX,TeSt.sten.kir[1]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.kir[1]->data);
	glGenTextures(1, &TeSt.sten.metalt[0]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.metalt[0]);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.metal[0]->sizeX,TeSt.sten.metal[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.metal[0]->data);
	  glGenTextures(1, &TeSt.sten.metalt[1]);
	  glBindTexture(GL_TEXTURE_2D,TeSt.sten.metalt[1]);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.metal[1]->sizeX,TeSt.sten.metal[1]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.metal[1]->data);
    glGenTextures(1, &TeSt.sten.bett[0]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.bett[0]);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.bet[0]->sizeX,TeSt.sten.bet[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.bet[0]->data);
	  glGenTextures(1, &TeSt.sten.bett[1]);
	  glBindTexture(GL_TEXTURE_2D,TeSt.sten.bett[1]);	  
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.bet[1]->sizeX,TeSt.sten.bet[1]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.bet[1]->data);
	glGenTextures(1, &TeSt.pol.stt);
	glBindTexture(GL_TEXTURE_2D,TeSt.pol.stt);	
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.st->sizeX,TeSt.pol.st->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.st->data);
	glGenTextures(1, &TeSt.pol.travt);
	glBindTexture(GL_TEXTURE_2D,TeSt.pol.travt);	
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.trav->sizeX,TeSt.pol.trav->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.trav->data);
	  glGenTextures(1, &TeSt.pol.derevot);
	  glBindTexture(GL_TEXTURE_2D,TeSt.pol.derevot);	  
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.derevo->sizeX,TeSt.pol.derevo->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.derevo->data);
	glGenTextures(1, &TeSt.pol.zemlat);
	glBindTexture(GL_TEXTURE_2D,TeSt.pol.zemlat);	
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.zemla->sizeX,TeSt.pol.zemla->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.zemla->data);
	  glGenTextures(1, &TeSt.pol.vatert);
	  glBindTexture(GL_TEXTURE_2D,TeSt.pol.vatert);	  
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.vater->sizeX,TeSt.pol.vater->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.vater->data);
	glGenTextures(1, &TeSt.pol.derevo2t);
	glBindTexture(GL_TEXTURE_2D,TeSt.pol.derevo2t);
	gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.derevo2->sizeX,TeSt.pol.derevo2->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.derevo2->data);
	  glGenTextures(1, &TeSt.pol.ledt);
	  glBindTexture(GL_TEXTURE_2D,TeSt.pol.ledt); 
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.led->sizeX,TeSt.pol.led->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.led->data);
	glGenTextures(1, &TeSt.pol.plitkat);
	glBindTexture(GL_TEXTURE_2D,TeSt.pol.plitkat);
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.plitka->sizeX,TeSt.pol.plitka->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.plitka->data);
	  glGenTextures(1, &TeSt.pol.ext);
	  glBindTexture(GL_TEXTURE_2D,TeSt.pol.ext);
      gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.pol.ex->sizeX,TeSt.pol.ex->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.pol.ex->data);
	glGenTextures(1, &TeSt.sten.steklot[0]);
	glBindTexture(GL_TEXTURE_2D,TeSt.sten.steklot[0]);
	gluBuild2DMipmaps(GL_TEXTURE_2D,3, TeSt.sten.steklo[0]->sizeX,TeSt.sten.steklo[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE,TeSt.sten.steklo[0]->data);
}
void CALLBACK mihka(void )
{
	int rx,ry,ra;
	for(i=dlina-1;i>0;i--)
	{
		if(mous.x2[i-1]!=-1)mous.x2[i]=mous.x2[i-1];
		if(mous.y2[i-1]!=-1)mous.y2[i]=mous.y2[i-1];
	}
	mous.x2[0]=mous.x;
	mous.y2[0]=mous.y;
	if(mous.x2[1]!=-1)
	{
    rx=mous.x2[0]-mous.x2[1];
	ry=mous.y2[0]-mous.y2[1];
	if(abs(rx)>abs(ry))
	{if(abs(rx-ry)>abs(mous.vs))mous.vs=rx-ry;
	 if(abs(rx-ry)<abs(mous.vs))mous.vs=mous.vs-(mous.vs-abs(rx-ry))/100;
	}
	if(abs(rx)<abs(ry))
	{if(abs(ry-rx)>abs(mous.vs))mous.vs=ry-rx;
	 if(abs(ry-rx)<abs(mous.vs))mous.vs=mous.vs-(mous.vs-abs(ry-rx))/100;
	}
	if(abs(rx)==abs(ry))mous.vs=mous.vs-(mous.vs-abs(rx))/100;
	mous.ugl+=mous.vs;
	}
	for(i=0;i<dlina;i++)
	{
	glPushMatrix();
	glTranslated(-10*(float)(mous.x2[i])/ek.w+5,-10*(float)(mous.y2[i])/ek.h+5,-1);
	glRotated(mous.ugl,0,0,1);
	glLineWidth(1);     
    glBegin(GL_LINES);
      glColor3d(1,0,0);   
      glVertex3d(0,0,0); 
      glVertex3d(-0.1,0,0); 
      glVertex3d(0,0,0); 
      glVertex3d(0.1,0,0);
	  glVertex3d(0,0,0); 
      glVertex3d(0,-0.1,0);
	  glVertex3d(0,0,0); 
      glVertex3d(0,0.1,0);
    glEnd();
	//auxSolidSphere(0.1);
	glPopMatrix();
	}
	glColor3d(1,1,1);
}
void init(void)
{
	//lo3d(&zelov[0],"boss_g1.3ds");
	lo3d(&zelov[0],"image/3df/zel.3ds","image/3df/zel.3dk");
	lo3d(&zelov[1],"image/3df/zel2.3ds","image/3df/zel2.3dk");
	lo3d(&zelov[2],"image/3df/zel3.3ds","image/3df/zel3.3dk");
	lo3d(&granat,"image/3df/gran.3ds","image/3df/gran.3dk");
	mous.x=-12397; mous.y=-12397;
	for(i=0;i<50;i++)
		for(j=0;j<50;j++)
		{
			kar.t[i][j]=malloc(sizeof(struct infkart));
            kar.t[i][j]->t[0].x=0;
			kar.t[i][j]->t[0].y=0;
			kar.t[i][j]->t[0].z=0;

			kar.t[i][j]->t[1].x=5;
			kar.t[i][j]->t[1].y=0;
			kar.t[i][j]->t[1].z=0;

			kar.t[i][j]->t[2].x=5;
			kar.t[i][j]->t[2].y=5;
			kar.t[i][j]->t[2].z=0;
			kar.t[i][j]->next=malloc(sizeof(struct infkart));
			kar.t[i][j]->next->t[0].x=0;						
			kar.t[i][j]->next->t[0].y=0;
			kar.t[i][j]->next->t[0].z=0;

			kar.t[i][j]->next->t[1].x=0;						
			kar.t[i][j]->next->t[1].y=5;
			kar.t[i][j]->next->t[1].z=0;

			kar.t[i][j]->next->t[2].x=5;						
			kar.t[i][j]->next->t[2].y=5;
			kar.t[i][j]->next->t[2].z=0;

			kar.t[i][j]->next->next=0;
		}
	for(i=0;i<dlina;i++)
	{
		mous.x2[i]=-1;
		mous.y2[i]=-1;
	}
	for(i=0;i<30;i++)
	{
	  pt[i].tr=false;
	  vl[i].tr=false;
	}
	orug[0].vrem=100;
	orug[0].sk=10;
	orug[0].r=1;
	orug[0].r2=0.1;
    orug[0].damag=2;
	orug[0].m=0.00001;

	orug[1].vrem=20;
	orug[1].sk=15;
	orug[1].r=1;
	orug[1].r2=0.2;
    orug[1].damag=10;
    orug[1].m=0.00001;

	orug[2].vrem=0;
	orug[2].sk=25;
	orug[2].r=1;
	orug[2].r2=0.05;
    orug[2].damag=20;
	orug[2].m=0.0000001;

	orug[3].vrem=700;
	orug[3].sk=4;
	orug[3].r=30;
    orug[3].r2=1.5;
	orug[3].damag=10;
	orug[3].m=200;

	orug[4].vrem=900;
	orug[4].sk=5;
	orug[4].r=20;
	orug[4].r2=1;
    orug[4].damag=33;
	orug[4].m=100;
	plmn=1;
	vihod=0;
	rasmx=rasmerx;
    rasmy=rasmery;
	strcpy(load,loader);
	anim[0]=-1;anim[2]=-1;
	anim[1]=-1;anim[3]=-1;
	EnterK=0;
	kar.z=0;
	kar.ugl=0;
	kar.ugl2=0;
	zel.no=1;
	zel.z=0;
	zel.orugie[0]=1000;
	zel.orugie[1]=100;
	zel.orugie[2]=70;
    zel.orugie[3]=60;
	zel.orugie[4]=50;
	zel.zamed=1;
	zel.koek=1;
	zel.tulu=0;
	zel.rk11u=0;
	zel.rk12u=0;
	zel.rk21u=0;
	zel.rk22u=0;
	zel.rk11u2=0;
	zel.rk21u2=0;
    zel.ng11u=0;
	zel.ng21u=0;
	zel.ng12u=0;
	zel.ng22u=0;
	zel.ng11u2=0;
	zel.ng21u2=0;
	zel.hp2=0;
    for(i=0;i<kolvr;i++)
	{
		vr[i].no=0;
		vr[i].orugie[0]=100;
		vr[i].hp2=1;
		vr[i].z=0;
     	vr[i].koek=1;
    	vr[i].tulu=0;
    	vr[i].rk11u=0;
		vr[i].rk12u=0;
		vr[i].rk21u=0;
		vr[i].rk22u=0;
		vr[i].rk11u2=0;
		vr[i].rk21u2=0;
	    vr[i].ng11u=0;
		vr[i].ng21u=0;
		vr[i].ng12u=0;
		vr[i].ng22u=0;
		vr[i].ng11u2=0;
		vr[i].ng21u2=0;
		vr[i].ugl=0;
		vr[i].x=randoms(0,100)+20;
		vr[i].y=randoms(0,100)+20;
		vr[i].vrPad=0;
		vr[i].hp=100;
	}
	UpDown=1;
	vrema=-1;
	mous.enter=0;
}
void CALLBACK resize(int width,int height)
{
   glViewport(0,0,width,height);
   ek.w=width;
   ek.h=height;
   glMatrixMode( GL_PROJECTION );
   glLoadIdentity();
   glOrtho(-5,5,-5,5,2,12);
    gluLookAt(0,0.0001,-0.1,0,0,0,0,1,0);
   glMatrixMode( GL_MODELVIEW );
}
void CALLBACK Rasvorot(AUX_EVENTREC *event)
{
	if(plmn==1)
	{
    mous.x=event->data[AUX_MOUSEX];
    mous.y=event->data[AUX_MOUSEY];
	}
}
void CALLBACK vistrel(void)
{
  struct timeb tstruct;
  static short int ma=0,ma2;
  ftime(&tstruct); 
  ma2=tstruct.millitm;
  if(ma2<ma)ma2=ma2+1000;
 if((plmn==0)&&(mous.enter==1)&&(zel.orugie[zel.no]>0)&&(ma2-ma>orug[zel.no].vrem))
 {
 for(i=0;i<30;i++)
 {
	 if(pt[i].tr==false)
	 {
		 float vv;
	   ma=tstruct.millitm;
       zel.orugie[zel.no]--;
	   pt[i].tr=true;
	   pt[i].t=0;
	   pt[i].x=kar.x;
	   pt[i].y=kar.y;
	   //vv=;
	   if(vv<0)vv=-vv;
	   pt[i].z=zel.z+4.8+sin(kar.ugl2*3.14/180);
	   pt[i].ugl=kar.ugl;
	   pt[i].ugl2=kar.ugl2;
	   pt[i].vid=zel.no;
	   break;
	 }
 }
 }
}
void CALLBACK Enter(AUX_EVENTREC *event)
{
 mous.enter=1;
}
void CALLBACK Enter2(AUX_EVENTREC *event)
{
 mous.enter=0;
}
void CALLBACK left(void)
{
  kar.ugl-=6;
  if(kar.ugl<-360)kar.ugl=kar.ugl+360;
}
void CALLBACK right(void)
{  
  kar.ugl+=6;
  if(kar.ugl>360)kar.ugl=kar.ugl-360;
}
int trunc(float a)
{
	int b,c;
	c=(int)a;
	if(c-a>=0)b=c-1;
	if(c-a<0)b=c;
	return b;
}
/*void sdvr(void)
{
	struct timeb tstruct;
	static short int ma=0,ma2;
	ftime(&tstruct); 
		ma2=tstruct.millitm;
	    if(ma2<ma)ma2=ma2+1000;
	for(i=0;i<kolvr;i++)
	if(vihod==0)
	{
		if((ma2-ma>20)&&(vr[i].hp>0))
		{
			if(i==kolvr-1)ma=tstruct.millitm;
		 float rast;
		     vr[i].x-=sin(vr[i].ugl*3.14/180)/5;
             vr[i].y+=cos(vr[i].ugl*3.14/180)/5;
			 rast=sqrt((vr[i].x-kar.x)*(vr[i].x-kar.x)+(vr[i].y-kar.y)*(vr[i].y-kar.y)+(vr[i].z-zel.z)*(vr[i].z-zel.z));
			 if(rast<2.5)
			 {
				 int uglo=45;
			   vr[i].x+=sin(vr[i].ugl*3.14/180)/3;
               vr[i].y-=cos(vr[i].ugl*3.14/180)/3;
		       //vr[i].ugl=vr[i].ugl+random(0,360)-180;
			   zel.hp-=5;
			   vr[i].hp-=2;
			   rast=sqrt((vr[i].x-kar.x)*(vr[i].x-kar.x)+(vr[i].y-kar.y)*(vr[i].y-kar.y));
			   if(sin((vr[i].x-kar.x)/rast)>=0)
			     if(cos((vr[i].x-kar.x)/rast)<=0)uglo+=90;
			   if(sin((vr[i].x-kar.x)/rast)<0)
			   {
			     if(cos((vr[i].x-kar.x)/rast)<=0)uglo+=180;
				 if(cos((vr[i].x-kar.x)/rast)>0)uglo+=270;
			   }
			   vr[i].ugl=uglo;
			   //vr[i].ugl=arcsin((vr[i].x-kar.x)/rast;
			   vr[i].rk11u2=-90;
               vr[i].rk21u2=-90;
			 }else
			 {
				 if(vr[i].rk11u2==-90){vr[i].rk11u2=0;vr[i].ng11u2=0;vr[i].ng21u2=0;}
                 if(vr[i].rk21u2==-90)vr[i].rk21u2=0;
			 }
		vr[i].ik=trunc(vr[i].x/15);
		vr[i].jk=trunc(vr[i].y/15);
		{
			int h1=0,h2=0,h3=0,h4=0;
					h4=kar.mas[vr[i].ik][vr[i].jk].h;
					if(vr[i].jk-1>=0)h1=kar.mas[vr[i].ik][vr[i].jk-1].h;
					if((vr[i].jk-1>=0)&&(vr[i].ik+1<rasmx))h2=kar.mas[vr[i].ik+1][vr[i].jk-1].h;
					if(vr[i].ik+1<rasmx)h3=kar.mas[vr[i].ik+1][vr[i].jk].h;
					{
						float x0,y0,z0=0;
						x0=vr[i].x-vr[i].ik*15;
						y0=vr[i].y-vr[i].jk*15;
						if(x0<y0)z0=(x0*(15*h4-15*h3)+y0*(15*h1-15*h4)-225*h1)/225;
						if(x0>=y0)z0=(-x0*(15*h2-15*h1)-y0*(15*h3-15*h2)-225*h1)/225;
						if(z0-vr[i].z<=0.1){vr[i].z-=9.8*vr[i].vrPad/100;vr[i].vrPad+=5;}
						if(z0-vr[i].z>=0.1){vr[i].z+=z0-vr[i].z;vr[i].vrPad=0;}
						if((z0-vr[i].z<0.1)&&(z0-vr[i].z>-0.1)){vr[i].z+=z0-vr[i].z;vr[i].vrPad=0;}					
					}
		}
      vr[i].rk11u2+=vr[i].koek*3;
      vr[i].rk21u2-=vr[i].koek*3;
      vr[i].ng11u2+=vr[i].koek*3;
      vr[i].ng21u2-=vr[i].koek*3;	
      if(vr[i].rk11u2>40)vr[i].koek=-vr[i].koek;
      if(vr[i].rk11u2<-40)vr[i].koek=-vr[i].koek;
	  if((vr[i].hp<=0)&&(vr[i].hp2==true))
			   {
		           vr[i].hp2=false;
				   vr[i].z-=2;
				   	vr[i].tulu=90;
			        vr[i].ng11u=90;
			        vr[i].ng21u=90;
					vr[i].ng11u2=randoms(0,70)-10;
					vr[i].ng21u2=randoms(0,70)-10;
			        vr[i].ng12u=90;
			        vr[i].ng22u=90;
					vr[i].rk11u=randoms(0,90);
					vr[i].rk21u=randoms(0,90);
					vr[i].rk12u=30;
					vr[i].rk11u2=randoms(0,45)-90;
					vr[i].rk21u2=randoms(0,45)-90;
			   }
	}
	  glPushMatrix();
	  glTranslated(vr[i].x-kar.x,0,vr[i].y-kar.y);
	  glRotated(-vr[i].ugl,0,1,0);
	  glTranslated(0,vr[i].z-zel.z,0);
	  zelovek(vr[i]);
	  glPopMatrix();
	}
}
int vsriv(int i,int j,int ok,int d2)
{
	float rast,rast2,x,y,z,hp;
	BOOL hp2;
	if(j<kolvr){x=vr[j].x;y=vr[j].y;z=vr[j].z;hp=vr[j].hp;hp2=vr[j].hp2;}
	else{x=kar.x;y=kar.y;x=zel.z;hp=zel.hp;hp2=zel.hp2;}
	rast=sqrt((x-pt[i].x)*(x-pt[i].x)+(y-pt[i].y)*(y-pt[i].y));
			 rast2=sqrt((x-pt[i].x)*(x-pt[i].x)+(y-pt[i].y)*(y-pt[i].y)+(z-pt[i].z)*(z-pt[i].z));
			 if((rast<3)&&(pt[i].z>z)&&(pt[i].z<z+5)&&(hp>0)&&(ok==0)||
				(rast2<orug[pt[i].vid].r)&&(hp>0)&&(ok==1))
			 {
				 if((orug[pt[i].vid].r<=1)&&(j<kolvr))hp-=orug[pt[i].vid].damag;			
			   if((hp<=0)&&(hp2==true))
			   {
				   hp2=false;
				   hp=0;
				   z-=2;
				   if(j<kolvr)
				   {
				   	vr[j].tulu=90;
			        vr[j].ng11u=90;
			        vr[j].ng21u=90;
					vr[j].ng11u2=randoms(0,70)-10;
					vr[j].ng21u2=randoms(0,70)-10;
			        vr[j].ng12u=90;
			        vr[j].ng22u=90;
					vr[j].rk11u=randoms(0,90);
					vr[j].rk21u=randoms(0,90);
					vr[j].rk12u=30;
					vr[j].rk11u2=randoms(0,45)-90;
					vr[j].rk21u2=randoms(0,45)-90;
				   }
			   }
			   if((d2==0)&&(orug[pt[i].vid].r>1))
			   {
		        for(j=0;j<30;j++)
				{ 
                if(vl[j].tr==false)
				{
			      vl[j].x=pt[i].x;
			      vl[j].y=pt[i].y;
			      vl[j].z=pt[i].z;
			      vl[j].r=0;
			      vl[j].rmax=orug[pt[i].vid].r;
				  vl[j].damag=orug[pt[i].vid].damag;
			      vl[j].tr=true;
	              break;
				}
				}
			   }
			   ok=1;
			 }
	if((d2==-1)&&(orug[pt[i].vid].r>1))
	{
		for(j=0;j<30;j++)
		   { 
             if(vl[j].tr==false)
			 {
			   vl[j].x=pt[i].x;
			   vl[j].y=pt[i].y;
			   vl[j].z=pt[i].z;
			   vl[j].r=0;
			   vl[j].rmax=orug[pt[i].vid].r;
			   vl[j].damag=orug[pt[i].vid].damag;
			   vl[j].tr=true;
	           break;
			 }
		   }
	}
	if(j<kolvr){vr[j].hp=hp;vr[j].hp2=hp2;}
	else zel.hp=hp;
  return ok;
}
void volna(void)
{
	 GLUquadricObj *quadObj; 
     quadObj = gluNewQuadric(); 
	struct timeb tstruct;
	static short int ma=0,ma2;
	ftime(&tstruct); 
	ma2=tstruct.millitm;
	if(ma2<ma)ma2=ma2+1000;
	glColor3d(1,0,0);
	for(i=0;i<30;i++) 
	{
	  if((vl[i].tr==true)&&(ma2-ma>20))
	  {
		  int rast;
		  float kok;
		  kok=1;
		  for(j=0;j<6;j++)
		  {
		  vl[i].r+=1;
		  if(vl[i].r>vl[i].rmax)break;
			  kok++;
		  }
		  kok=kok/1.5;
		  if(vl[i].r>vl[i].rmax)vl[i].tr=false;
		  for(j=0;j<kolvr+1;j++)
		  {
			  if(j<kolvr)rast=sqrt((vr[j].x-vl[i].x)*(vr[j].x-vl[i].x)+(vr[j].y-vl[i].y)*(vr[j].y-vl[i].y)+(vr[j].z-vl[i].z)*(vr[j].z-vl[i].z));
			  if(j==kolvr)rast=sqrt((kar.x-vl[i].x)*(kar.x-vl[i].x)+(kar.y-vl[i].y)*(kar.y-vl[i].y)+(zel.z-vl[i].z)*(zel.z-vl[i].z));
		  if((j<kolvr)&&(rast<=vl[i].r)&&(vl[i].rmax>1)&&(vr[j].hp2==true))vr[j].hp-=vl[i].damag;			
		  if((rast<=vl[i].r)&&(vl[i].rmax>1)&&(j==kolvr))zel.hp-=vl[i].damag;			
			   if((j<kolvr)&&(vr[j].hp<=0)&&(vr[j].hp2==true))
			   {
				   vr[j].hp2=false;
				   vr[j].hp=0;
				   vr[j].z-=2;
				   	vr[j].tulu=90;
			        vr[j].ng11u=90;
			        vr[j].ng21u=90;
					vr[j].ng11u2=randoms(0,70)-10;
					vr[j].ng21u2=randoms(0,70)-10;
			        vr[j].ng12u=90;
			        vr[j].ng22u=90;
					vr[j].rk11u=randoms(0,90);
					vr[j].rk21u=randoms(0,90);
					vr[j].rk12u=30;
					vr[j].rk11u2=randoms(0,45)-90;
					vr[j].rk21u2=randoms(0,45)-90;
			   }
		  }
	  }
	  if((i==29)&&(ma2-ma>20))ma=tstruct.millitm;
	  if(vl[i].tr==true)
	  {
		  glPushMatrix();
	        glTranslated(vl[i].x-kar.x,0,vl[i].y-kar.y);
	        glTranslated(0,vl[i].z-zel.z,0);
			gluQuadricDrawStyle(quadObj,GLU_POINT);
            gluSphere(quadObj,vl[i].r, vl[i].r*10,vl[i].r*10); 
			
	     glPopMatrix();
	  }
	}
	glColor3d(1,1,1);
}
void pula(void)
{
	GLUquadricObj *quadObj; 
	int k=0;
	struct timeb tstruct;
	static short int ma=0,ma2;
	int ik,jk;
	quadObj = gluNewQuadric(); 
    gluQuadricTexture(quadObj, GL_TRUE);
    gluQuadricDrawStyle(quadObj, GLU_FILL); 
	ftime(&tstruct); 
		ma2=tstruct.millitm;
	    if(ma2<ma)ma2=ma2+1000;
	for(i=0;i<30;i++)
		for(k=0;k<orug[pt[i].vid].sk;k++)
	{
	if((vihod==0)&&(pt[i].tr==true))
	{
		if(ma2-ma>20)
		{
			int ok=0;
			if(i==30-1)ma=tstruct.millitm;
		     pt[i].x-=sin(pt[i].ugl*3.14/180);
             pt[i].y+=cos(pt[i].ugl*3.14/180);
			 pt[i].z+=sin(pt[i].ugl2*3.14/180)-pt[i].t*((orug[pt[i].vid].m*9.8)/1000);
			 pt[i].t+=0.01;
			 if((pt[i].x<0)||(pt[i].y<0)||(pt[i].x>rasmx*15)||(pt[i].y>rasmy*15))pt[i].tr=false;
			 for(j=0;j<kolvr+1;j++)
			 {
				 int ok2;
			   ok2=vsriv(i,j,ok,ok);
			   if((ok==0)&&(ok2==1))j=1;
			   ok=ok2;
			 }
			 if(ok==1)pt[i].tr=false;
		ik=trunc(pt[i].x/15);
		jk=trunc(pt[i].y/15);
		{
			int h1=0,h2=0,h3=0,h4=0;
					h4=kar.mas[ik][jk].h;
					if(jk-1>=0)h1=kar.mas[ik][jk-1].h;
					if((jk-1>=0)&&(ik+1<rasmx))h2=kar.mas[ik+1][jk-1].h;
					if(ik+1<rasmx)h3=kar.mas[ik+1][jk].h;
					{
						struct masivo masi;
                        masi=prover_zel(ik,jk,pt[i].x,pt[i].y,pt[i].z);
		 				float x0,y0,z0=0;
						x0=pt[i].x-ik*15;
						y0=pt[i].y-jk*15;
						if(x0<y0)z0=(x0*(15*h4-15*h3)+y0*(15*h1-15*h4)-225*h1)/225;
						if(x0>=y0)z0=(-x0*(15*h2-15*h1)-y0*(15*h3-15*h2)-225*h1)/225;
						if((z0-pt[i].z>0)){int kk=-1;
							 for(j=0;j<kolvr;j++)
							  kk=vsriv(i,j,1,kk);
							pt[i].tr=false;
						}
						{
							int kk=-1;
						for(j=0;j<12;j++)
                 		  if(masi.mas[j]==1)
						  if((pt[i].z<z0+15))
						  {
							  for(j=0;j<kolvr+1;j++)
							  kk=vsriv(i,j,1,kk);
							  pt[i].tr=false;break;
						  }
						}
					}
		}	
	}
	  glPushMatrix();
	  glTranslated(pt[i].x-kar.x,0,pt[i].y-kar.y);
	  glRotated(-pt[i].ugl,0,1,0);
	  glTranslated(0,pt[i].z-zel.z,0);
	  if(pt[i].vid==0){glColor3d(1,1,1);auxSolidSphere(orug[pt[i].vid].r2);}
	  if(pt[i].vid==1){glColor3d(1,1,1);auxSolidSphere(orug[pt[i].vid].r2);}
	  if(pt[i].vid==2){glColor3d(1,0,0);auxSolidSphere(orug[pt[i].vid].r2);}
	  if(pt[i].vid==3)
	  {
		  glPushMatrix();
		  glEnable(GL_TEXTURE_2D);
	      glBindTexture(GL_TEXTURE_2D,orug[3].pult);
		  glColor3d(0.7,0.7,0.7);
		  glRotated(-90,1,0,0);
		  gluSphere(quadObj,orug[pt[i].vid].r2,20,20);
		  //auxSolidSphere(orug[pt[i].vid].r2);
		  glDisable(GL_TEXTURE_2D);
		  glPopMatrix();
	  }
	  if(pt[i].vid==4){glColor3d(1,1,0);auxSolidSphere(orug[pt[i].vid].r2);}
	  glColor3d(1,1,1);
	  glPopMatrix();
	}
	}
}*/
void CALLBACK up(void)
{ 
	if(vihod==0)
	{
		float rast;
    	UpDown=1;
    	vrema=0;
  kar.x-=sin(kar.ugl*3.14/180);
  kar.y+=cos(kar.ugl*3.14/180);
  for(i=0;i<kolvr;i++)
  {
  rast=sqrt((vr[i].x-kar.x)*(vr[i].x-kar.x)+(vr[i].y-kar.y)*(vr[i].y-kar.y)+(vr[i].z-zel.z)*(vr[i].z-zel.z));
  if((rast<1.5)&&(vr[i].hp>0))
  {
   kar.x+=sin(kar.ugl*3.14/180);
   kar.y-=cos(kar.ugl*3.14/180);
  }
  }
  zel.rk11u2=-90;
  zel.rk21u2=-90;
	}
}
void CALLBACK down(void)
{
	if(vihod==0)
	{
	float rast;
	UpDown=-1;
	vrema=0;
  kar.x+=sin(kar.ugl*3.14/180);
  kar.y-=cos(kar.ugl*3.14/180);
  for(i=0;i<kolvr;i++)
  {
  rast=sqrt((vr[i].x-kar.x)*(vr[i].x-kar.x)+(vr[i].y-kar.y)*(vr[i].y-kar.y)+(vr[i].z-zel.z)*(vr[i].z-zel.z));
  if((rast<1.5)&&(vr[i].hp>0))
  {
   kar.x-=sin(kar.ugl*3.14/180);
   kar.y+=cos(kar.ugl*3.14/180);
  }
  }
  zel.rk11u2=-90;
  zel.rk21u2=-90;
}
}
void CALLBACK priset(void)
{ 
  EnterK=1;
}
void CALLBACK prisok(void)
{
	int k,v=0;
	for(k=0;k<3;k++)
		if(anim[k]!=-1)v=1;
	if((anim[1]==-1)&&(v==0))anim[1]=0;
}
void animasia()
{
	static short int m=0,m2,ma=0,ma2;
	struct timeb tstruct;
    ftime(&tstruct); 
	m2=tstruct.millitm;
	if(m2<m)m2=m2+1000;
	if((vrema!=-1)&&(m2-m>200)){ vrema++;m=tstruct.millitm;}
	if(vrema>=2)
	{
		vrema=-1;
		UpDown=0;
	}
	if(vrema==-1)
	{
	   //if(zel.rk11u2>0)zel.rk11u2-=2;
	   //if(zel.rk11u2<0)zel.rk11u2+=2;
	   //if(zel.rk21u2>0)zel.rk21u2-=2;
	   //if(zel.rk21u2<0)zel.rk21u2+=2;
	   if(zel.ng11u2>0)zel.ng11u2-=2;
	   if(zel.ng11u2<0)zel.ng11u2+=2;
	   if(zel.ng21u2>0)zel.ng21u2-=2;
	   if(zel.ng21u2<0)zel.ng21u2+=2;
	}
	ma2=tstruct.millitm;
	if(ma2<ma)ma2=ma2+1000;
	if((anim[0]!=-1)&&(ma2-ma>20*zel.zamed))
	{
     ma=tstruct.millitm;
	 if(anim[0]==0){zel.tulu+=1;}
	 if(anim[0]==1){zel.tulu-=1;}
	 if((zel.tulu>=70)&&(anim[0]==0))anim[0]=1;
	 if((zel.tulu<=0)&&(anim[0]==1)){anim[0]=-1;zel.tulu=0;}
	}
	if((anim[1]!=-1)&&(ma2-ma>20*zel.zamed))
	{
	   ma=tstruct.millitm;
	   vrema=0;
	   kar.x-=UpDown*2*sin(kar.ugl*3.14/180);
       kar.y+=UpDown*2*cos(kar.ugl*3.14/180);
	   if(zel.rk11u2>0)zel.rk11u2-=1;
	   if(zel.rk11u2<0)zel.rk11u2+=1;
	   if(zel.rk21u2>0)zel.rk21u2-=1;
	   if(zel.rk21u2<0)zel.rk21u2+=1;
	 if(anim[1]==0){zel.z+=1; zel.rk11u+=20;zel.rk21u+=20;zel.ng11u+=2;zel.ng21u+=2;
	     zel.ng11u2-=16;zel.ng12u+=16;zel.ng21u2-=16;zel.ng22u+=16;}
	 if(anim[1]==1){zel.z-=1; zel.rk11u-=20;zel.rk21u-=20;zel.ng11u-=2;zel.ng21u-=2;
	     zel.ng11u2+=16;zel.ng12u-=16;zel.ng21u2+=16;zel.ng22u-=16;}
	 if((zel.z>=znaz+5)&&(anim[1]==0))anim[1]=1;
	 if((zel.z<=znaz)&&(anim[1]==1)){anim[1]=-1;zel.z=znaz;
	  zel.rk11u=0;zel.rk21u=0;zel.ng11u=0;zel.ng21u=0;
	  zel.ng11u2=0;zel.ng12u=0;zel.ng21u2=0;zel.ng22u=0;}
	}
	if(anim[2]!=-1)
	{
		glPushMatrix();
		 glColor3ub(200,0,0);
		 glTranslated(0,15,0);
		if(anim[2]<15)auxSolidCylinder((float)anim[2]/5,15);
		if(anim[2]>=15)auxSolidCylinder( ( (30/5)-(float)anim[2]/5),15);
		glPopMatrix();
	}
}
void CALLBACK exitv(void)
{
	if(vihod==0)anim[2]=0;
	vihod=1;
}
void CALLBACK karta(int i,int j)
{
	struct infkart *p=kar.t[i][j];
	for(p=kar.t[i][j];p!=0;p=p->next)
	{
		glBegin(GL_TRIANGLES);
		  glVertex3d(p->t[0].x,p->t[0].z,p->t[0].y);
		  glVertex3d(p->t[1].x,p->t[1].z,p->t[1].y);
		  glVertex3d(p->t[2].x,p->t[2].z,p->t[2].y);
		glEnd();
	}
}
void CALLBACK play(void)
{
	int kkk=6;
	static int vrmg,vrmg2;
  struct masivo masi;
  float zz,xx,yy;
  int k,mas[4]={0,0,0,0};
  glMatrixMode( GL_PROJECTION );
   glLoadIdentity();   
   glFrustum(-5,5,-5,5,3,(kkk-1)*15);
   gluLookAt(0,0,0,0,-0.0001,0.1,0,1,0);
  glMatrixMode(GL_MODELVIEW);
	{
  	POINT mpos;
	GetCursorPos(&mpos);

     kar.ugl+=(float)((int)(mpos.x)-100)*skrolingx;
    kar.ugl2+=(float)((int)(mpos.y)-100)*skrolingy;
	//SetCursorPos((int)(ek.w/2),(int)(ek.h/2));
	 //kar.ugl2=90;
	 SetCursorPos(100,100);
     if(kar.ugl2<-55)kar.ugl2=-55;
     if(kar.ugl2>55)kar.ugl2=55;
	}
  glPushMatrix();
  /////////////////////////////��� hp
  glPushMatrix();
  glTranslated(5,5,3.1);
  {
	  int r,g=255;
	  r=255-(zel.hp-50)*5.1;
	  if(r>=255){g=255-(r-255);r=255;}
  glColor3ub(r,g,0);
  vrmg2=zel.hp/2;
  if(vrmg>=vrmg2)
  {
  auxSolidSphere(0.1);
  vrmg=-1;
  }else
  {
	  glColor3ub(100,100,100);
	  auxSolidSphere(0.1);
  }
  vrmg++;
  glColor3ub(r,g,0);
  }
  glTranslated(0.5,0,0);
  glBegin(GL_QUADS);     
      glVertex3d(0,0,0);
      glVertex3d(-(float)zel.hp/12,0,0);
      glVertex3d(-(float)zel.hp/12,0.5,0);
      glVertex3d(0,0.5,0);
  glEnd();
  glPopMatrix();
  ///////////////////////////////////��� �������
  glPushMatrix();
  glTranslated(5,5,3.1);
  {
	  int r,g=255;
	  r=255-(zel.orugie[0]-50)*5.1;
	  if(r>=255){g=255-(r-255);r=255;}
  glColor3ub(r,0,g);
  glTranslated(0.15,-0.2,0);
  glBegin(GL_QUADS);     
      glVertex3d(0,0,0);
      glVertex3d(-(float)zel.orugie[zel.no]/12,0,0);
      glVertex3d(-(float)zel.orugie[zel.no]/12,0.2,0);
      glVertex3d(0,0.2,0);
  glEnd();
  }
  glPopMatrix();
  /////��� �������
  glPushMatrix();
    glTranslated(0,0,3.1);
	//glRotated(90,1,0,0);
	if(vihod==0)
	{
	glLineWidth(3);     
    glBegin(GL_LINES);
      glColor3d(1,0,0);   
      glVertex3d(-0.1,0,0); 
      glVertex3d(-0.5,0,0); 

      glVertex3d(0.1,0,0); 
      glVertex3d(0.5,0,0);

	  glVertex3d(0,-0.1,0); 
      glVertex3d(0,-0.5,0);

	  glVertex3d(0,0.1,0); 
      glVertex3d(0,0.5,0);
    glEnd();
	glColor3d(1,1,1);
	glTranslated(0,-5,-1);
	zelovek(zel);
	}
  glPopMatrix();
  //�����
  glMatrixMode( GL_PROJECTION );
   glLoadIdentity();   
   glFrustum(-5,5,-5,5,3,(kkk-1)*15);
   //gluLookAt(0,0,0,0,-0.0001,0.1,0,1,0);
   {
	   float x,y,z;
   x=sin(-kar.ugl*3.14/180);
   y=cos(-kar.ugl*3.14/180);
   z=sin(kar.ugl2*3.14/180);//-0.0001;
   gluLookAt(0,0,0,x,z,y,0,1,0);
   }
  glMatrixMode(GL_MODELVIEW);
  //////////
  kar.z=-4.8;
  if(kar.x<0)kar.x+=1;
  if(kar.y<0)kar.y+=1;
  if(kar.x/15>rasmx)kar.x-=1;
  if(kar.y/15>rasmy)kar.y-=1;
  kar.ik=trunc(kar.x/5);
  kar.jk=trunc(kar.y/5);
  if(zel.hp<=0)exitv();
  //glTranslated(0,-(kar.ugl2)/10,0);
  glTranslated(0,kar.z,0);
  glTranslated(0,0,2);
    /*sdvr();
	vistrel();
	pula();
	volna();*/
	glTranslated(0,-zel.z,0);
	animasia();
	for(i=kar.ik-kkk;i<kkk+kar.ik;i++)
	for(j=kar.jk-kkk;j<kkk+kar.jk;j++)
		if((i>=0)&&(j>=0)&&(i<50)&&(j<50))
		{
			glPushMatrix();
			  glTranslated(i*5-kar.x,0,j*5-kar.y);
			  karta(i,j);
            glPopMatrix(); 
	}
  glPopMatrix();
  EnterK=0;
}
void CALLBACK loadKart(char *name)
{
	if(name!=0)
	{
/*		vihod=-1;
		anim[2]=0;
	//char s[30];
	FILE *fil;
	fil=fopen(name,"r");
	fscanf(fil,"%d",&rasmx);
	fscanf(fil,"%d",&rasmy);
	for(i=0;i<rasmx;i++)
		for(j=0;j<rasmy;j++)
		{
	      fscanf(fil,"%d",&kar.mas[i][j].c1);
		  fscanf(fil,"%d",&kar.mas[i][j].c2);
		  fscanf(fil,"%d",&kar.mas[i][j].c3);
		  fscanf(fil,"%d",&kar.mas[i][j].c4);
		  fscanf(fil,"%d",&kar.mas[i][j].p1);
		  fscanf(fil,"%d",&kar.mas[i][j].h);
		  //kar.mas[i][j].h=-10;
		  kar.mas[i][j].anim=-1;
		  kar.mas[i][j].dopinf=0;
		  if(kar.mas[i][j].p1==8)
		  {
			  kar.x=i*15+7;
			  kar.y=j*15+7;
			  vr[0].x=i*15+4;
			  vr[0].y=j*15+4;
			  zel.hp=100;
			  kar.ik=i;
              kar.jk=j;
		  }
		}
   fclose(fil);*/
	}
}
void CALLBACK kubik(float ras)
{
	  glBegin(GL_QUADS);     
        glTexCoord2d(0,0); glVertex3d(ras,-ras,-ras);
        glTexCoord2d(-1,0); glVertex3d(ras,-ras,ras);
        glTexCoord2d(-1,1); glVertex3d(ras,ras,ras);
        glTexCoord2d(0,1); glVertex3d(ras,ras,-ras);
	  glEnd();
	  glBegin(GL_QUADS);     
        glTexCoord2d(0,0); glVertex3d(ras,-ras,-ras);
        glTexCoord2d(1,0); glVertex3d(-ras,-ras,-ras);
        glTexCoord2d(1,1); glVertex3d(-ras,ras,-ras);
        glTexCoord2d(0,1); glVertex3d(ras,ras,-ras);
	  glEnd();
	  glBegin(GL_QUADS);     
        glTexCoord2d(0,0); glVertex3d(ras,-ras,ras);
        glTexCoord2d(-1,0); glVertex3d(-ras,-ras,ras);
        glTexCoord2d(-1,1); glVertex3d(-ras,ras,ras);
        glTexCoord2d(0,1); glVertex3d(ras,ras,ras);
	  glEnd();
	  glBegin(GL_QUADS);     
        glTexCoord2d(0,0); glVertex3d(-ras,-ras,ras);
        glTexCoord2d(-1,0); glVertex3d(-ras,-ras,-ras);
        glTexCoord2d(-1,1); glVertex3d(-ras,ras,-ras);
        glTexCoord2d(0,1); glVertex3d(-ras,ras,ras);
	  glEnd();
	  glDisable(GL_TEXTURE_2D);
}
void CALLBACK menu(void)
{
	static short int ma=0,ma2;
	struct timeb tstruct;
    ftime(&tstruct); 
	ma2=tstruct.millitm;
	if(ma2<ma)ma2=ma2+1000;
if(plmn!=0)
{
	static int ugl1=0,ugl2=0,ugl3=0;
    glMatrixMode( GL_PROJECTION );
       glLoadIdentity(); 
       glOrtho(-5,5,-5,5,2,18);
	   //glFrustum(-5,5,-5,5,2,18);
       gluLookAt(0,0.00001,-1,0,0,0,0,1,0);
    glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
    if((mous.x>2*(float)ek.w/5)&&(mous.x<3*(float)ek.w/5)&&(mous.y<3.5*(float)ek.h/10)&&(mous.y>2.5*(float)ek.h/10)&&(ma2-ma>10))
	{
		ugl1++;
		if(ugl1>360)ugl1=360-ugl1;
		if(mous.enter==1){init();loadKart(load);plmn=0;}
	}
	if((mous.x>2*(float)ek.w/5)&&(mous.x<3*(float)ek.w/5)&&(mous.y<8.5*(float)ek.h/10)&&(mous.y>7.5*(float)ek.h/10)&&(ma2-ma>10))
	{
		ugl3++;
		if(ugl3>360)ugl3=360-ugl1;
		if(mous.enter==1){exit(0);}
	}
	if(ma2-ma>10)
	{
	ma=tstruct.millitm;
    ugl2++;
	}
    glTranslated(0,0,3);
	glPushMatrix();
	  glTranslated(0,2,0);
	  glRotated(ugl1,0,1,0);
	  glEnable(GL_TEXTURE_2D);
	  glBindTexture(GL_TEXTURE_2D,ment[0]);
	  kubik(0.5);
	glPopMatrix();
	glPushMatrix();
	  glTranslated(0,-3,0);
	  glRotated(ugl3,0,1,0);
	  glEnable(GL_TEXTURE_2D);
	  glBindTexture(GL_TEXTURE_2D,exitot);
	  kubik(0.5);
	glPopMatrix();
	glPushMatrix();
	  glTranslated(0,4,0);
	  glRotated(ugl2,0,1,0);
	  glEnable(GL_TEXTURE_2D);
	  glBindTexture(GL_TEXTURE_2D,ment[1]);
	  kubik(0.5);
	glPopMatrix();
	mihka();
  glPopMatrix();
}
}
void CALLBACK display(void)
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); 
	if(plmn==0)play();
	if(plmn!=0)menu();
    auxSwapBuffers(); 
}
void CALLBACK plus(void)
{
	zel.no++;
	if(zel.no>=5)zel.no=0;
}
void CALLBACK minus(void)
{
	zel.no--;
	if(zel.no<0)zel.no=4;
}
int main(void)
{
float ambient[4] = {0.6, 0.6, 0.6, 1};
float pos[4] = {3,3,3,1};
float dir[3] = {0,0,0};
float color[4] = {0.3,0.3,0.3,1};
GLfloat mat_specular[] = {1,1,1,1};
ShowCursor(false);
    auxKeyFunc(97,left); 
	auxKeyFunc(100,right); 
	auxKeyFunc(119,up); 
	auxKeyFunc(115,down);
	auxKeyFunc('e',plus); 
	auxKeyFunc('q',minus);
	auxKeyFunc(AUX_RETURN,priset); 
	auxKeyFunc(AUX_SPACE,prisok); 
	auxMouseFunc(0,AUX_MOUSELOC,Rasvorot); 
	auxMouseFunc(AUX_LEFTBUTTON,AUX_MOUSEDOWN,Enter); 
	auxMouseFunc(AUX_LEFTBUTTON,AUX_MOUSEUP,Enter2); 
    auxInitPosition(0,0,1024,768);
    auxInitDisplayMode( AUX_RGB | AUX_DEPTH | AUX_DOUBLE );
    auxInitWindow( "Escape from prison" );
    auxIdleFunc(display);
    auxReshapeFunc(resize); 
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_BLEND);
	glEnable(GL_AUTO_NORMAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    init();
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, color);
    glLightfv(GL_LIGHT0, GL_POSITION, pos);
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, dir);
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_specular);
    //glMaterialf(GL_FRONT, GL_SHININESS, 128.0);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
	ZagrTextur();
	auxMainLoop(display);
	ShowCursor(TRUE);
	return 0;
}