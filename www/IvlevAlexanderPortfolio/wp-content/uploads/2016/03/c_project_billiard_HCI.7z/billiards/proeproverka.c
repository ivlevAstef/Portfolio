#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <MATH.h>
#include <sys/timeb.h>
#define silaTrenia 0.005
#define kol 20
#define kol2 20
#define kol3 20
#define dt 0.009
#define pi 3.14//159265
struct mih
{
  float ugl,ugl2;
  float x,y;
  float sila;
};
struct hariki
{
	float x,y,z,sk;
	float ugl,r;
};
struct bordur
{
	float x,y,dlina;
	float ugl;
};
struct pole
{
	float rx,ry;
	float x[kol3],y[kol3];
};
struct bordur bor[kol2];
struct mih mihka;
struct hariki har[kol];
struct pole pl;
int i,j,kolh,kolb,koll,ostalhar;
float nx,ny;
void init()
{
	int kolo;
	FILE *f=fopen("standart.bor","r");
	//FILE *f=fopen("Char-Z.bor","r");
	mihka.ugl=90;
    mihka.ugl2=0;
	fscanf(f,"%d",&kolo);
	fscanf(f,"%f",&pl.rx);
	fscanf(f,"%f",&pl.ry);
	kolb=kolo;
	for(i=0;i<kolo;i++)
	{
	  fscanf(f,"%f",&bor[i].x);
	  fscanf(f,"%f",&bor[i].y);
	  fscanf(f,"%f",&bor[i].dlina);
	  fscanf(f,"%f",&bor[i].ugl);
	}
	fscanf(f,"%d",&kolo);
	koll=kolo;
	for(i=0;i<kolo;i++)
	{
	  fscanf(f,"%f",&pl.x[i]);
	  fscanf(f,"%f",&pl.y[i]);
	}
	fscanf(f,"%d",&kolo);
	kolh=kolo;
for(i=0;i<kolh;i++)
{
	fscanf(f,"%f",&har[i].x);
	fscanf(f,"%f",&har[i].y);
	fscanf(f,"%f",&har[i].r);
	har[i].z=1.5;
	har[i].ugl=0;
	har[i].sk=0;
}
fclose(f);
nx=har[0].x;
ny=har[0].y;
mihka.sila=2;
ostalhar=kolh;
}
void CALLBACK Rasvorot(AUX_EVENTREC *event)
{
	float x2,y2;
  x2=event->data[AUX_MOUSEX]-mihka.x;
  y2=event->data[AUX_MOUSEX]-mihka.y;
  mihka.ugl=mihka.ugl+y2/2;
  mihka.ugl2=mihka.ugl2+x2/2;
}
void CALLBACK sila(AUX_EVENTREC *event)
{
  float x2,y2;
  int vv;
  if(mihka.sila!=0)
  {
  x2=event->data[AUX_MOUSEX]-mihka.x;
  y2=event->data[AUX_MOUSEX]-mihka.y;
  if(x2>=0)vv=1;
  if(x2<0)vv=-1;
  if(mihka.sila+vv*sqrt(x2*x2+y2*y2)/10<1)
  {
	  har[0].sk=mihka.sila;
	  nx=har[0].x;
	  ny=har[0].y;
	  har[0].ugl=mihka.ugl;
	  if(har[0].ugl<0)har[0].ugl=360+har[0].ugl;
	  mihka.sila=0;
  }
  if(mihka.sila!=0)mihka.sila+=vv*sqrt(x2*x2+y2*y2)/10;
  }
}
void CALLBACK Rasvorot2(AUX_EVENTREC *event)
{
mihka.x=event->data[AUX_MOUSEX];
mihka.y=event->data[AUX_MOUSEX];
}
void CALLBACK resize(int width,int height)
{
   glViewport(0,0,width,height);
   glMatrixMode( GL_PROJECTION );
   glLoadIdentity();
   glOrtho(-5,5,-5,5,2,12);
    gluLookAt(0,0.0001,-0.1,0,0,0,0,1,0);
   glMatrixMode( GL_MODELVIEW );
}
float abs2(float a)
{
	if(a<0)return -a;
	return a;
}
float otrazenieOtLine(float x,float y,float ugl,float dlina,float xx,float yy,float uglpol)
{
	BOOL udar=FALSE;
	float x2,y2,r,r2,r3;
	x2=x+sin(-ugl*pi/180)*dlina;
	y2=y+cos(-ugl*pi/180)*dlina;
	r=sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2));
	r2=sqrt((x-xx)*(x-xx)+(y-yy)*(y-yy));
	r3=sqrt((xx-x2)*(xx-x2)+(yy-y2)*(yy-y2));
	if((r<=r2+r3+dt/10+0.1)&&(r>=r2+r3-dt/10-0.1))udar=TRUE;
	if(udar==TRUE)
	{
		float ugl2=ugl;
		if(uglpol<0)uglpol=360+uglpol;
		if(ugl2<0)ugl2=360+ugl2;
		uglpol=ugl2+(ugl2-uglpol);
	}
	return uglpol;
}
float sqr(float a)
{
	return a*a;
}
float uglos(float rx,float ry)
{
	float ugl;
	if(ry!=0){
		if((ry>0)&&(rx>=0)) ugl=atan(rx/ry);//+pi/2.0;
		if((ry<0)&&(rx>=0)) ugl=pi+atan(rx/ry);//+pi/2.0;
		if((ry<0)&&(rx<0)) ugl=pi+atan(rx/ry);//+pi/2.0;
		if((ry>0)&&(rx<0)) ugl=2*pi+atan(rx/ry);//+pi/2.0;
		ugl=ugl*180/pi;}
	else 
	{ugl=-90;
	if(rx<0)ugl=90;}
	return ugl;
}
float udar(int i,int j)
{
	float ugx,ugy,sk1x,sk1y,sk2x,sk2y,rast,ugl,ugl2;
	float newsx1,newsy1,newsx2,newsy2,kast,vx,vy;
	{
	  float rast=sqrt(sqr(har[i].x-har[j].x)+sqr(har[i].y-har[j].y));
	  if(rast<har[i].r+har[j].r)
	  {
		  float koek=har[i].r+har[j].r-rast;
		  har[i].x+=koek*sin(-har[i].ugl*pi/180);
		  har[i].y+=koek*cos(-har[i].ugl*pi/180);
	  }
	}
    ugx=har[i].x-har[j].x;
	ugy=har[i].y-har[j].y;
	ugl=uglos(-ugx,ugy);
	ugl=ugl-90;
	vx=-har[i].sk*sin(-(har[i].ugl-90)*pi/180);
	vy=-har[i].sk*cos(-(har[i].ugl-90)*pi/180);
	sk1x=vx*cos(ugl*pi/180)+vy*sin(ugl*pi/180);
	sk1y=-vx*sin(ugl*pi/180)+vy*cos(ugl*pi/180);
	vx=-har[j].sk*sin(-(har[j].ugl-90)*pi/180);
	vy=-har[j].sk*cos(-(har[j].ugl-90)*pi/180);
	sk2x=vx*cos(ugl*pi/180)+vy*sin(ugl*pi/180);
	sk2y=-vx*sin(ugl*pi/180)+vy*cos(ugl*pi/180);
	kast=sk2y;
	sk2y=sk1y;
	sk1y=kast;
	newsx1=(sk1x*cos(ugl*pi/180)-sk1y*sin(ugl*pi/180));
	newsy1=-(sk1x*sin(ugl*pi/180)+sk1y*cos(ugl*pi/180));
    newsx2=(sk2x*cos(ugl*pi/180)-sk2y*sin(ugl*pi/180));
	newsy2=-(sk2x*sin(ugl*pi/180)+sk2y*cos(ugl*pi/180));
	har[i].ugl=uglos(newsx1,newsy1)+90;
	har[i].sk=sqrt(sqr(newsx1)+sqr(newsy1));
	har[j].ugl=uglos(newsx2,newsy2)+90;
	har[j].sk=sqrt(sqr(newsx2)+sqr(newsy2));
	har[i].sk-=har[i].sk*0.1;
    har[j].sk-=har[j].sk*0.1;
	/*har[i].x-=har[i].sk/2*sin(-har[i].ugl*pi/180);
	har[i].y-=har[i].sk/2*cos(-har[i].ugl*pi/180);
	har[j].x-=har[j].sk/2*sin(-har[i].ugl*pi/180);
	har[j].y-=har[j].sk/2*cos(-har[i].ugl*pi/180);*/
    return uglos(newsx1,newsy1);
}
void CALLBACK play(void)
{
	BOOL ok;
    float k;
	int vis[kol];
  glMatrixMode( GL_PROJECTION );
   glLoadIdentity();   
   glFrustum(-5,5,-5,5,10,200);
   {float x,y,z;
   gluLookAt(0,-5,40,0,0,0,0,1,0);
   }
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
    glTranslated(0,0,-80);
    glColor3ub(10,150,10);
    auxSolidBox(pl.rx,pl.ry,1);
	glPushMatrix();
	  glTranslated(0,0,-20);
      glColor3ub(0,150,150);
      auxSolidBox(200,160,1);
	glPopMatrix();
	ok=TRUE;
	for(i=0;i<kolh;i++)
	vis[i]=0;
	for(i=0;i<kolh;i++)
	{
		har[i].sk-=har[i].sk*dt;
		glColor3ub(255,0,0);
		if(i==0)glColor3ub(255,255,255);
	for(k=0;k<har[i].sk;k+=dt)
	{
		float masiv[kol],znaz,masiv2[kol];
		BOOL zahod;
		znaz=har[i].sk;
		zahod=FALSE;
		for(j=0;j<kolh;j++)
		{
			masiv[j]=0;
            masiv2[j]=0; 
			if((vis[i]==0)&&(vis[j]==0)&&(i!=j))
			{
			float rast=sqrt(sqr(har[i].x-har[j].x)+sqr(har[i].y-har[j].y));
			if(rast<=har[i].r+har[j].r){zahod=TRUE;masiv[j]=udar(i,j);masiv2[j]=har[i].sk;vis[j]=1;}
			har[i].sk=znaz;
			}
		}
			if(zahod==TRUE)
			{
			  for(j=1;j<kolh;j++)
			  {masiv[0]+=masiv[j];
			   masiv2[0]+=masiv2[j];}
			har[i].ugl=masiv[0];
			har[i].sk=masiv2[0];
			}
		har[i].x-=dt*sin(-har[i].ugl*pi/180);
		har[i].y-=dt*cos(-har[i].ugl*pi/180);
		for(j=0;j<koll;j++)
		{
			float rastoa;
			rastoa=sqrt( sqr(har[i].x-pl.x[j])+sqr(har[i].y-pl.y[j]) );
			if(rastoa<1.6)
				if(i!=0){har[i].x=-1000;har[i].sk=0;ostalhar--;}else{har[i].x=-1000;har[i].sk=0;}
		}
		if(har[i].sk>0.001)ok=FALSE;
		else har[i].sk=0;
		for(j=0;j<kolb;j++)
			har[i].ugl=otrazenieOtLine(bor[j].x,bor[j].y,bor[j].ugl,bor[j].dlina,har[i].x,har[i].y,har[i].ugl);
	glPushMatrix();
	  glTranslated(har[i].x,har[i].y,har[i].z);
	  auxSolidSphere(har[i].r);
	glPopMatrix();
	}
	glPushMatrix();
	  glTranslated(har[i].x,har[i].y,har[i].z);
	  auxSolidSphere(har[i].r);
	glPopMatrix();
	}
	if((ok==TRUE)&&(mihka.sila==0))
	{mihka.sila=2;
	if(har[0].x==-1000){har[0].x=nx;har[0].y=ny;}
	}
	glPushMatrix();
	if(mihka.sila!=0)
	{
	  glColor3ub(200,200,200);
	   glLineWidth(5);
	  glBegin(GL_LINES);
	    glVertex3d(har[0].x+sin(-mihka.ugl*pi/180)*mihka.sila,har[0].y+cos(-mihka.ugl*pi/180)*mihka.sila,1);
		glVertex3d(har[0].x+(20+mihka.sila)*sin(-mihka.ugl*pi/180),har[0].y+(20+mihka.sila)*cos(-mihka.ugl*pi/180),2);
	  glEnd();
	  glColor3ub(255,0,0);
	   glLineWidth(1);
	  glBegin(GL_LINES);
		glVertex3d(har[0].x-sin(-mihka.ugl*pi/180),har[0].y-cos(-mihka.ugl*pi/180),1);
		glVertex3d(har[0].x-(50)*sin(-mihka.ugl*pi/180),har[0].y-(50)*cos(-mihka.ugl*pi/180),2);
	  glEnd();
	}
	for(i=0;i<kolb;i++)
	{
		glColor3ub(100,100,100);
		glLineWidth(10);
	glBegin(GL_LINES);
	    glVertex3d(bor[i].x,bor[i].y,1);
		glVertex3d(bor[i].x+bor[i].dlina*sin(-bor[i].ugl*pi/180),bor[i].y+bor[i].dlina*cos(-bor[i].ugl*pi/180),1);
	glEnd();
	}
	for(i=0;i<koll;i++)
	{
		glColor3ub(0,0,0);
		glPushMatrix();
		  glTranslated(pl.x[i],pl.y[i],0.522);
		  auxSolidCone(1.6,0.01);
		glPopMatrix();
	}
	glPopMatrix();
  glPopMatrix();
}
void CALLBACK display(void)
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); 
	play();
    auxSwapBuffers(); 
}
int main(void)
{
float color[4] = {1,1,1,1};
float pos[4] = {-40,40,10,1};
	auxMouseFunc(AUX_LEFTBUTTON,AUX_MOUSELOC,Rasvorot); 
	auxMouseFunc(AUX_RIGHTBUTTON,AUX_MOUSELOC,sila); 
	auxMouseFunc(0,AUX_MOUSELOC,Rasvorot2); 
    auxInitPosition(0,0,1024,768);
    auxInitDisplayMode( AUX_RGB | AUX_DEPTH | AUX_DOUBLE );
    auxInitWindow( "builard" );
    auxIdleFunc(display);
    auxReshapeFunc(resize); 
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_BLEND);
	glEnable(GL_AUTO_NORMAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, color);
    glLightfv(GL_LIGHT0, GL_POSITION, pos);
	init();
	//glLightModelfv(GL_LIGHT_MODEL_AMBIENT, color);	
	auxMainLoop(display);
	ShowCursor(TRUE);
	return 0;
}