//
//  DestroyLine.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PhysicItem.h"

class LineP: public PhysicItem
{
private:
	static const float angularDamping = 0.02f;
	static const float density = 1.0f;
	static const float friction = 0.3f;
	static const float restitution = 0.2f;
	static const float mass = 2.5f;
	static const float I = 0.01f;
	
	b2Body* line;
public:
	LineP(b2World* world,float x,float y,float x2,float y2);
	LineP(b2World* world,float x,float y,float width,float height,float angle,b2BodyType);
	~LineP();
	
	virtual b2Body* getPhysic(){ return line;}
	virtual void setParent(void* data){ line->SetUserData(data);}
	
	virtual b2Vec2 getPosition()
	{
		b2Vec2 vec= line->GetPosition();
		vec *= PTM_RATIO;
		return vec;
	}
	virtual float getAngle(){ return line->GetAngle();}
};

