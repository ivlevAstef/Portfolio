//
//  DestroyLine.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "LineP.h"

class DestroyLine: public Item {
private:
	LineP* line; 
public:
	DestroyLine(CCLayer* layer,b2World* world,float x,float y,float x2,float y2);
	~DestroyLine();
	
	virtual void update(float dt);
	virtual void draw(){}
	virtual void collision(Item* item2);
	
	static const std::string getNameStatic(){return "DestroyLine"; }
	virtual const std::string getName(){return getNameStatic(); }
};
