//
//  Polka2.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Polka2.h"

Polka2::Polka2(CCLayer* layer,b2World* world, float x, float y)
{                                                           
	view = new ItemView(layer,@"polka2.png",2);              
	
	polka = new PolkaP(world,x,y,view->getWidth()/2,view->getHeight()/2,0,0,1);
	
	polka->setParent((void*)this);                          
}                                                           

Polka2::~Polka2()                                             
{                                                           
	delete polka;                                           
	delete view;                                            
}                                                           

void Polka2::draw()                                          
{                                                           
                                                     
}                                                           

void Polka2::update(float dt)                                
{                                                           
	if (NULL == view || NULL == polka)                      
		return;                                             
	b2Vec2 pos = polka->getPosition();                      
	view->setPosition(pos.x, pos.y);                        
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(polka->getAngle()));
}  