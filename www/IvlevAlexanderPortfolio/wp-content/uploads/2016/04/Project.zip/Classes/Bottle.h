//
//  Bottle.h
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "LineP.h"

class Bottle: public Item {
private:
	LineP* box;
	ItemView* view;
public:
	Bottle(CCLayer* layer,b2World* world,float x,float y);
	~Bottle();
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Bottle"; }
};