//
//  MenuScene.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "GameScene.h"
#import "NextLevelMenu.h"
#import "VandalAppDelegate.h"
//#import "Scores.h"
//#import "About.h"
//#import "LevelMenu.h"
#import "SoundUtils.h"


@implementation NextLevelMenu
- (id) initWithDeddy:(GameScene*) _deddy
{
    if ((self = [super initWithColor: ccc4( 0, 0, 0, 60)])) {

	
		deddy=_deddy;		

		
		CCSprite* sprite = [CCSprite spriteWithFile:@"winmenu2.png"];
		
		[self addChild:sprite z:101];
		sprite.position=ccp(160,240);
		
		
		CCMenuItemImage *menuItem4 = [CCMenuItemImage itemFromNormalImage:@"winmenu_menu1.png" selectedImage:@"winmenu_menu2.png" target:self selector:@selector(onMenu:)];
		CCMenu *menu = [CCMenu menuWithItems:menuItem4, nil];
		
		NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
		
		int winLevel = [deddy GetLevelNumber]+1;
		int totalLevel = [d integerForKey:@"totalLevel"];
		if (totalLevel>winLevel) {
			CCMenuItemImage *menuItem2 = [CCMenuItemImage itemFromNormalImage:@"winmenu_next1.png" selectedImage:@"winmenu_next2.png" target:self selector:@selector(onNextLevel:)];
			[menu addChild:menuItem2];
		}

		[menu alignItemsHorizontallyWithPadding:7.0];
		menu.position=ccp(160,200);
        [self addChild:menu z:102];

		
	}
    return self;
}

-(void)onMenu:(id)sender{

	SoundUtils::MenuClick();
	[deddy onExitGame];

}

-(void)onNextLevel:(id)sender{

	SoundUtils::MenuClick();
	int nextLevel=[deddy GetLevelNumber]+1;
	[[CCDirector sharedDirector] replaceScene:[[GameScene alloc] initWithLevel: nextLevel ]];

}


@end
