//
//  HelloWorldScene.h
//  Cocos2DBreakout2
//
//  Created by Ray Wenderlich on 2/17/10.
//  Copyright 2010 Ray Wenderlich. All rights reserved.
//
#ifndef littleBoyGameScene
#define littleBoyGameScene

#import "cocos2d.h"
#import "Box2D.h"
#import "MyContactListener.h"
#import "Item.h"
#import "Boy.h"

@interface GameScene : CCLayer {
    b2World *world;
	PhysicItem* Bottom;
	CCColorLayer* PauseLayer;
	BOOL isPause;
	BOOL isHelp;
	int tickCount;
	Boy* boy;
	std::vector<Item*> items;
	int LevelNumber;
	
    MyContactListener *contactListener;
}
-(int)GetLevelNumber;
-(void)onGameWin;
-(void)onLose;
-(void)StartBullet: (CGPoint) from to: (CGPoint) to;
-(void)onCancelPause;
+ (id) scene;

@end

#endif
