//
//  FallItemBad.mm
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FallItemBad.h"
#import "DestroyLine.h"

#import "GameController.h"
#import "EventParametrCollision.h"

void FallItemBad::execute(const EventParametr& parametr)
{
	Item* obj1 = ((EventParametrCollision&)parametr).obj1;
	Item* obj2 = ((EventParametrCollision&)parametr).obj2;
	
	GameController* controller = GetterSetterGameController::get();
	if( NULL == controller)
		return;
	
	if( NULL != obj1 && DestroyLine::getNameStatic() == obj1->getName() )
		controller->fallItemBad(obj2);
	
	if( NULL != obj2 && DestroyLine::getNameStatic() == obj2->getName() )
		controller->fallItemBad(obj1);
}
