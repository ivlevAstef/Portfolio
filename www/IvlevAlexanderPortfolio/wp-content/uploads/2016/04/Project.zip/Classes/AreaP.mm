//
//  AreaP.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "AreaP.h"

AreaP::AreaP(b2World* world,float x,float y,float x2, float y2)
{
	this->world = world;
	x /= PTM_RATIO;
	y /= PTM_RATIO;
	x2 /= PTM_RATIO;
	y2 /= PTM_RATIO;
	
	b2BodyDef BodyDef;
	BodyDef.angularDamping = angularDamping;
	BodyDef.position.Set(0,0);
	area = world->CreateBody(&BodyDef);
	
	b2PolygonShape Box;
	b2FixtureDef BoxDef;
	BoxDef.shape = &Box;
	BoxDef.density = density;
	BoxDef.friction = friction;
	BoxDef.restitution = restitution;
	BoxDef.filter.maskBits = AREA;
	BoxDef.filter.categoryBits= AREA;
	
	Box.SetAsEdge(b2Vec2(x,y), b2Vec2(x2, y));
	area->CreateFixture(&BoxDef);
	
	Box.SetAsEdge(b2Vec2(x,y), b2Vec2(x, y2));
	area->CreateFixture(&BoxDef);
	
	Box.SetAsEdge(b2Vec2(x, y2), b2Vec2(x2, y2));
	area->CreateFixture(&BoxDef);
	
	Box.SetAsEdge(b2Vec2(x2, y2), b2Vec2(x2, y));
	area->CreateFixture(&BoxDef);
	
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	area->SetMassData(  &massData);
}

AreaP::~AreaP()
{
	world->DestroyBody(area);
}
	