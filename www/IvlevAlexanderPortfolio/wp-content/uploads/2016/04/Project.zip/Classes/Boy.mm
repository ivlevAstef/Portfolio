//
//  Paddle.m
//  Box2DBreakout2
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Boy.h"
#import "SoundUtils.h"



// HelloWorld implementation
@implementation Boy
@synthesize bear = _bear;
@synthesize moveAction = _moveAction;
@synthesize walkAction1 = _walkAction1;
@synthesize stopAction = _stopAction;
@synthesize shotAction = _shotAction;



-(id) initOnLayer: (CCLayer*) layer  andWorld:(b2World*) world{
    if((self = [super init])) {
        _layer=layer;
		_world=world;
		_speed=0;
        // This loads an image of the same name (but ending in png), and goes through the
        // plist to add definitions of each frame to the cache.
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"boy.plist"];        
        
        // Create a sprite sheet with the Happy Bear images
        CCSpriteBatchNode *spriteSheet = [CCSpriteBatchNode batchNodeWithFile:@"boy.png"];
        [_layer addChild:spriteSheet];
        
        // Load up the frames of our animation
        NSMutableArray *walkAnimFrames = [NSMutableArray array];
        for(int i = 1; i <= 9; ++i) {
            [walkAnimFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"%d.png", i]]];
        }
        CCAnimation *walkAnim = [CCAnimation animationWithFrames:walkAnimFrames delay:0.1f];
		self.walkAction1 = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:walkAnim restoreOriginalFrame:NO]];
		
		NSMutableArray *StopAnimFrames = [NSMutableArray array];
        for(int i = 1; i <= 1; ++i) {
            [StopAnimFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"%d.png", i]]];
        }
		CCAnimation *stopAnim = [CCAnimation animationWithFrames:StopAnimFrames delay:0.1f];
		self.stopAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:stopAnim restoreOriginalFrame:NO]];
		
		NSMutableArray *ShotAnimFrames = [NSMutableArray array];
        for(int i = 1; i <= 4; ++i) {
            [ShotAnimFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"fair%d.png", i]]];
        }
		CCAnimation *shotAnim = [CCAnimation animationWithFrames:ShotAnimFrames delay:0.07f];
		//[CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:shotAnim restoreOriginalFrame:NO]];
		self.shotAction = [CCSequence actions:                          
		 [CCAnimate actionWithAnimation:shotAnim restoreOriginalFrame:NO],
		 [CCCallFunc actionWithTarget:self selector:@selector(EndGunShot)],
		 nil
		 ];
        
        // Create a sprite for our bear
        CGSize winSize = [CCDirector sharedDirector].winSize;
        self.bear = [CCSprite spriteWithSpriteFrameName:@"1.png"];        
        _bear.position = ccp(winSize.width/2, 63);
        
        //[_bear runAction:_walkAction];
        [spriteSheet addChild:_bear];
		[self SetSpeed:0.5];
		//[self SetSpeed:-0.5];
        
        //self.isTouchEnabled = YES;
        
    }
    return self;
}



-(BOOL) isShot
{
	return _isShot;	
}

-(void) StopAnim {    
	
	if (_moving) {
		[_bear stopAction:_walkAction1];
		[_bear stopAction:_moveAction];
	}else{
		[_bear stopAction: _stopAction];
	}
	
}

-(void) GunShot:(CGPoint) target {    
	if(!_isShot)
	{
		
		if (_bear.position.x<target.x) {
			_bear.flipX=NO;
		}else {
			_bear.flipX=YES;
		}

		
	_target=target;
	_isShot= YES;
	[self StopAnim];
		SoundUtils::GunShot();
	[_bear runAction:_shotAction];
	}
	
	
}
-(void) EndGunShot {    
	
	_isShot= NO;
	

	[_layer StartBullet: ccp(_bear.position.x,_bear.position.y+50) to: _target];
	[_bear runAction:_stopAction];
	_moving=NO;
	_speed=0;
	
}

-(void)bearMoveEnded {
	[_bear stopAction:_walkAction1];
    _moving = NO;
	
}



-(void)SetSpeed:(float) speed
{
	if (_isShot) {
		return;
	}
	
	if ((speed>0)and(_bear.position.x==280)) {
		return;
	}
	
	if ((speed<0)and(_bear.position.x==40)) {
		return;
	}
	 
	//return;
	int newspeed=0;
	float mspeed=speed;
	if (mspeed<0) {
		mspeed*=-1;
	}
	
	if (mspeed>0.1) {
		newspeed=1;
	}
	/*
	if (mspeed>0.3) {
		newspeed=2;
	}
	
	if (mspeed>0.5) {
		newspeed=3;
	}
	
	if (mspeed>0.7) {
		newspeed=4;
	}
	
	if (mspeed>0.9) {
		newspeed=5;
	}
	*/
	if (speed<0) {
		newspeed*=-1;
	}
	
	if(newspeed!=_speed)
	{
		_speed=newspeed;
		if (_moving) {
			[_bear stopAction:_walkAction1];
			[_bear stopAction:_moveAction];
		}else{
		[_bear stopAction: _stopAction];
		}
		if (_speed==0) {
			[_bear runAction:_stopAction];
			_moving=NO;
			return;
		}
		CGPoint touchLocation;
		if (_speed < 0) {
			touchLocation = ccp(40,63);
			_bear.flipX = YES;
		} else {
			touchLocation = ccp(280,63);
			_bear.flipX = NO;
		}   
		float moveDuration = 1.0;
		
		self.moveAction = [CCSequence actions:                          
						   [CCMoveTo actionWithDuration:moveDuration position:touchLocation],
						   [CCCallFunc actionWithTarget:self selector:@selector(bearMoveEnded)],
						   nil
						   ];
		 [_bear runAction:_moveAction];  
		 [_bear runAction:_walkAction1];  
		_moving=YES;
		
	}
	
}

-(CGPoint)BulletPosition {
	return _bear.position;
   }



// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	self.bear = nil;
    self.walkAction1 = nil;
	[super dealloc];
}
@end




