//
//  Bottle.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Bottle.h"


Bottle::Bottle(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"bottle.png",1);
	box = new LineP(world,x,y, view->getWidth(), view->getHeight(), 0 ,b2_dynamicBody);
	box->setParent((void*)this);
}

Bottle::~Bottle()
{
	delete box;
	delete view;
}

void Bottle::update(float dt)
{
	if (NULL == view || NULL == box)
		return;
	b2Vec2 pos = box->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(box->getAngle()));
}
