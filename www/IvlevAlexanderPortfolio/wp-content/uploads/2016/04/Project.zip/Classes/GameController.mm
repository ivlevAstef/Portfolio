//
//  GameController.mm
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GameController.h"

GameController* GetterSetterGameController::controller = NULL;

GameController::GameController(DataGame startData)
{
	this->start = startData;
	this->current = startData;
}

void GameController::update(float dt)
{
	static float time = 0;
	time+= dt;
	if( time >= 0.5)
	{
		current.score--;
		time = 0;
	}
}

void GameController::fallItemGood(Item*)
{
	current.countGoodItems --;
	if( current.countGoodItems <= 0)
		win();
}

void GameController::fallItemBad(Item*)
{
	current.countBadItems--;
	if( current.countBadItems <= 0)
		lose();
}

void GameController::win()
{
	NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
	
	 int winLevel = [d integerForKey:@"winLevel"];
	 int totalLevel = [d integerForKey:@"totalLevel"];
	if (totalLevel>winLevel) {
		winLevel++;
		[d setInteger: winLevel forKey: @"winLevel"];
	}
	[gameLayer onGameWin];
}
void GameController::lose()
{
	[gameLayer onLose];
}