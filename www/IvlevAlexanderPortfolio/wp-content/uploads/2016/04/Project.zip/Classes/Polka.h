//
//  Polka.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "PolkaP.h"

class Polka: public Item {
private:
	CCNode *line1;
	CCNode *line2;
	PolkaP* polka;
	ItemView* view;
public:
	Polka(CCLayer* layer,b2World* world,float x,float y,float heightLine,int countSegment);
	~Polka();
	
	virtual void draw();
	virtual void update(float dt);
	
	virtual const std::string getName(){return "Polka"; }
};
