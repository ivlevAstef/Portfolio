//
//  Clock.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ClockP.h"

ClockP::ClockP(b2World* world,float x,float y,float width, float height)
{
	this->world = world;
	x /= PTM_RATIO;
	y /= PTM_RATIO;
	width /= PTM_RATIO;
	height /= PTM_RATIO;
	
	b2BodyDef bodyDef;
	bodyDef.type = b2_dynamicBody;
	bodyDef.angularDamping = angularDamping;
	bodyDef.position.Set( x, y);
	clock = world->CreateBody(&bodyDef);
	
	b2FixtureDef ShapeDef;
	
	b2CircleShape circle;
	circle.m_radius = width/2;
	ShapeDef.shape = &circle;
	ShapeDef.density = density;
	ShapeDef.friction = friction;
	ShapeDef.restitution = restitution;
	ShapeDef.filter.maskBits = ITEM;
	ShapeDef.filter.categoryBits= ITEM;
	clock->CreateFixture(&ShapeDef);
	
	b2PolygonShape box;
	ShapeDef.shape = &box;
	
	float thick = (height-width);
	box.SetAsBox( (width-thick)/2, thick/2, b2Vec2(0,-height/2 +thick), 0);
	clock->CreateFixture(&ShapeDef);
	
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	clock->SetMassData(  &massData);
	
}

ClockP::~ClockP()
{
	world->DestroyBody(clock);
}
	