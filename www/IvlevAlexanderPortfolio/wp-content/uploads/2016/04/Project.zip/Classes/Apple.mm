//
//  Apple.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Apple.h"


Apple::Apple(CCLayer* layer,b2World* world, float x, float y)
{
	view = new ItemView(layer,@"apple.png",1);
	apple = new BulletP(world,x,y, view->getWidth());
	apple->setParent((void*)this);
}	

Apple::~Apple()
{
	delete apple;
	delete view;
}

void Apple::update(float dt)
{
	if (NULL == view || NULL == apple)
		return;
	b2Vec2 pos = apple->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(apple->getAngle()));
}
