//
//  ItemView.m
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ItemView.h"

ItemView::ItemView(CCLayer* layer, NSString* name,int zOrder)
{
	if( NULL == layer)
		return;
	sprite = [CCSprite spriteWithFile:name];

	[layer addChild:sprite z:zOrder];
	this->layer = layer;
}
ItemView::~ItemView()
{
	[layer removeChild:sprite cleanup:YES];
}

void ItemView::setPosition( CGFloat x, CGFloat y)
{
	sprite.position = ccp(x,y);
}

void ItemView::setRotate( CGFloat alpha)
{
	sprite.rotation = alpha;
}


void ItemView::setScale(float x, float y) 
{
	sprite.scaleX = x;
	sprite.scaleY = y;
}