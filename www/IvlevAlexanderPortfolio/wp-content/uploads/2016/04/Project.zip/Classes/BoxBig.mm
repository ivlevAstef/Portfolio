//
//  BoxBig.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BoxBig.h"

BoxBig::BoxBig(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"boxbig.png",3);
	box = new BoxP(world,x,y, view->getWidth(), view->getHeight(), 5 );
	box->setParent((void*)this);
}

BoxBig::~BoxBig()
{
	delete box;
	delete view;
}

void BoxBig::update(float dt)
{
	if (NULL == view || NULL == box)
		return;
	b2Vec2 pos = box->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(box->getAngle()));
}