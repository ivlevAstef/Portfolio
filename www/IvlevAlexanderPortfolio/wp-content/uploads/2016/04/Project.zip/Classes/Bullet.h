//
//  Bullet.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "Item.h"
#import "BulletP.h"

class Bullet: public Item {
private:
	ItemView* view;
	BulletP* bullet;
	static const float forceVelocity = 4;
public:
	Bullet(CCLayer* layer,b2World* world,float x,float y);
	~Bullet();
	void setVelocity(float x, float y);
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Bullet"; }
};

