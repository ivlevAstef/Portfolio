//
//  CloseBox.h
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PhysicItem.h"

class BoxP: public PhysicItem
{
private:
	static const float angularDamping = 0.02f;
	static const float density = 1.0f;
	static const float friction = 0.35f;
	static const float restitution = 0.1f;
	static const float mass = 2.0f;
	static const float I = 0.05f;
	
	b2Body* box;
public:
	BoxP(b2World* world,float x,float y,float width, float height,float thick);
	~BoxP();
	virtual b2Body* getPhysic(){ return box;}
	virtual void setParent(void* data){ box->SetUserData(data);}
	
	virtual b2Vec2 getPosition()
	{
		b2Vec2 vec= box->GetPosition();
		vec *= PTM_RATIO;
		return vec;
	}
	virtual float getAngle(){ return box->GetAngle();}
};
