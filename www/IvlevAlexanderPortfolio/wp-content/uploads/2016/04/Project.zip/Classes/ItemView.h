//
//  ItemView.h
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import <string>


class ItemView {
private:
	CCSprite* sprite;
	CCLayer* layer;
public:
	ItemView(CCLayer* layer, NSString* name,int zOrder);
	~ItemView();
	
	void setPosition( CGFloat x, CGFloat y);
	void setRotate( CGFloat alpha);
	void setScale(float x, float y);
	inline CCSprite* get(){return sprite;}
	inline float getWidth(){ return sprite.contentSize.width; }
	inline float getHeight(){ return sprite.contentSize.height; }
	inline CGPoint getPosition(){ return sprite.position;}
};