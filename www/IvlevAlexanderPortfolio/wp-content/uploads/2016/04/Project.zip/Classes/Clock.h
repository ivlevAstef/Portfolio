//
//  Clock.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "Item.h"
#import "ClockP.h"

class Clock: public Item {
private:
	bool oneCollision;
	ItemView* view;
	ClockP* clock;
public:
	Clock(CCLayer* layer,b2World* world,float x,float y);
	~Clock();
	
	virtual void collision(Item* item2);
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Clock"; }
};
