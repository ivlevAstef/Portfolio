//
//  MenuScene.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "GameScene.h"
#import "LoseMenu.h"
#import "VandalAppDelegate.h"
//#import "Scores.h"
//#import "About.h"
//#import "LevelMenu.h"
#import "SoundUtils.h"


@implementation LoseMenu
- (id) initWithDeddy:(GameScene*) _deddy
{
    if ((self = [super initWithColor: ccc4( 0, 0, 0, 60)])) {


		deddy=_deddy;		
		

		
		CCSprite* sprite = [CCSprite spriteWithFile:@"losemenu2.png"];
		
		[self addChild:sprite z:101];
		sprite.position=ccp(175,240);
		
		
		CCMenuItemImage *menuItem4 = [CCMenuItemImage itemFromNormalImage:@"losemenu_menu1.png" selectedImage:@"losemenu_menu2.png" target:self selector:@selector(onMenu:)];
		CCMenu *menu = [CCMenu menuWithItems:menuItem4, nil];
	
		CCMenuItemImage *menuItem2 = [CCMenuItemImage itemFromNormalImage:@"losemenu_againe1.png" selectedImage:@"losemenu_againe2.png" target:self selector:@selector(onAgain:)];
		[menu addChild:menuItem2];
	
		
		[menu alignItemsHorizontallyWithPadding:0.0];
		menu.position=ccp(160,200);
        [self addChild:menu z:102];
		

		
	}
    return self;
}

-(void)onMenu:(id)sender{

	SoundUtils::MenuClick();
	[deddy onExitGame];

}

-(void)onAgain:(id)sender{

	SoundUtils::MenuClick();
	int nextLevel=[deddy GetLevelNumber];
	[[CCDirector sharedDirector] replaceScene:[[GameScene alloc] initWithLevel: nextLevel ]];

}


@end
