//
//  DestroyLine.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LineP.h"

LineP::LineP(b2World* world,float x,float y,float x2, float y2)
{
	this->world = world;
	x /= PTM_RATIO;
	y /= PTM_RATIO;
	x2 /= PTM_RATIO;
	y2 /= PTM_RATIO;
	
	b2BodyDef BodyDef;
	BodyDef.position.Set(x,y);
	BodyDef.angularDamping = angularDamping;
	line = world->CreateBody(&BodyDef);
	
	b2PolygonShape lineS;
	lineS.SetAsEdge(b2Vec2(0,0), b2Vec2(x2-x, y2-y));
	b2FixtureDef lineDef;
	lineDef.shape = &lineS;	
	lineDef.density = density;
	lineDef.friction = friction;
	lineDef.restitution = restitution;
	lineDef.filter.maskBits = ITEM;
	lineDef.filter.categoryBits= ITEM;
	line->CreateFixture(&lineDef);
	
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	line->SetMassData(  &massData);
}

LineP::LineP(b2World* world,float x,float y,float width,float height,float angle,b2BodyType type)
{
	this->world = world;
	x /= PTM_RATIO;
	y /= PTM_RATIO;
	width /= PTM_RATIO;
	height /= PTM_RATIO;
	
	b2BodyDef BodyDef;
	BodyDef.type = type;
	BodyDef.position.Set(x,y);
	BodyDef.angularDamping = angularDamping;
	line = world->CreateBody(&BodyDef);
	
	b2PolygonShape lineS;
	lineS.SetAsBox(width/2,height/2, b2Vec2(0, 0), angle);
	b2FixtureDef lineDef;
	lineDef.shape = &lineS;
	lineDef.density = density;
	lineDef.friction = friction;
	lineDef.restitution = restitution;
	lineDef.filter.maskBits = ITEM;
	lineDef.filter.categoryBits= ITEM;
	line->CreateFixture(&lineDef);
	
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	line->SetMassData(  &massData);
	
}

LineP::~LineP()
{
	world->DestroyBody(line);
}