//
//  AreaP.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PhysicItem.h"

class AreaP: public PhysicItem
{
private:
	static const float angularDamping = 0.00f;
	static const float density = 1.0f;
	static const float friction = 0.4f;
	static const float restitution = 0.3f;
	static const float mass = 5.0f;
	static const float I = 0.0f;
	
	b2Body* area;
public:
	AreaP(b2World* world,float x,float y,float x2,float y2);
	~AreaP();
	
	virtual b2Body* getPhysic(){ return area;}
	virtual void setParent(void* data){ area->SetUserData(data);}
	
	virtual b2Vec2 getPosition()
	{
		b2Vec2 vec= area->GetPosition();
		vec *= PTM_RATIO;
		return vec;
	}
	virtual float getAngle(){ return area->GetAngle();}
};

