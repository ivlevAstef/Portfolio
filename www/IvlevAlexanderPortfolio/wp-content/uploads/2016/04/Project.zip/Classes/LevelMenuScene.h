
//  Created by Tim Sills on 2/26/10.
//

#import "cocos2d.h"
#import "LoopingLevelMenu.h"
#import "InputController.h"
//#import "CCMenu.h"

// MenuScene Layer
@interface LevelMenuScene : CCLayer
{
	CCSprite *menuSprite;
	CCSprite *menuSprite2;
	CCSprite *lockSprite;
	CCColorLayer* blackLayer;
	int _selectLevel;
	int _winLevel;
}

// returns a Scene that contains the GameScene as the only child
+(id) scene;

-(void)MenuItem1: (id)sender;
-(void)MenuItem2: (id)sender;
-(void)MenuItem3: (id)sender;
-(void)MenuItem4: (id)sender;
-(void)MenuItem5: (id)sender;


@end
