//
//  HelloWorldScene.m
//  Cocos2DBreakout2
//
//  Created by Ray Wenderlich on 2/17/10.
//Copyright 2010 Ray Wenderlich. All rights reserved.
//

#import "GameScene.h"
#import "MenuScene.h"
#import "HelpMenu.h"
#import "PauseMenuScene.h"
#import "NextLevelMenu.h"
#import "LoseMenu.h"
#import "GameController.h"
#import "SimpleAudioEngine.h"

#import "Bullet.h"
#import "AreaP.h"
#import "DestroyLine.h"
#import "LevelManager.h"
#import "SoundUtils.h"

@implementation GameScene

+ (id)scene {
 
    CCScene *scene = [CCScene node];
    GameScene *layer = [GameScene node];
    [scene addChild:layer];
    return scene;
    
}

-(id)initWithLevel:(int) level
{
	isPause=NO;
	[[CCDirector sharedDirector] resume];
	LevelNumber=level;
	return [self init];
}

- (id)init {
 
    if ((self=[super init])) {
		glEnable(GL_LINE_SMOOTH);
		
        CGSize winSize = [CCDirector sharedDirector].winSize;

        self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = YES;
        
        // Create a world
        b2Vec2 gravity = b2Vec2(0.0f, -10.0f);
        bool doSleep = false;
        world = new b2World(gravity, doSleep);
		 
		items.push_back(new DestroyLine((CCLayer*)self,world,0,-15,winSize.width, -15));
		
		
		AreaP* area = new AreaP(world,0,-20,winSize.width,winSize.height-50);
		
		ItemView* fon = new ItemView((CCLayer*)self,@"background2.png",-1);       
		fon->setPosition(160, 240);
		ItemView* topFon = new ItemView((CCLayer*)self,@"topBackground.png",-1);       
		topFon->setPosition(160, 480- (topFon->getHeight()/2));
		
		isPause=NO;
		//MenuInit
		
		
		
		CCMenuItemImage *menuItem1 = [CCMenuItemImage itemFromNormalImage:@"menu.png" selectedImage:@"menu.png" target:self selector:@selector(onPause:)];
		CCMenu *menu = [CCMenu menuWithItems:menuItem1, nil];
        menu.position = ccp(45,465);
        [self addChild:menu];
		
		//EndMenu
		
		
		
		
		
		boy = [[Boy alloc] initOnLayer: self andWorld: world];
		
		std::vector<Item*> level = LevelManager::getLevel(LevelNumber,(CCLayer*)self,world);
		items.insert(items.end(), level.begin(), level.end());
		
		GetterSetterGameController::get()->SetGameLayer(self);
		
        // Create contact listener
        contactListener = new MyContactListener();
        world->SetContactListener(contactListener);
		SoundUtils::PlayMusic();
        [self schedule:@selector(tick:)];
		
		isHelp=YES;
		tickCount=0;

    }
    return self;
    
}

-(void)onPause:(id)sender{
	if(!isPause)
	{
	SoundUtils::MenuClick();
	[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];

	PauseLayer = [[PauseMenuScene alloc] initWithDeddy: self];

		
	[self addChild: PauseLayer z: 100];
	isPause=YES;
	[[CCDirector sharedDirector] pause];
	}
}
-(void)onGameWin{
		if(!isPause)
		{
			SoundUtils::MenuClick();
			[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
			

			PauseLayer = [[NextLevelMenu alloc] initWithDeddy: self];
			
			[self addChild: PauseLayer z: 100];
			isPause=YES;
			[[CCDirector sharedDirector] pause];
		}
	
//	[self removeChild:  cleanup: YES];
}

-(void)onLose{
	if(!isPause)
	{
		SoundUtils::MenuClick();
		[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
		

		PauseLayer = [[LoseMenu alloc] initWithDeddy: self];
		
		[self addChild: PauseLayer z: 100];
		isPause=YES;
		[[CCDirector sharedDirector] pause];
	}
	
	//	[self removeChild:  cleanup: YES];
}

-(int)GetLevelNumber
{
	return LevelNumber;
}


-(void)onCancelPause
{
	SoundUtils::PlayMusic();
	[self removeChild: PauseLayer cleanup: YES];
	[[CCDirector sharedDirector] resume];
	isPause=NO;
	isHelp=NO;
}

-(void)onExitGame
{
	isPause=NO;
	SoundUtils::StopMusic();
	[[CCDirector sharedDirector] replaceScene:[MenuScene node]];
}

-(void)draw
{
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisable(GL_TEXTURE_2D);
	
	for( unsigned int i=0; i< items.size(); i++)
	{
		items[i]->draw();
	}

	
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnable(GL_TEXTURE_2D);
}

- (void)tick:(ccTime) dt {	
	if (isPause) {
		return;
	}
	if (isHelp) {
		tickCount++;
		isPause=YES;
		[[CCDirector sharedDirector] pause];
		PauseLayer = [[HelpMenu alloc] initWithDeddy: self];
		[self addChild: PauseLayer z: 100];
		
	}
	GameController* controller = GetterSetterGameController::get();
	if( NULL == controller)
		return;
	controller->update(dt);
    world->Step(dt, 10, 10);
	for( unsigned int i=0; i< items.size(); i++)
	{
		items[i]->update(dt);
	}
	
	std::vector<MyContact>::iterator pos;
	for(pos = contactListener->_contacts.begin(); pos != contactListener->_contacts.end(); ++pos) {
        MyContact contact = *pos;
		void* dataA = contact.objA->GetUserData();
		void* dataB = contact.objB->GetUserData();
		if(NULL == dataA || NULL == dataB)
			continue;
        ((Item*)dataA)->collision((Item*)dataB);
        ((Item*)dataB)->collision((Item*)dataA);
		
    }
	
	for (unsigned int i = 0; i < items.size(); i++) 
	{
		if( items[i]->getDestroy() )
		{
			delete items[i];
			items.erase( items.begin() + i);
			i--;
		}
	}
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	if (isPause) {
		return;
	}
	UITouch *myTouch = [touches anyObject];
    CGPoint location = [myTouch locationInView:[myTouch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
	[boy GunShot: location];
}

-(void)StartBullet: (CGPoint) from to: (CGPoint) to
{
	Bullet* bullet = new Bullet((CCLayer*)self,world,from.x, from.y);
	bullet->setVelocity(to.x, to.y);
	items.push_back( bullet);
}

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration	
{
	world->SetGravity(b2Vec2(3.3*acceleration.x,-10));
	[boy SetSpeed:acceleration.x];
}


- (void)dealloc {
    
	for (unsigned int i = 0; i < items.size(); i++) 
	{
			delete items[i];
			items.erase( items.begin() + i);
			i--;
	}
	
    delete contactListener;
    delete world;
    [super dealloc];
    
}

@end
