//
//  Scores.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ScoresMenuScene.h"
#import "MenuScene.h"



@implementation ScoresMenuScene
- (id) init
{
    if ((self = [super init])) {
		CCSprite *bg = [CCSprite spriteWithFile:@"background.png"];
		[bg setPosition:ccp(160, 240)];
		[self addChild:bg z:0];
		[self addChild:[CCLayer node] z:1];
		
		
		CCMenuItemImage *menuImage1 = [CCMenuItemImage itemFromNormalImage:@"Back.png" selectedImage:@"Back.png" target:self selector:@selector(onBack:)];
		CCMenu *menu = [CCMenu menuWithItems:menuImage1, nil];
		menu.position = ccp(60,40);  
		[self addChild:menu];
		
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Tyrym tym tym" fontName:@"Arial" fontSize:20];
        label.position = ccp(240, 160);
        [self addChild:label];
		/*
		CCMenuItemFont *menuItem1 = [CCMenuItemFont itemFromString:@"Back" target:self selector:@selector(onMenuScene:)];
        CCMenu *menu = [CCMenu menuWithItems:menuItem1, nil];
		menu.position = ccp(40,40);  
		[self addChild:menu];*/
    }
    return self;
}

- (void)onBack:(id)sender
{
    NSLog(@"on menu");
	[[CCDirector sharedDirector] replaceScene:[CCTransitionFlipAngular transitionWithDuration:0.5f scene:[MenuScene node]]];
}


@end
