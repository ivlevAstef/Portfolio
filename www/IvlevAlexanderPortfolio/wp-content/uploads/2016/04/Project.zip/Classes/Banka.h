//
//  Banka.h
//  Vandal
//
//  Created by 11 on 05.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "LineP.h"

class Banka: public Item {
private:
	LineP* box;
	ItemView* view;
public:
	Banka(CCLayer* layer,b2World* world,float x,float y);
	~Banka();
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Banka"; }
};
