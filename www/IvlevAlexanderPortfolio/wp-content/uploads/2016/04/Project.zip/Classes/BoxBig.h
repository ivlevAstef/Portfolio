//
//  BoxBig.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "BoxP.h"

class BoxBig: public Item {
private:
	BoxP* box;
	ItemView* view;
public:
	BoxBig(CCLayer* layer,b2World* world,float x,float y);
	~BoxBig();
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "BoxBig"; }
};

