//
//  SoundUtils.h
//  Vandal
//
//  Created by user on 05.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


class SoundUtils  {
private:
	
	
public:
	static void MenuClick();
	static void PlayMusic();
	static void StopMusic();
	static void GunShot();
	
};
