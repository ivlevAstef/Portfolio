//
//  LevelLoader.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LevelManager.h"

#import "Box.h"
#import "BoxBig.h"
#import "Clock.h"
#import "Polka.h"
#import "Banka.h"
#import "Book.h"
#import "Apple.h"
#import "Cake.h"
#import "Pot.h"
#import "Sword.h"
#import "Verysmallpot.h"
#import "Polka2.h"
#import "Bottle.h"

#import "EventParametrCollision.h"
#import "FallItemGood.h"
#import "FallItemBad.h"




std::string ToString(NSString *_nsString) {
	const char *cStr = [_nsString UTF8String];
	return (NULL != cStr ? cStr : "");
}
//
NSString *FromString(const std::string& _str) {
	return [NSString stringWithUTF8String:_str.c_str()];
}
//
int ToInt(NSNumber *_nsNumber) {
	int v = static_cast<int>([_nsNumber doubleValue] + 0.5);
	return v;
}
//

std::map<std::string,LevelManager::GetItem*> LevelManager::itemsGreate;
std::map<std::string,LevelManager::GetEvent*> LevelManager::eventGreate;


std::vector<Item*> LevelManager::loadLevelItems(NSArray* array, CCLayer* layer, b2World* world)
{	
	std::vector<Item*> items;
	if( nil == array)
		return items;
	
	for(NSDictionary* item in array)
	{
		if( nil == item)
			continue;
		
		NSString* type = [item objectForKey:@"type"];
		if( nil == type)
			continue;
		
		GetItem* itemType = itemsGreate[ToString(type)];
		if( NULL == itemType && "Polka" != ToString(type))
			continue;
		
		NSNumber* posX = [item objectForKey:@"x"];
		NSNumber* posY = [item objectForKey:@"y"];
		NSNumber* height = [item objectForKey:@"height"];
		NSNumber* count = [item objectForKey:@"count"];
		
		ItemParametrs param(layer,world);
		
		if( nil != posX)
			param.x = [posX floatValue];
		if( nil != posY)
			param.y = [posY floatValue];
		if( nil != height)
			param.heightLine = [height floatValue];
		if( nil != count)
			param.countSegment = [count floatValue];
		
		Item* itemNew = NULL;
		if( "Polka" == ToString(type) )
		{
			itemNew = new Polka(param.layer,param.world,param.x,param.y,param.heightLine,param.countSegment);
		}else {
			itemNew = itemType->get(param );
		}

		if( NULL == itemNew)
			continue;
		
		items.push_back( itemNew );
		
		NSArray* events = [item objectForKey:@"events"];
		loadEvents(events,itemNew);
	}
	return items;
	
}

void LevelManager::loadEvents(NSArray* array,Item* item)
{
	if( nil == array)
		return;
	
	for(NSString* eventName in array)
	{
		if( nil == eventName)
			continue;
		
		GetEvent* event = eventGreate[ToString(eventName)];
		if( NULL == event)
			continue;
		
		item->addEvent(event->get());
	}
	
}

GameController* LevelManager::loadLevelData(NSDictionary* data)
{	
	GameController::DataGame parametr;
	if( nil == data)
		return NULL;
	
	NSNumber* score = [data objectForKey:@"score"];
	NSNumber* countGood = [data objectForKey:@"countGoodItem"];
	NSNumber* countBad = [data objectForKey:@"countBadItem"];
	NSNumber* costBad = [data objectForKey:@"costBadItem"];
	NSNumber* time = [data objectForKey:@"time"];
	
	if( nil != score)
		parametr.score = [score intValue];
	if( nil != score)
		parametr.countGoodItems = [countGood intValue];
	if( nil != score)
		parametr.countBadItems = [countBad intValue];
	if( nil != score)
		parametr.costBadItem = [costBad intValue];
	if( nil != score)
		parametr.time = [time floatValue];
		
	return new GameController(parametr);
	
}

std::vector<Item*> LevelManager::load(NSString* name,CCLayer* layer, b2World* world)
{
	NSString* filePath = [[NSBundle mainBundle] pathForResource:name ofType:@"plist"];
	NSDictionary* plist = [[NSDictionary dictionaryWithContentsOfFile:filePath] retain];
	
	std::vector<Item*> items;
	if( nil == plist)
		return items;
	
	NSArray* itemsData = [plist objectForKey:@"items"];
	NSDictionary* levelData = [plist objectForKey:@"level"];
	if( nil == itemsData || nil == levelData)
		return items;
	
	GameController* controller = loadLevelData(levelData);
	if( NULL == controller)
		return items;
	
	GetterSetterGameController::set(controller);
	return loadLevelItems(itemsData,layer,world);
	
}



std::vector<Item*> LevelManager::getLevel(unsigned int number,CCLayer* layer, b2World* world)
{
	init();
	std::vector<Item*> level;
	
	char dataNumber[128] = {0};
	
	if( 1 != sprintf(dataNumber, "%d",number))
		return level;
	
	NSString* name = FromString( std::string("level")+dataNumber );
	return load(name,layer,world);
}

void LevelManager::init()
{
	static bool isLoad = false;
	if( !isLoad)
	{
		addEvent<FallItemGood>("FallItemGood");
		addEvent<FallItemBad>("FallItemBad");
		add<Clock>("Clock");
		add<Box>("Box");
		add<BoxBig>("BoxBig");
		//add<Polka>("Polka");
		add<Banka>("Banka");
		add<Book>("Book");
		add<Apple>("Apple");
		add<Cake>("Cake");
		add<Pot>("Pot");
		add<Sword>("Sword");
		add<Verysmallpot>("Verysmallpot");
		add<Polka2>("Polka2");
		add<Bottle>("Bottle");
		isLoad = true;
	}
}