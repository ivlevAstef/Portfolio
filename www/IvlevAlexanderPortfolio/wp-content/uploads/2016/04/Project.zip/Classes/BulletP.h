//
//  bullet.h
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

//
//  Physics.h
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "PhysicItem.h"

class BulletP: public PhysicItem
{
private:
	static const float angularDamping = 0.02f;
	static const float density = 1.0f;
	static const float friction = 0.25f;
	static const float restitution = 0.1f;
	static const float mass = 0.9f;
	static const float I = 0.1f;
	
	b2Body* bullet;
public:
	BulletP(b2World* world,float x, float y,float radial);
	~BulletP();
	
	virtual b2Body* getPhysic(){ return bullet;}
	virtual void setParent(void* data){ bullet->SetUserData(data);}
	
	void setVelocity(float x, float y,float force);
	
	virtual b2Vec2 getPosition()
	{
		b2Vec2 vec= bullet->GetPosition();
		vec *= PTM_RATIO;
		return vec;
	}
	virtual float getAngle(){ return bullet->GetAngle();}
};
