//
//  About.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AboutMenuScene.h"
#import "MenuScene.h"
//#import "Box2D.h"


@implementation AboutMenuScene
- (id) init
{
    if ((self = [super init])) {
		CCSprite *bg = [CCSprite spriteWithFile:@"background.png"];
		[bg setPosition:ccp(160, 240)];
		[self addChild:bg z:0];
		[self addChild:[CCLayer node] z:1];
		
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Param Pam Pam" fontName:@"Arial" fontSize:20];
        label.position = ccp(240, 160);
        [self addChild:label];
		
		CCMenuItemImage *menuImage1 = [CCMenuItemImage itemFromNormalImage:@"back.png" selectedImage:@"back.png" target:self selector:@selector(onBack:)];
		CCMenu *menu = [CCMenu menuWithItems:menuImage1, nil];
		menu.position = ccp(60,40);  
		[self addChild:menu];
    }
    return self;
}

- (void)onBack:(id)sender
{
    NSLog(@"on menu");
    [[CCDirector sharedDirector] replaceScene:[CCTransitionFlipAngular transitionWithDuration:0.5f scene:[MenuScene node]]];
}

@end
