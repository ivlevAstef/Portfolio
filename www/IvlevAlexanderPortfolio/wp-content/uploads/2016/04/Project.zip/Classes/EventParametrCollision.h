/*
 *  EventParametrCollision.h
 *  Vandal
 *
 *  Created by 11 on 04.02.11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#import "EventParametr.h"
#import "Item.h"

class EventParametrCollision: public EventParametr
{
public:
	Item* obj1;
	Item* obj2;
	EventParametrCollision(Item* obj1,Item* obj2):obj1(obj1),obj2(obj2){}
};