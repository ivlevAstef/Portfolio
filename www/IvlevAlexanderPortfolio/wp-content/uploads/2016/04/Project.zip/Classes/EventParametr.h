/*
 *  EventParametr.h
 *  Vandal
 *
 *  Created by 11 on 04.02.11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */


/*don't use*/
class EventParametr
{
};