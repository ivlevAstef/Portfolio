//
//  Apple.h
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "BulletP.h"

class Apple: public Item {
private:
	ItemView* view;
	BulletP* apple;
public:
	Apple(CCLayer* layer,b2World* world,float x,float y);
	~Apple();
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Apple"; }
};
