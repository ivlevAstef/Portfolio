//
//  Sword.h
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "LineP.h"

class Sword: public Item {
private:
	LineP* sword;
	ItemView* view;
public:
	Sword(CCLayer* layer,b2World* world,float x,float y);
	~Sword();
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Sword"; }
};