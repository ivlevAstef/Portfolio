//
//  Pot.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Pot.h"

Pot::Pot(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"pot.png",1);
	pot = new LineP(world,x,y, view->getWidth(), view->getHeight(), 0 ,b2_dynamicBody);
	pot->setParent((void*)this);
}

Pot::~Pot()
{
	delete pot;
	delete view;
}

void Pot::update(float dt)
{
	if (NULL == view || NULL == pot)
		return;
	b2Vec2 pos = pot->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(pot->getAngle()));
}
