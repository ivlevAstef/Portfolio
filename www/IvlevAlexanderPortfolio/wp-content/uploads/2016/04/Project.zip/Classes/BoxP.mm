//
//  CloseBox.mm
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "BoxP.h"

BoxP::BoxP(b2World* world,float x,float y,float width, float height,float thick)
{
	this->world = world;
	x /= PTM_RATIO;
	y /= PTM_RATIO;
	width /= PTM_RATIO;
	height /= PTM_RATIO;
	thick /= PTM_RATIO;
	
	
	b2BodyDef bodyDef;
	bodyDef.type = b2_dynamicBody;
	bodyDef.angularDamping = angularDamping;
	bodyDef.position.Set( x, y);
	box = world->CreateBody(&bodyDef);
	
	b2PolygonShape wall;
	b2FixtureDef wallDef;
	wallDef.shape = &wall;
	
	wallDef.density = density;
	wallDef.friction = friction;
	wallDef.restitution = restitution;
	wallDef.filter.maskBits = ITEM;
	wallDef.filter.categoryBits= ITEM;
	
	wall.SetAsBox(thick/2, height/2, b2Vec2(-width/2,0), 0);
	box->CreateFixture(&wallDef);
	wall.SetAsBox(thick/2, height/2, b2Vec2(width/2,0), 0);
	box->CreateFixture(&wallDef);
	wall.SetAsBox(width/2, thick/2, b2Vec2(0,-height/2+ thick/2), 0);
	box->CreateFixture(&wallDef);
	
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	box->SetMassData(  &massData);
	
}

BoxP::~BoxP()
{
	world->DestroyBody(box);
}
