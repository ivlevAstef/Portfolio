//
//  ball.h
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ItemView.h"
#import "PhysicItem.h"
#import "Event.h"

#import <string>
#import <vector>

class Item {
protected:
	std::vector<Event*> events;
	bool destroy;
	
	static void isDestroy(Item& item,bool destr){ item.destroy = destr; }
	void executeEvents(Item* item2);
	
public:	
	inline bool getDestroy(){ return destroy;}
	
	virtual void update(float dt) = 0;
	virtual void draw() = 0;
	virtual void collision(Item* item2){executeEvents(item2);}
	
	virtual const std::string getName(){return "Item"; }
	
	void addEvent(Event* );
	
	virtual ~Item();
protected:
	Item():destroy(false) {}
};