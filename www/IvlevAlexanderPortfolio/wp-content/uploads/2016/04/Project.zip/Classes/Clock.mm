//
//  Clock.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "Clock.h"

#import "SimpleAudioEngine.h"

Clock::Clock(CCLayer* layer,b2World* world, float x, float y)
{
	oneCollision = false;
	
	view = new ItemView(layer,@"clock.png",1);
	clock = new ClockP(world,x,y, view->getWidth(),view->getHeight());
	clock->setParent((void*)this);
}	

Clock::~Clock()
{
	delete clock;
	delete view;
}

void Clock::update(float dt)
{
	if (NULL == view || NULL == clock)
		return;
	b2Vec2 pos = clock->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(clock->getAngle()));
}

void Clock::collision(Item* item2)
{
	executeEvents(item2);
	if( false == oneCollision && "Bullet" == item2->getName())
	{
		oneCollision = true;
		[[SimpleAudioEngine sharedEngine] playEffect:@"blip.caf"];
	}
}