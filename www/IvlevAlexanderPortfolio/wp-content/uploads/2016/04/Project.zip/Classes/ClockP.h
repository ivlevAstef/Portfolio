//
//  Clock.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PhysicItem.h"

class ClockP: public PhysicItem
{
private:
	static const float angularDamping = 0.02f;
	static const float density = 1.0f;
	static const float friction = 0.5f;
	static const float restitution = 0.15f;
	static const float mass = 0.4f;
	static const float I = 0.1f;
	
	b2Body* clock;
public:
	ClockP(b2World* world,float x,float y,float width,float height);
	~ClockP();
	
	virtual b2Body* getPhysic(){ return clock;}
	virtual void setParent(void* data){ clock->SetUserData(data);}
	
	virtual b2Vec2 getPosition()
	{
		b2Vec2 vec= clock->GetPosition();
		vec *= PTM_RATIO;
		return vec;
	}
	virtual float getAngle(){ return clock->GetAngle();}
};
