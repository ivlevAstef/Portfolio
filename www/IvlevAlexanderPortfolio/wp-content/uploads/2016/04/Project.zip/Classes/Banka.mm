//
//  Banka.mm
//  Vandal
//
//  Created by 11 on 05.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "Banka.h"

Banka::Banka(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"banka.png",1);
	box = new LineP(world,x,y, view->getWidth(), view->getHeight(), 0 ,b2_dynamicBody);
	box->setParent((void*)this);
}

Banka::~Banka()
{
	delete box;
	delete view;
}

void Banka::update(float dt)
{
	if (NULL == view || NULL == box)
		return;
	b2Vec2 pos = box->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(box->getAngle()));
}
