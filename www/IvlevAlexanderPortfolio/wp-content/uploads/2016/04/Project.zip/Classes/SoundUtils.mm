//
//  SoundUtils.mm
//  Vandal
//
//  Created by user on 05.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SoundUtils.h"
#import "SimpleAudioEngine.h"

void SoundUtils::MenuClick()
{
	[[SimpleAudioEngine sharedEngine] playEffect:@"PencilShort.wav"];
}

void SoundUtils::GunShot()
{
	[[SimpleAudioEngine sharedEngine] playEffect:@"Rogatka.wav"];
}

void SoundUtils::PlayMusic()
{
	[[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"background-music-aac.caf"];
}

void SoundUtils::StopMusic()
{
	[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
}