//
//  Pot.h
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "LineP.h"

class Pot: public Item {
private:
	LineP* pot;
	ItemView* view;
public:
	Pot(CCLayer* layer,b2World* world,float x,float y);
	~Pot();
	
	virtual void update(float dt);
	virtual void draw(){}
	
	virtual const std::string getName(){return "Pot"; }
};
