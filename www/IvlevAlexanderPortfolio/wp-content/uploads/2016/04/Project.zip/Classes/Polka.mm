//
//  Polka.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Polka.h"

Polka::Polka(CCLayer* layer,b2World* world, float x, float y,float heightLine,int countSegment)
{                                                           
	view = new ItemView(layer,@"polka.png",2);              
	                                                        
	polka = new PolkaP(world,x,y,view->getWidth()/2,view->getHeight()/2,0,heightLine,countSegment);
                                                            
	polka->setParent((void*)this);                          
}                                                           
                                                            
Polka::~Polka()                                             
{                                                           
	delete polka;                                           
	delete view;                                            
}                                                           
                                                            
void Polka::draw()                                          
{                                                           
	if (NULL == view || NULL == polka)                      
		return;                                             
	glColor4f(0.3, 0.3, 0.3, 1.0);                          
	glLineWidth(2.0f);                                      
	                                                        
	std::vector<b2Vec2> line1 = polka->getLine1();          
	for( unsigned i = 1; i< line1.size(); i++)              
	{                                                       
		ccDrawLine( ccp(line1[i-1].x,line1[i-1].y), ccp(line1[i].x,line1[i].y) );
	}                                                       
	std::vector<b2Vec2> line2 = polka->getLine2();          
	for( unsigned i = 1; i< line2.size(); i++)              
	{                                                       
		ccDrawLine( ccp(line2[i-1].x,line2[i-1].y), ccp(line2[i].x,line2[i].y) );
	}                                                       
}                                                           
                                                            
void Polka::update(float dt)                                
{                                                           
	if (NULL == view || NULL == polka)                      
		return;                                             
	b2Vec2 pos = polka->getPosition();                      
	view->setPosition(pos.x, pos.y);                        
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(polka->getAngle()));
}                                                           