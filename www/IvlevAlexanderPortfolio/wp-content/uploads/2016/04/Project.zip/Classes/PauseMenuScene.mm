//
//  MenuScene.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "GameScene.h"
#import "PauseMenuScene.h"
#import "VandalAppDelegate.h"
//#import "Scores.h"
//#import "About.h"
//#import "LevelMenu.h"
#import "SoundUtils.h"


@implementation PauseMenuScene
- (id) initWithDeddy:(GameScene*) _deddy
{
    if ((self = [super initWithColor: ccc4( 0, 0, 0, 60)])) {

		deddy=_deddy;		
		CCSprite* sprite = [CCSprite spriteWithFile:@"quitmenu2.png"];
		
		[self addChild:sprite z:101];
		sprite.position=ccp(160,240);
		
		
		CCMenuItemImage *menuItem4 = [CCMenuItemImage itemFromNormalImage:@"quitmenu_yes1.png" selectedImage:@"quitmenu_yes2.png" target:self selector:@selector(onExit:)];
		CCMenu *menu = [CCMenu menuWithItems:menuItem4, nil];
		
		CCMenuItemImage *menuItem2 = [CCMenuItemImage itemFromNormalImage:@"quitmenu_no1.png" selectedImage:@"quitmenu_no2.png" target:self selector:@selector(onCancelPause:)];
		[menu addChild:menuItem2];
		
		[menu alignItemsHorizontallyWithPadding:30.0];
		menu.position=ccp(160,210);
        [self addChild:menu z:102];

		
	}
    return self;
}

-(void)onCancelPause:(id)sender{

	SoundUtils::MenuClick();
	[deddy onCancelPause];

}

-(void)onExit:(id)sender{

	SoundUtils::MenuClick();
	[deddy onExitGame];

}


@end
