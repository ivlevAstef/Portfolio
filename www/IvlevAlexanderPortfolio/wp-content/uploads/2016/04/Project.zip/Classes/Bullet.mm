//
//  Bullet.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "Bullet.h"

Bullet::Bullet(CCLayer* layer,b2World* world, float x, float y)
{
	view = new ItemView(layer,@"stone.png",1);
	bullet = new BulletP(world,x,y, view->getWidth());
	bullet->setParent((void*)this);
}	

Bullet::~Bullet()
{
	delete bullet;
	delete view;
}

void Bullet::setVelocity(float x, float y)
{
	bullet->setVelocity(x, y,forceVelocity);
}

void Bullet::update(float dt)
{
	if (NULL == view || NULL == bullet)
		return;
	b2Vec2 pos = bullet->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(bullet->getAngle()));
}


