//  Created by Tim Sills on 2/26/10.
//


// Import the interfaces
#import "LevelMenuScene.h"
#import "LoopingLevelMenu.h"
#import "GameScene.h"
#import "MenuScene.h"
#import "SoundUtils.h"

// MenuScene implementation
@implementation LevelMenuScene

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	LevelMenuScene *layer = [LevelMenuScene node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{

	if( (self=[super init] )) {
		CCSprite *bg = [CCSprite spriteWithFile:@"levels.png"];
		[bg setPosition:ccp(160, 240)];
		[self addChild:bg z:0];
		[self addChild:[CCLayer node] z:1];
		
		//CCLabelTTF *menuSelection = [CCLabelTTF labelWithString:@"Menu Selection" fontName:@"marker felt" fontSize:24];
		//menuSelection.position = ccp(160,20);
		//[self addChild:menuSelection];
		//menuSprite = [CCSprite spriteWithFile:@"button1.png"];
		//menuSprite.position = ccp(160,80);
		//[self addChild:menuSprite];
		
		CCMenuItem *item1 = [CCMenuItemImage itemFromNormalImage:@"button1.png" selectedImage:@"button1.png" target: self selector: @selector(MenuItem1:)];
		CCMenuItem *item2 = [CCMenuItemImage itemFromNormalImage:@"button2.png" selectedImage:@"button2.png" target: self selector: @selector(MenuItem2:)];
		CCMenuItem *item3 = [CCMenuItemImage itemFromNormalImage:@"button3.png" selectedImage:@"button3.png" target: self selector: @selector(MenuItem3:)];
		CCMenuItem *item4 = [CCMenuItemImage itemFromNormalImage:@"button4.png" selectedImage:@"button4.png" target: self selector: @selector(MenuItem4:)];
		CCMenuItem *item5 = [CCMenuItemImage itemFromNormalImage:@"button5.png" selectedImage:@"button5.png" target: self selector: @selector(MenuItem5:)];
		LoopingLevelMenu *menu = [LoopingLevelMenu menuWithItems:item1, item2, item3, item4, item5, nil];
		menu.position = ccp(160, 420);
		[menu alignItemsHorizontallyWithPadding:30];
		[self addChild:menu];
		
		//CCMenuItem *back = [CCMenuItemImage itemFromNormalImage:@"back.png" selectedImage:@"back.png" target: self selector: @selector(onBack:)];
		//back.position = ccp(30,30);
		CCMenuItem *play = [CCMenuItemImage itemFromNormalImage:@"menuplay.png" selectedImage:@"menuplayp.png" target: self selector: @selector(onPlay:)];
		play.position = ccp(260,40);
		CCMenu *menuAdd = [CCMenu menuWithItems:play, nil];
		menuAdd.position = ccp(0, 0);
		[self addChild:menuAdd];
		
		
		_selectLevel=-1;
		
		
		NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
		
		_winLevel = [d integerForKey:@"winLevel"];
		[self SelectLevel:(_winLevel-1)];
		
		
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}


-(void)SelectLevel: (int) levelNumber
{
	if (_selectLevel==levelNumber) {
		return;
	}
	SoundUtils::MenuClick();
	_selectLevel=levelNumber;
	[self removeChild:menuSprite cleanup:YES];
	menuSprite = [CCSprite spriteWithFile:[NSString stringWithFormat:@"level%dshot.png",(_selectLevel+1)]];
	menuSprite.position = ccp(160,240);
	[self addChild:menuSprite z:-2];
	
	//CCColorLayer* lll =[CCColorLayer initWithColor: ccc4( 0, 0, 0, 60)];
	[self removeChild:blackLayer cleanup:YES];
	[self removeChild:lockSprite cleanup:YES];
	
	if (_selectLevel>=_winLevel) {
		 blackLayer=[CCColorLayer layerWithColor: ccc4( 0, 0, 0, 160)];
		[self addChild:blackLayer z:-1];
		
		menuSprite = [CCSprite spriteWithFile:[NSString stringWithFormat:@"lock.png"]];
		menuSprite.position = ccp(160,240);
		[self addChild:menuSprite z:-1];
		
	}
	
	
	[self removeChild:menuSprite2 cleanup:YES];
	menuSprite2 = [CCSprite spriteWithFile:[NSString stringWithFormat:@"button%d.png",(_selectLevel+1)]];
	menuSprite2.position = ccp(170,80);
	[self addChild:menuSprite2];
	
}

-(void)MenuItem1:(id)sender {	
	[self SelectLevel: 0];
}

-(void)MenuItem2:(id)sender {
	[self SelectLevel: 1];
}

-(void)MenuItem3:(id)sender {
	[self SelectLevel: 2];
}

-(void)MenuItem4:(id)sender {
	
	[self SelectLevel: 3];
}

-(void)MenuItem5:(id)sender {
	
	[self SelectLevel: 4];
}


-(void)onPlay:(id)sender {

	if (_selectLevel>=0) {
		if (_selectLevel<_winLevel) {
		SoundUtils::MenuClick();
	[[CCDirector sharedDirector] replaceScene:[[GameScene alloc] initWithLevel: _selectLevel]];
		}
		}
	}




@end
