//
//  Polka2.h
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "PolkaP.h"

class Polka2: public Item {
private:
	PolkaP* polka;
	ItemView* view;
public:
	Polka2(CCLayer* layer,b2World* world,float x,float y);
	~Polka2();
	
	virtual void draw();
	virtual void update(float dt);
	
	virtual const std::string getName(){return "Polka2"; }
};