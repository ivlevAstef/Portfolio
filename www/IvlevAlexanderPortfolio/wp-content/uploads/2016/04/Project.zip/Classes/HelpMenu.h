//
//  MenuScene.h
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"


@interface HelpMenu : CCColorLayer {
	
	GameScene *deddy;
	
}

@end
