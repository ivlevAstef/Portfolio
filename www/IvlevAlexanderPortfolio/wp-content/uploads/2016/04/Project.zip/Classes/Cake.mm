//
//  Cake.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Cake.h"



Cake::Cake(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"cake.png",1);
	cake = new LineP(world,x,y, view->getWidth(), view->getHeight(), 0 ,b2_dynamicBody);
	cake->setParent((void*)this);
}

Cake::~Cake()
{
	delete cake;
	delete view;
}

void Cake::update(float dt)
{
	if (NULL == view || NULL == cake)
		return;
	b2Vec2 pos = cake->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(cake->getAngle()));
}
