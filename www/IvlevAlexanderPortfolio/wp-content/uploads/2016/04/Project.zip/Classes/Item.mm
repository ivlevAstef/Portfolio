//
//  ball.m
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "EventParametrCollision.h"

void Item::executeEvents(Item* item2)
{
	for (unsigned int i = 0; i < events.size(); i++) {
		if( NULL != events[i])
			events[i]->execute( EventParametrCollision(this, item2) );
	}
}

void Item::addEvent(Event* event)
{
	if( NULL != event)
		events.push_back( event);
}

/*void Item::set(ItemView* view,PhysicItem* model)
{
	if( NULL != view)
		this->view = view;
	
	if( NULL != model)
	{
		this->model = model;
		this->model->setParent((void*)this);
	}
	destroy = false;
}*/

Item::~Item()
{
	for (unsigned int i = 0; i < events.size(); i++) {
		delete events[i];
	}
}