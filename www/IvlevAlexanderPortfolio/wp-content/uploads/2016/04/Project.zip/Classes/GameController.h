//
//  GameController.h
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "Item.h"


class GameController
{
public:
	struct DataGame {
		int countGoodItems;
		int countBadItems;
		int score;
		int costBadItem;
		float time;
		DataGame()
		{
			score = 0;
			time = 0.0f;
			countBadItems = 0;
			countGoodItems = 0;
			costBadItem =0;
		}
	};
private:
	CCLayer* gameLayer;
	DataGame start;
	DataGame current;
	
public:
	void SetGameLayer(CCLayer* layer){gameLayer=layer;}
	GameController(){}
	GameController(DataGame startData);
	void fallItemGood(Item*);
	void fallItemBad(Item*);
	void update(float dt);
	
private:
	void win();
	void lose();
};

class GetterSetterGameController 
{
private:
	static GameController* controller;
public:
	static GameController* get(){ return controller;}
	static void set(GameController* contr){ controller = contr; }
};
