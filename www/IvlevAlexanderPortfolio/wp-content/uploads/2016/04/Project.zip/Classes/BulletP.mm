//
//  bullet.mm
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BulletP.h"

BulletP::BulletP(b2World* world,float x,float y,float radial)
{
	this->world = world;
	b2BodyDef bodyDef;
	bodyDef.type = b2_dynamicBody;
	bodyDef.angularDamping = angularDamping;
	bodyDef.bullet = true;
	bodyDef.position.Set( x/PTM_RATIO, y/PTM_RATIO);
	bullet = world->CreateBody(&bodyDef);
	
	b2FixtureDef ShapeDef;

	b2CircleShape circle;
	circle.m_radius = radial/(PTM_RATIO*2);
	ShapeDef.shape = &circle;
	ShapeDef.density = density;
	ShapeDef.friction = friction;
	ShapeDef.restitution = restitution;
	ShapeDef.filter.maskBits = BULLET;
	ShapeDef.filter.categoryBits= BULLET;
	bullet->CreateFixture(&ShapeDef);
	
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	bullet->SetMassData(  &massData);
	//body->IsBullet = true;
}

BulletP::~BulletP()
{
	world->DestroyBody(bullet);
}

void BulletP::setVelocity(float x, float y,float force)
{
	if( NULL == bullet)
		return;
	x = x/ PTM_RATIO;
	y = y/ PTM_RATIO;
	b2Vec2 vec =  bullet->GetPosition();
	bullet->ApplyLinearImpulse(force*b2Vec2(x - vec.x, y - vec.y), vec);
}