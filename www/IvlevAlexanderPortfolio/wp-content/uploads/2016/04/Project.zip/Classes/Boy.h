/*
 *  Paddle.h
 *  Box2DBreakout2
 *
 *  Created by 11 on 02.02.11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *ß
 */

#import "ItemView.h"
#import "PhysicItem.h"
#import "Bullet.h"
#import "BulletP.h"
#import <vector>


@interface Boy : NSObject
{
	CCLayer  *_layer;
	b2World  * _world;
    CCSprite *_bear;
    CCAction *_walkAction1;
	CCAction *_stopAction;
	CCAction *_shotAction;
	CCAction *_walkAction4;
	CCAction *_walkAction5;
	CCAction *_walkAction6;
    CCAction *_moveAction7;
	int _speed;
    BOOL _moving;
	BOOL _isShot;
	CGPoint _target;
}

-(id) initOnLayer: (CCLayer*) layer  andWorld:(b2World*) world;
-(CGPoint)BulletPosition;
-(void)SetSpeed:(float) speed;
-(void) GunShot:(CGPoint) target;
-(BOOL) isShot;

@property (nonatomic, retain) CCSprite *bear;
@property (nonatomic, retain) CCAction *walkAction1;
@property (nonatomic, retain) CCAction *stopAction;
@property (nonatomic, retain) CCAction *moveAction;
@property (nonatomic, retain) CCAction *shotAction;

@end



