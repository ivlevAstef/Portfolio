//
//  MenuScene.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "GameScene.h"
#import "HelpMenu.h"
#import "VandalAppDelegate.h"
//#import "Scores.h"
//#import "About.h"
//#import "LevelMenu.h"
#import "SoundUtils.h"


@implementation HelpMenu
- (id) initWithDeddy:(GameScene*) _deddy
{
    if ((self = [super initWithColor: ccc4( 0, 0, 0, 0)])) {
		deddy=_deddy;		
		
		int nlevel = [deddy GetLevelNumber];
		
		CCSprite *mask = [CCSprite spriteWithFile:[NSString stringWithFormat:@"helpmasklevel%d.png",(nlevel+1)]];
		[mask setPosition:ccp(160, 240)];
		[mask setOpacity:60];
		[self addChild:mask z:100];
		
		CCSprite *pic = [CCSprite spriteWithFile:[NSString stringWithFormat:@"helppiclevel%d.png",(nlevel+1)]];
		[pic setPosition:ccp(160, 240)];
		[self addChild:pic z:101];
		
		
		
		CCMenuItemImage *menuItem4 = [CCMenuItemImage itemFromNormalImage:@"menuplay.png" selectedImage:@"menuplayp.png" target:self selector:@selector(onCancelPause:)];
		CCMenu *menu = [CCMenu menuWithItems:menuItem4, nil];
		
		
		[menu alignItemsHorizontallyWithPadding:0.0];
		menu.position=ccp(260,30);
        [self addChild:menu z:102];
		
	}
    return self;
}

-(void)onCancelPause:(id)sender{

	SoundUtils::MenuClick();
	[deddy onCancelPause];

}




@end

