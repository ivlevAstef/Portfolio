//
//  Sword.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sword.h"

Sword::Sword(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"sword.png",1);
	sword = new LineP(world,x,y, view->getWidth(), view->getHeight(), 0 ,b2_dynamicBody);
	sword->setParent((void*)this);
}

Sword::~Sword()
{
	delete sword;
	delete view;
}

void Sword::update(float dt)
{
	if (NULL == view || NULL == sword)
		return;
	b2Vec2 pos = sword->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(sword->getAngle()));
}
