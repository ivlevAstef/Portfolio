//
//  untitled.m
//  Vandal
//
//  Created by 12 345 on 06.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "untitled.h"


@implementation untitled


- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
