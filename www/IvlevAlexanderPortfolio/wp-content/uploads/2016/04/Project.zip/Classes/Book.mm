//
//  book.mm
//  Vandal
//
//  Created by 12 345 on 07.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Book.h"

Book::Book(CCLayer* layer,b2World* world,float x,float y)
{
	view = new ItemView(layer,@"book.png",1);
	book = new LineP(world,x,y, view->getWidth(), view->getHeight(), 0 ,b2_dynamicBody);
	book->setParent((void*)this);
}

Book::~Book()
{
	delete book;
	delete view;
}

void Book::update(float dt)
{
	if (NULL == view || NULL == book)
		return;
	b2Vec2 pos = book->getPosition();
	view->setPosition(pos.x, pos.y);
	view->setRotate( -1 * CC_RADIANS_TO_DEGREES(book->getAngle()));
}
