//
//  MenuScene.m
//  NormalMenu
//
//  Created by user on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "GameScene.h"
#import "MenuScene.h"
#import "VandalAppDelegate.h"
#import "ScoresMenuScene.h"
#import "AboutMenuScene.h"
#import "LevelMenuScene.h"
#import "SoundUtils.h"



@implementation MenuScene
- (id) init
{
    if ((self = [super init])) {
		CCSprite *bg = [CCSprite spriteWithFile:@"menuback.png"];
		[bg setPosition:ccp(160, 240)];
		[self addChild:bg z:0];
		[self addChild:[CCLayer node] z:1];
	

		CCMenuItemImage *menuItem1 = [CCMenuItemImage itemFromNormalImage:@"menuplay.png" selectedImage:@"menuplayp.png" target:self selector:@selector(onLevelMenu:)];
		CCMenu *menu = [CCMenu menuWithItems:menuItem1, nil];
		
		
		CCMenuItemImage *menuItem2 = [CCMenuItemImage itemFromNormalImage:@"menuscore.png" selectedImage:@"menuscoresp.png" target:self selector:@selector(onScores:)];
		[menu addChild:menuItem2];
		[menu alignItemsVertically];
		menu.position = ccp(85,300);
        [self addChild:menu];
		
		

	}
    return self;
}

-(void)onLevelMenu:(id)sender{

	SoundUtils::MenuClick();
	[[CCDirector sharedDirector] replaceScene:[LevelMenuScene scene]];
}


-(void)onResume:(id)sender{
	SoundUtils::MenuClick();
	[[CCDirector sharedDirector] popScene];
}



- (void)onScores:(id)sender
{
	SoundUtils::MenuClick();
    [[CCDirector sharedDirector] replaceScene:[ScoresMenuScene node]];
}

- (void)onAbout:(id)sender
{
    NSLog(@"on about");
    [[CCDirector sharedDirector] replaceScene:[AboutMenuScene node]];
}

@end
