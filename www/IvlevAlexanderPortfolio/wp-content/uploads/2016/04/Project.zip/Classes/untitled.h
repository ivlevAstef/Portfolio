//
//  untitled.h
//  Vandal
//
//  Created by 12 345 on 06.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface untitled : UIView {

}

@end
