//
//  Physics.h
//  Arconoid
//
//  Created by 11 on 02.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "Box2D.h"

class PhysicItem
{
public:
	static const float PTM_RATIO = 160.0f;
	enum Masks
	{
		ITEM = 0x0001,
		BULLET = 0x0001,
		BOY = 0x0010,
		AREA = 0x0011
	};
protected:
	b2World* world;
	
	PhysicItem():world(NULL){}
public:	
	virtual b2Body* getPhysic() = 0;
	virtual void setParent(void*) = 0;
	
	virtual b2Vec2 getPosition() = 0;
	virtual float getAngle() = 0;
	
	virtual ~PhysicItem(){}
};
