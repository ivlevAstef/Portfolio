//
//  PolkaP.mm
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PolkaP.h"

std::vector<b2Vec2> PolkaP::getLine1()
{
	std::vector<b2Vec2> result;
	for( unsigned int i =0; i < line1.size(); i++)
	{
		b2Vec2 pos  = line1[i]->GetPosition();
		pos *= PTM_RATIO;
		result.push_back(  pos);
	}
	
	return result;
}

std::vector<b2Vec2> PolkaP::getLine2()
{
	std::vector<b2Vec2> result;
	for( unsigned int i =0; i < line2.size(); i++)
	{
		b2Vec2 pos  = line2[i]->GetPosition();
		pos *= PTM_RATIO;
		result.push_back( pos );
	}
	
	return result;
}

PolkaP::PolkaP(b2World* world,float x,float y,float width,float height,float angle,float heightLine,int countSegment)
{
	this->world = world;
	this->heigthLine = heightLine;
	float lenghtSegment = 10.0f;
	if (0 <= countSegment) {
		lenghtSegment = heigthLine/countSegment;
	}
	if( 0 == heightLine)
		lenghtSegment = 1.0f;
	unsigned int COUNT_SEGMENT = heigthLine/lenghtSegment;
	float frequencyHz = 10.0f;
	float dampingRatio = 0.1f;
	float widthPolka = width / PTM_RATIO;
	
	x /= PTM_RATIO;
	y /= PTM_RATIO;
	width /= PTM_RATIO;
	width -= width/20;
	height /= PTM_RATIO;	
	heigthLine /= PTM_RATIO;
	lenghtSegment /= PTM_RATIO;
	
	//////		
	b2BodyDef BodyDef;
	BodyDef.type = b2_dynamicBody;
	BodyDef.position.Set(x,y);
	BodyDef.angularDamping = angularDamping;
	BodyDef.linearDamping = linearDamping;
	polka = world->CreateBody(&BodyDef);
	
	b2BodyDef lineDef;
	lineDef.type = b2_dynamicBody;
	lineDef.angularDamping = angularDamping2;
	lineDef.linearDamping = linearDamping;
	
	b2DistanceJointDef jointDefLine;	
	jointDefLine.collideConnected = true;
	jointDefLine.frequencyHz = frequencyHz;
	jointDefLine.dampingRatio = dampingRatio;
	for( unsigned int i = 0; i < COUNT_SEGMENT; i++)
	{
		float xI = x;
		float yI = y+((float)i)*lenghtSegment;
		float yI_1 = y+((float)(i-1))*lenghtSegment;
		
		lineDef.position.Set(xI-width,yI);
		line1.push_back( world->CreateBody(&lineDef) );
		lineDef.position.Set(xI+width,yI);
		line2.push_back( world->CreateBody(&lineDef) );
			
		if( 0 == i)
		{
			jointDefLine.Initialize(line1[i], polka, b2Vec2(xI-width,yI), b2Vec2(xI-width,yI));
			world->CreateJoint(&jointDefLine);
			jointDefLine.Initialize(line2[i], polka, b2Vec2(xI+width,yI), b2Vec2(xI+width,yI));
			world->CreateJoint(&jointDefLine);
			continue;
		}
		jointDefLine.Initialize(line1[i], line1[i-1], b2Vec2(xI-width,yI), b2Vec2(xI-width,yI_1));
		world->CreateJoint(&jointDefLine);
		jointDefLine.Initialize(line2[i], line2[i-1], b2Vec2(xI+width,yI), b2Vec2(xI+width,yI_1));
		world->CreateJoint(&jointDefLine);
	}
	{
		unsigned int i = COUNT_SEGMENT;
		
		float yI = y+((float)i)*lenghtSegment;
		float yI_1 = y+((float)(i-1))*lenghtSegment;
		b2BodyDef staticDef;
		staticDef.type = b2_staticBody;
		staticDef.angularDamping = angularDamping2;
		staticDef.linearDamping = linearDamping;
		
		staticDef.position.Set(x-width,y);
		if( 0 == i){
			jointDefLine.Initialize(world->CreateBody(&staticDef), polka, b2Vec2(x-width,y), b2Vec2(x-width,y));
		}else{
			jointDefLine.Initialize(world->CreateBody(&staticDef), line1[i-1], b2Vec2(x-width,yI), b2Vec2(x-width,yI_1));
		}
		world->CreateJoint(&jointDefLine);
		
		staticDef.position.Set(x+width,y);
		if( 0 == i){
			jointDefLine.Initialize(world->CreateBody(&staticDef), polka, b2Vec2(x+width,y), b2Vec2(x+width,y));
		}else{
			jointDefLine.Initialize(world->CreateBody(&staticDef), line2[i-1], b2Vec2(x+width,yI), b2Vec2(x+width,yI_1));
		}
		world->CreateJoint(&jointDefLine);
	}
	b2PolygonShape Box;
	Box.SetAsBox(widthPolka,height, b2Vec2(0, 0), angle);
	
	b2FixtureDef BoxDef;
	BoxDef.shape = &Box;
	BoxDef.density = density;
	BoxDef.friction = friction;
	BoxDef.restitution = restitution;
	BoxDef.filter.maskBits = ITEM;
	BoxDef.filter.categoryBits= ITEM;
	
	polka->CreateFixture(&BoxDef);
	static const b2MassData massData = {mass, b2Vec2(0,0), I};
	polka->SetMassData(  &massData);
	
}

PolkaP::~PolkaP()
{
	world->DestroyBody(polka);
	for( unsigned int i  =0 ; i< line1.size(); i++)
	{
		world->DestroyBody( line1[i] );
	}
	for( unsigned int i  =0 ; i< line2.size(); i++)
	{
		world->DestroyBody( line2[i] );
	}
}
