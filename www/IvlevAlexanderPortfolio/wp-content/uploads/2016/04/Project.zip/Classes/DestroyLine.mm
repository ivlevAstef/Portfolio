//
//  DestroyLine.mm
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "DestroyLine.h"

DestroyLine::DestroyLine(CCLayer* layer,b2World* world, float x, float y,float x2,float y2)
{
	line = new LineP(world,x,y, x2,y2);
	line->setParent((void*)this);
}

DestroyLine::~DestroyLine()
{
	delete line;
}

void DestroyLine::update(float dt)
{
}

void DestroyLine::collision(Item* item2)
{
	if( NULL == item2)
		return;
	Item::isDestroy( *item2, true);
}