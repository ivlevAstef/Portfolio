//
//  PolkaP.h
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PhysicItem.h"
#import <vector>

class PolkaP: public PhysicItem
{
private:
	std::vector<b2Body*> line1;
	std::vector<b2Body*> line2;
	b2Body* polka;
	float heigthLine;
private:
	static const float angularDamping = 0.5f;
	static const float angularDamping2 = 0.5f;
	static const float linearDamping = 1.0f;
	static const float density = 1.0f;
	static const float friction = 0.4f;
	static const float restitution = 0.1f;
	static const float mass = 5.0f;
	static const float I = 0.1f;
public:
	PolkaP(b2World* world,float x,float y,float width,float height,float angle,float heightLine,int countSegment);
	~PolkaP();
	
	std::vector<b2Vec2> getLine1();
	std::vector<b2Vec2> getLine2();	
	virtual b2Body* getPhysic(){ return polka;}
	virtual void setParent(void* data){ polka->SetUserData(data);}
	
	virtual b2Vec2 getPosition()
	{
		b2Vec2 vec= polka->GetPosition();
		vec *= PTM_RATIO;
		return vec;
	}
	virtual float getAngle(){ return polka->GetAngle();}

};
