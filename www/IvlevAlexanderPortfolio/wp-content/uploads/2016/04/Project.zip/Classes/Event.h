//
//  Event.h
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "EventParametr.h"

class Event
{
public:
	virtual void execute(const EventParametr&) = 0;
};