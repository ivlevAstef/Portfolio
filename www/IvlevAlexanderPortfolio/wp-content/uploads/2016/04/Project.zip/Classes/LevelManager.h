//
//  LevelLoader.h
//  Arconoid
//
//  Created by 11 on 03.02.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <map>
#import <string>
#import "Item.h"
#import "GameController.h"


class LevelManager 
{
private:
	struct ItemParametrs
	{
		CCLayer* layer;
		b2World* world;
		float x;
		float y;
		float heightLine;
		int countSegment;
		ItemParametrs(CCLayer* layer,b2World* world):layer(layer),world(world),x(0),y(0),heightLine(0),countSegment(-1){}
	};
	class GetItem
	{
	public:
		virtual Item* get(ItemParametrs&) = 0;
	};
	class GetEvent
	{
	public:
		virtual Event* get() = 0;
	};
	
	static std::map<std::string,GetItem*> itemsGreate;
	static std::map<std::string,GetEvent*> eventGreate;
public:
	static std::vector<Item*> getLevel(unsigned int number,CCLayer* layer, b2World* world);
	
private:
	
	static std::vector<Item*> load(NSString* name,CCLayer* layer, b2World* world);
	static void init();
	
	static void loadEvents(NSArray* array,Item* item);
	static GameController* loadLevelData(NSDictionary* data);
	static std::vector<Item*> loadLevelItems(NSArray* array, CCLayer* layer, b2World* world);
	
	template<class TYPEITEM>
	class GetItemType: public GetItem
	{
	public:
		Item* get(ItemParametrs& param)
		{
			return new TYPEITEM(param.layer,param.world,param.x,param.y);
		}
	};	
	
	/*template<>
	class GetItemType<Polka>: public GetItem
	{
	public:
		Item* get(ItemParametrs& param)
		{
			return new TYPEITEM(param.layer,param.world,param.x,param.y,param.heightLine);
		}
	};*/
	
	template<class TYPEEVENT>
	class GetEventType: public GetEvent
	{
	public:
		Event* get()
		{
			return new TYPEEVENT();
		}
	};
	
	template<class TYPEEVENT>
	static void addEvent(std::string name)
	{
		eventGreate[name] = new GetEventType<TYPEEVENT>();
	}
	
	template<class TYPEITEM>
	static void add(std::string name)
	{
		itemsGreate[name] = new GetItemType<TYPEITEM>();
	}
};