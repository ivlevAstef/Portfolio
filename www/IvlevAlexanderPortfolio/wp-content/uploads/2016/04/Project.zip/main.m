//
//  main.m
//  Vandal
//
//  Created by 11 on 04.02.11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"VandalAppDelegate");
	[pool release];
	return retVal;
}
